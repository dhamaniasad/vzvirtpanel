<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view the 
	* basic setup of the Vtonf Control Panel
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');

$string1 = '';
$hostname = '';
$mip = '';
$rip1 = '';
$rip2 = '';
$rip3 = '';
$rip4 = '';
$addr = '';
$email = '';
$phone = '';

if (isset ($_POST['mip']) && isset ($_POST['rip1']) && isset ($_POST['hostname'])) {

    $stringt = '';
    $string1 .= '<table class="table_msg">';
    $string1 .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';

    $hostname = trim($_POST['hostname']);
    $mip = trim($_POST['mip']);
    $rip1 = trim($_POST['rip1']);
    $rip2 = trim($_POST['rip2']);
    $rip3 = trim($_POST['rip3']);
    $rip4 = trim($_POST['rip4']);
    $addr = trim($_POST['addr']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    $host_flag = 0;
    $mip_flag = 0;
    $rip1_flag = 0;
    $rip2_flag = 0;
    $rip3_flag = 0;
    $rip4_flag = 0;
    $addr_flag = 0;
    $email_flag = 0;
    $phone_flag = 0;
    $dup_flag = 0;

    /* Validation for Host name*/

    if ($common_obj->valid_hostname($hostname)) {
        $host_flag = 1;
    }

    if (strlen($hostname) < 16) {
        if ($host_flag) {
            if ($common_obj->isValid_NameServer($hostname)) {
                $host_flag = 1;
            }
        }
    } else {
        $host_flag = 1;
        $hostname = "";
    }

    if ($host_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_HOSTNAME")."<br>";
    }

    $array = array ($mip, $rip1, $rip2, $rip3, $rip4);

    for ($i = 0; $i < sizeof($array); $i ++) {
        if (!$dup_flag) {
            for ($j = 0; $j < sizeof($array); $j ++) {
                if ($i != $j) {
                    if (strlen($array[$i]) > 0 && strlen($array[$j]) > 0 && $array[$i] == $array[$j]) {
                        $dup_flag = 1;
                        break;
                    }
                }
            }
        }
    }
    if ($dup_flag) {
        $stringt .= $lang_conv->fetch_word("DUPLICATE_IPS")."<br>";
    }

    /* Validation for Main IP*/

    if (strlen($mip) < 16) {
        if ($common_obj->isValid_NameServer($mip)) {
            $mip_flag = 1;
        }
    } else {
        $mip_flag = 1;
        $mip = "";
    }

    if ($mip_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_MIP")."<br>";
    }
    /* Validation for Ip1*/

    if (strlen($rip1) < 16) {
        if ($common_obj->isValid_NameServer($rip1)) {
            $rip1_flag = 1;
        }
    } else {
        $rip1_flag = 1;
        $rip1 = "";
    }

    if ($rip1_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_RIP").'1'."<br>";
    }

    if (strlen($rip2) > 0) {
        if (strlen($rip2) < 16) {
            if ($common_obj->isValid_NameServer($rip2)) {
                $rip2_flag = 1;
            }
        } else {
            $rip2_flag = 1;
            $rip2 = "";
        }
    }

    if ($rip2_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_RIP").'2'."<br>";
    }

    if (strlen($rip3) > 0) {
        if (strlen($rip3) < 16) {
            if ($common_obj->isValid_NameServer($rip3)) {
                $rip3_flag = 1;
            }
        } else {
            $rip3_flag = 1;
            $rip3 = "";
        }
    }

    if ($rip3_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_RIP").'3'."<br>";
    }

    if (strlen($rip4) > 0) {
        if (strlen($rip4) < 16) {
            if ($common_obj->isValid_NameServer($rip4)) {
                $rip4_flag = 1;
            }
        } else {
            $rip4_flag = 1;
            $rip4 = "";
        }
    }
    if ($rip4_flag) {
        $stringt .= $lang_conv->fetch_word("VALID_RIP").'4';
    }
    if (strlen($addr) > 0) {
        if (strlen($addr) > 200) {
            $addr_flag = 0;
            $stringt .= $lang_conv->fetch_word("VALID_ADDRESS")."<br>";
            $addr = "";
        }
    }
    if (strlen($email) > 0) {
        if ($common_obj->isValid_email($email)) {
            $email_flag = 1;
            $stringt .= $lang_conv->fetch_word("VALID_EMAIL")."<br>";
        }
        if (strlen($email) > 50) {
            $email = "";
        }
    }
    if (strlen($phone) > 0) {
        if ($common_obj->isValid_phone($phone)) {
            $phone_flag = 1;
            $stringt .= $lang_conv->fetch_word("VALID_PHONE")."<br>";
        }
        if (strlen($phone) > 50) {
            $phone = "";
        }
    }

    if ($host_flag || $mip_flag || $dup_flag || $rip1_flag || $rip2_flag || $rip3_flag || $rip4_flag || $addr_flag || $email_flag || $phone_flag) {
        $string1 .= '<tr><td >';
        $string1 .= $common_obj->display_message($stringt, 0);
        $string1 .= '</tr></td>';
    } else {

        $common_obj->updateKeyValuePair('hostname', $hostname);
        $common_obj->updateKeyValuePair('mip', $mip);
        $common_obj->updateKeyValuePair('rip1', $rip1);
        $common_obj->updateKeyValuePair('rip2', $rip2);
        $common_obj->updateKeyValuePair('rip3', $rip3);
        $common_obj->updateKeyValuePair('rip4', $rip4);
        $common_obj->updateKeyValuePair('addr', $addr);
        $common_obj->updateKeyValuePair('email', $email);
        $common_obj->updateKeyValuePair('phone', $phone);

        $string1 .= '<tr><td >';
        $string1 .= $common_obj->display_message($lang_conv->fetch_word("SETUP_UPDATE_SUCCESS"), 1);
        $string1 .= '</tr></td>';
        $string1 .= '</table>';
    }
}
if (!isset ($_POST['hostname'])) {
    $file = file('/etc/vtonf/setupvtonf');
    foreach ($file as $line) {
        list ($key, $value) = split(":", trim($line));
        if (strcasecmp(trim($key), 'hostname') == 0) {
            $hostname = trim($value);
        }
        if (strcasecmp(trim($key), 'mip') == 0) {
            $mip = trim($value);
        }
        if (strcasecmp(trim($key), 'rip1') == 0) {
            $rip1 = trim($value);
        }
        if (strcasecmp(trim($key), 'rip2') == 0) {
            $rip2 = trim($value);
        }
        if (strcasecmp(trim($key), 'rip3') == 0) {
            $rip3 = trim($value);
        }
        if (strcasecmp(trim($key), 'rip4') == 0) {
            $rip4 = trim($value);
        }
        if (strcasecmp(trim($key), 'addr') == 0) {
            $addr = trim($value);
        }
        if (strcasecmp(trim($key), 'email') == 0) {
            $email = trim($value);
        }
        if (strcasecmp(trim($key), 'phone') == 0) {
            $phone = trim($value);
        }
    }
}
?>

<div class="basicsetup_header_left"></div>
<div class="basicsetup_header"><?php echo $lang_conv->fetch_word("BASICSETUP")?></div>
<div class="basicsetup_header_right"></div>

<div  class="basicsetup_div">


<form name="basicsetup_form" id="basicsetup_form" method="post" onSubmit="return false">


<div   class="hostname_subhead" ><?php echo $lang_conv->fetch_word("HOSTNAME")?>  : </div>

<div class="hostname_textbox">
    <input id="hostname" type="text" name="hostname"  value="<?php echo $hostname?>">
</div>

<div class='basic_hosthelp_buttn'>
<a onmouseout="doUpdateNotes('General','exit')" 
onmouseover="doUpdateNotes('BASIC_HOST','enter')" 
onclick="javascript:doSetNote('BASIC_HOST')" href='javascript:void(0);'>
<img  src='image/help_butt.jpg' />
</a>
</div>


<div   class="mainip_subhead" ><?php echo $lang_conv->fetch_word("MAIN_IP_ADDRESS") ?> : </div>
<div class="mainip_textbox">
    <input  id="mip" type="text" name="mip"  value="<?php echo $mip?>"> 
</div>

<div class='basic_mainiphelp_buttn'>
<a onmouseout="doUpdateNotes('General','exit')" 
onmouseover="doUpdateNotes('BASIC_MAINIP','enter')" 
onclick="javascript:doSetNote('BASIC_MAINIP')" href='javascript:void(0);'>
<img  src='image/help_butt.jpg' />
</a>
</div>

<div   class="rip1_subhead" ><?php echo $lang_conv->fetch_word("R_IP").'1' ?> : </div>
<div class="rip1_textbox">
    <input id="rip1"  type="text" name="rip1"  value="<?php echo $rip1?>"> 
</div>

<div class='basic_rip1phelp_buttn'>
<a onmouseout="doUpdateNotes('General','exit')" 
onmouseover="doUpdateNotes('BASIC_RIP','enter')" 
onclick="javascript:doSetNote('BASIC_RIP')" href='javascript:void(0);'>
<img  src='image/help_butt.jpg' />
</a>
</div>

<div   class="rip2_subhead" ><?php echo $lang_conv->fetch_word("R_IP").'2' ?> : </div>
<div class="rip2_textbox">
    <input  id="rip2" type="text" name="rip2"  value="<?php echo $rip2?>"> 
</div>
<div class='basic_rip2phelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>

<div    class="rip3_subhead"><?php echo $lang_conv->fetch_word("R_IP").'3' ?> : </div>
<div class="rip3_textbox">
    <input   id="rip3" type="text" name="rip3"  value="<?php echo $rip3?>"> 
</div>
<div class='basic_rip3phelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>

<div    class="rip4_subhead"><?php echo $lang_conv->fetch_word("R_IP").'4' ?> : </div>
<div class="rip4_textbox">
    <input  id="rip4" type="text" name="rip4"  value="<?php echo $rip4?>"> 
</div>
<div class='basic_rip4phelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>

<div    class="homeaddress_subhead"><?php echo $lang_conv->fetch_word("HOMEADDRESS") ?> : </div>
<div class="homeaddress_textbox">

  <textarea name="addr" id="addr" rows="3" cols="24" wrap="on"><?php echo $addr?></textarea> 
  
</div>
<div class='homeaddresshelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>

<div    class="emailaddress_subhead"><?php echo $lang_conv->fetch_word("EMAILADDRESS") ?> : </div>
<div class="emailaddress_textbox">
    <input  id="email" type="text" name="email"  value="<?php echo $email?>"> 
</div>
<div class='emailaddresshelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>

<div    class="phone_subhead">	  <?php echo $lang_conv->fetch_word("PHONE") ?> :</div>
  
 
<div class="phone_textbox" >
      <input  id="phone" type="text" name="phone" value="<?php echo $phone?>">        
</div>
 
<div class='phonehelp_buttn'>
<?php echo "(".$lang_conv->fetch_word("OPTIONAL").")" ?>
</div>
<div class="basicsetup_btn">
	<a href="javascript:void(0);" class="buttonstyle"	 
	onclick="doBasicSetup();">
	<?php echo $lang_conv->fetch_word("UPDATEBASICSETUP")?>
	</a>
</div>

<div class="basic_message" id="successful_message">
  
<?php


print $string1;
?>
</div>
</form>
</div>