<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* restart Vtonf Control Panel page.
	*
	*/
	

include ('../services/checksession.php');
include ('../common/lang_conversion.php');
?>
<p>&nbsp;</p>

<div class="restartvtonfd_header_left"></div>
<div class="restartvtonfd_header"><?php echo $lang_conv->fetch_word("RESTARTVTONFD")?></div>
<div class="restartvtonfd_header_right"></div>

<div class="restartvtonfd_div">
<form action="" method="post" id="restartvtonfd" name="restartvtonfd">

<div class="restartvtonfd_question" >
<?php echo $lang_conv->fetch_word("ARE_SURE_RESTARTVTONFD")?>?
</div>
<div class="restartvtond_btn">
 <a href="javascript:void(0);" class="buttonstyle" onclick="doRestartVtonfd()">
 <?php echo $lang_conv->fetch_word("YES")?>
 </a>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="javascript:void(0);" class="buttonstyle" onclick="doClearRestartVtonfd()">
 <?php echo $lang_conv->fetch_word("NO")?>
 </a>
</div>
</form>
<?php

$res = "".$lang_conv->fetch_word("RESTARTVTONFD_SUCSS");
?>
<input type="hidden" value="<?php echo $res?>" id="change_msg" name="change_msg"/>
<div id="message" class="restartvtonfd_message" >
</div>
</div>