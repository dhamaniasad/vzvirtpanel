<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to Change the 
	* theme of the Vtonf Control Panel 
	*
	*/
	
include ('../services/checksession.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');

$lang_conv = new language_map();

$string = "";
if (isset ($_POST['themeid'])) {

    $selected_theme = trim($_POST['themeid']);

    $prev_theme = $_SESSION['theme'];

    $string .= '<table class="table_msg">';
    $string .= '<tr><th colspan=2>'.$lang_conv->fetch_word("RESULT").'</th></tr>';
    $string .= '<tr><td colspan=2 >';
    if (strcasecmp($prev_theme, $selected_theme) == 0) {
        print '<input type="hidden" id="success" value="0"/>';
        $string .= $lang_conv->fetch_word("THEMEALREDAYINUSE");
    } else {
        $selected_theme_code = $common_obj->getKeyValuePair($_ABS_PATH.'common/theme_list', $selected_theme);
        if (strcasecmp($selected_theme_code, '') == 0) {
            $selected_theme_code = 'default';
        }
        $common_obj->updateKeyValuePair('theme', $selected_theme_code);
        $_SESSION['theme'] = $selected_theme_code;
        $string1 = $lang_conv->fetch_word("THEMECHANGE").' '.$selected_theme;

        $string = '';
        print '<input type="hidden" id="success" value="1"/>';
        print '<input type="hidden" id="success_msg" value="'.$string1.'"/>';
    }
    $string .= '</td></tr>';
    $string .= '</table>';
}
?>
<div class="changtheme_header_left"></div>
<div class="changtheme_header"><?php echo $lang_conv->fetch_word("CHANGETHEME") ?></div>
<div class="changtheme_header_right"></div>

<div class="changtheme_div">

<form action="" method="post" id="themechange" name="themechange">


<div class="changetheme_id_box" ><?php echo $lang_conv->fetch_word("SELECT_THEME")?>: 
</div>

 <select id="themeid" name="themeid"  class="changetheme_drop_down" >
<?php


$themevalue = $_SESSION['theme'];
if (file_exists($_ABS_PATH.'common/theme_list')) {

    $lang_list = file($_ABS_PATH.'common/theme_list');
    foreach ($lang_list as $line) {
        if ($line != '') {
            list ($key, $value) = split(":", $line);

            if ($key != "") {
                $value = trim($value);
                if (strcasecmp($value, $themevalue) == 0) {
                    print '<option selected value="'.$key.'">'.$key.'</option>';
                } else {
                    print '<option value="'.$key.'">'.$key.'</option>';
                }
            }
        }
    }
} else {
    print '<option value="Default">Default</option>';
}
?>
    </select>
<div class="changetheme_butn">
<a href="javascript:void(0);" class="buttonstyle"
 onclick="doChangeTheme();">
 <?php echo $lang_conv->fetch_word("CHANGE")?>
 </a>
</div>

<div id="message" class="changetheme_message">
<?php


print $string;
?>
</div>
</form>
</div>