<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view the update 
	* settings page of the Vtonf Control Panel 
	*
	*/
	

include ('../services/checksession.php');
include ('../common/lang_conversion.php');
?>
<p>&nbsp;</p>
<div class="updatesettings_header_left"></div>
<div class="updatesettings_header"><?php echo $lang_conv->fetch_word("UPDATESETTINGS")?></div>
<div class="updatesettings_header_right"></div>

<div class="updatesettings_div">
<form action="" method="post" id="restartvtonfd" name="restartvtonfd">

<div class="updatesettings_question" >
<?php echo $lang_conv->fetch_word("ARE_SURE_UPDATESETTINGS")?>?
</div>
<div class="updatesettings_btn">
<a href="javascript:void(0);" class="buttonstyle" onclick="doUpdateSettings()">
<?php echo $lang_conv->fetch_word("UPDATE")?>
</a>
</div>
</form>
<input type="hidden" value="<?php echo $lang_conv->fetch_word("UPDATESETTINGS_SUCSS")?>" 
id="change_msg" name="change_msg"/>
<div id="message" class="updatesettings_message" >
</div>
</div>