<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to Change the 
	* login password of the Vtonf Control Panel 
	*
	*/
	
include ('../services/checksession.php');
include ('../common/lang_conversion.php');
include ('../lib/vtonfd.php');
include ('../include/config.php');
include ('../common/common_function.php');

$string = "";
if (isset ($_POST['pass1']) && isset ($_POST['pass2'])) {

    $vpspasswd1 = trim($_POST['pass1']);
    $vpspasswd2 = trim($_POST['pass2']);

    $string .= '<table class="chglogin_table" >';
    $string .= '<tr><th colspan=2>'.$lang_conv->fetch_word("RESULT").'</th></tr>';
    $string .= '<tr><td colspan=2 >';
    if (!($vpspasswd1 == $vpspasswd2)) {

        $string .= $common_obj->display_message($lang_conv->fetch_word("BOTHPSWDSMATCH").'!! ', 0);
    } else {
        if (strlen($vpspasswd1) < 6) {
            $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSSIXCHR")." !!!", 0);
        } else
            if (strlen($vpspasswd1) > 32) {
                $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSMORECHR")." !!!", 0);
            } else {
                $val = $vtonfd->change_login_passwd($vpspasswd1);
                if ($val) {
                    $string .= $lang_conv->fetch_word("PSWDCHNGFAIL").' !!!';
                } else {
                    $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDCHNGSUCESS")." !!! ", 1);
                }
            }
    }
    $string .= '</td></tr>';
    $string .= '</table>';
}
?>
<div class="chlogin_header_left"></div>
<div class="chlogin_header">
<?php echo $lang_conv->fetch_word("CHANGE_LOGIN_PSWD")?></div>
<div class="chlogin_header_right"></div>

<div class="chlogin_div">
<form id="form" name="form" method="post" action="">

	     <div class="chglogin_label"> 
	   		 <?php echo $lang_conv->fetch_word("LOGIN_PSWD")?> :
	   	 </div>
	   	 <div class="chglogin_txtpas">
	  		  <input type="password" name="pass1" id="pass1" maxlength="30">
	     </div>
	     <div class="reenterpas_label" > 
	     	<?php echo $lang_conv->fetch_word("REENTER_LOGIN_PSWD")?>:
	     </div>
	     <div class="reenterpas_txt">
	     	<input type="password" name="pass2" id="pass2" maxlength="30">
		 </div>
        <div class="chlogin_button">
       	  <a href="javascript:void(0);" class="buttonstyle"
       	         	 onclick="doChangeLoginPwd()">
       	 <?php echo $lang_conv->fetch_word("CHANGE")?>
       	 </a>
        </div>
</form>
<div id="message" class="chlogin_pswd_message">
<?php

print $string;
?>
</div>
</div>


