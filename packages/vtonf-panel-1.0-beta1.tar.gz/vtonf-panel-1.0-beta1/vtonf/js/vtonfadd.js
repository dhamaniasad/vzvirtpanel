/*
#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
var help="test";
var static_var=0;
var num_menus=5;
var ie="Microsoft Internet Explorer";
var objfull;

function show_services_data(datasource, divID, headDiv){		
	clearTimeout(t);	
	setTimeout('hideDetail("'+divID+'","'+headDiv+'")',100);
	setTimeout('new Effect.Appear("white_c")',100);
	setTimeout('get_services_data("'+datasource+'","detail")',100);
}


function get_services_data(datasource,divID) {
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= datasource;
	ajax.method="POST";
	ajax.element=divID;
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
}
function show_serverload_data(datasource, divID, headDiv){	
	clearTimeout(t);	
	setTimeout('hideDetail("'+divID+'","'+headDiv+'")',100);
	setTimeout('new Effect.Appear("white_c")',100);
	setTimeout('get_serverload_data("serverload.php","detail")',100);
}

function hideDetail(divID, headDiv){
	document.getElementById('bheader').style.display='block';
	document.getElementById('btitle').innerHTML=document.getElementById(headDiv).innerHTML
	var display=document.getElementById('bheader');
	display.innerHTML=document.getElementById(divID).innerHTML;
	document.getElementById('detail').innerHTML="";
	var detail = document.getElementById('bbody');
	detail.style.display='none';
	detail.style.visiblity='hidden';
}

var t;

function get_serverload_data(datasource,divID) {
	ajax= new sack();
	var vars = " ";
	ajax.requestFile=datasource;
	var form = document.serverload_form;
	if(static_var == 100){
		static_var = 0;
	}
	ajax.encVar('serverload_value',static_var++);	
	ajax.method="POST";
	ajax.element=divID;
	ajax.onCompletion = checksession;
	ajax.runAJAX(vars);
	var key= true;
	t=setTimeout('get_serverload_data("serverload.php","detail")',3000);
}
var ajax = new sack();

function whenCompleted(){
	checksession();
	var me = document.getElementById('fullscreen');	
	me.innerHTML = '';	
	var m = document.getElementById('main');
	m.className='enable';		
	enablehref();
	var e = document.getElementById('message');
	var form = document.getElementById('form');
	form.pass1.value="";
	form.pass2.value="";	
}

function clearErrorMessage(){

	clearTimeout(t);
	if(document.getElementById('message') != null){
		document.getElementById('message').innerHTML = "";
	}
}

function doChangePwd(){	
	ajax = new sack();
	var form = document.getElementById('form');
	ajax.encVar("pass1", form.pass1.value); // recomended method of setting data to be parsed.
	ajax.encVar("pass2", form.pass2.value); 
	
	ajax.requestFile = "changerootpasswd.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompleted;	
	ajax.runAJAX(vars);
}

/*
function checksession(){
	if(null != document.getElementById("relogin")){
		var str=document.getElementById("relogin").value;

		if(str.indexOf('relogin') != -1){
			alert("Sorry Your session has expired!!!!");
			window.location.reload();
		}
	}
}
*/
function closedialog(){
	var modaldialog = document.getElementById('modaldialog');
	document.getElementById('loadingimage').style.display="block";	
	modaldialog.style.display='none';
	enable_fullscreen();
}

function doExectuedialog(){
	
	ajax = new sack();
	var form = document.execute;
	var cstatus;
	for (i=0;i<form.nodest.length;i++){
		if (form.nodest[i].checked==true){
			cstatus=form.nodest[i].value;
			break;
		}
	}	
	var veid=document.getElementById('vid').value;
	var pstatus=document.getElementById('pstatus').value;
	ajax.encVar("node_veid", veid);
	ajax.encVar("cstatus", cstatus); 	

	ajax.requestFile = "../server/nodeprocess.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = showloadingimage;
	ajax.onCompletion = dialogcompletion;	
	ajax.runAJAX(vars);
}

function showloadingimage(){	
	var modaldialog = document.getElementById('modaldialog');
	modaldialog.style.display='none';
	document.getElementById('loadingimage').style.display="block";
}

function dialogcompletion(){
	enable_fullscreen();
}

function showdialogdiv(veid,status){
		var ful = document.getElementById('fullscreen');		
		ful.style.display='block';
		document.getElementById('loadingimage').style.display="none";	
		var modaldialog = document.getElementById('modaldialog');
		document.getElementById('dynamicnode_id').innerHTML = document.getElementById('node_name').value+'  '+veid;
		var version =getVersion() ;
		if(version <= 6){
				modaldialog.style.top="20%";
				modaldialog.style.left="40%";
				modaldialog.style.position='absolute';
		}
		modaldialog.style.display="block";
		document.getElementById('vid').value=veid;
		document.getElementById('pstatus').value=status;
		document.getElementById('nodest').focus();
}

function enable_fullscreen(){

		if(isMSIE){
			var version = getVersion() ;
			if(version <= 6){						
 				var selecttag = document.getElementsByTagName('select');
 				for(var i=0 ;i < selecttag.length; i++){
 					selecttag[i].disabled=false;
 				}
			}
		}	
	var b=document.getElementById('fullscreen');		
	b.style.display='none';
}



function disable_fullscreen(){
		var ful = document.getElementById('fullscreen');
		
		ful.style.display='block';
		var loadingimage = document.getElementById('loadingimage');
		if(isMSIE){
			
			var version =getVersion() ;
			if(version <= 6){
				loadingimage.style.top="20%";
				loadingimage.style.left="50%";
				loadingimage.style.position='relative';
						
 				var selecttag = document.getElementsByTagName('select');
 				for(var i=0 ;i < selecttag.length; i++){
 					selecttag[i].disabled=true; 	
 				}
			}
		}	
		
		if(!this.objfull){
			this.objfull = document.createElement("img");
			this.objfull.setAttribute('src','../images/loading_vtonf.gif');		
			this.objfull.setAttribute('title','Loading..');		
			loadingimage.insertBefore(this.objfull, loadingimage.firstChild);
		}	
 		
}

function whenLoading(){
	disable_fullscreen();
}

function whenCompleted(){
	checksession();
	enable_fullscreen();
}

function doChangeNodePwd(){	
	ajax = new sack();
	var form = document.getElementById('form');
	ajax.encVar("vid", form.vid[form.vid.selectedIndex].text);
	ajax.encVar("pass", form.pass.value);
	ajax.encVar("pass1", form.pass1.value); 
	
	ajax.requestFile = "changenoderootpwd.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompleted;	
	ajax.runAJAX(vars);
}	

function doRestartVE(datasource){	
	checksession();
	var form = document.restartve;
	if(confirm(form.vemsg.value)){
		ajax = new sack();	
		ajax.requestFile = datasource;			
		ajax.method = "POST";
		ajax.element = 'detail';
		ajax.encVar('vemsg','restart');
		var vars = " ";
		ajax.onLoading = whenLoading;
		ajax.onCompletion = whenCompleted;
		ajax.runAJAX(vars);
	}
}
function doClearRestartVE() {
	document.getElementById('detail').innerHTML = '';
}
function whenLoadingReboot(){
	disable_fullscreen();
 	t=setTimeout('reloadWin()',155000);
}

function reloadWin(){
	window.location.reload();
}

function doReboot(){		
	var form = document.rebootform;
	if(confirm(form.rebootmsg.value)){
	checksession();
	ajax = new sack();
	ajax.encVar('reboot','reboot');
	ajax.requestFile = "rebootserver.php";
	ajax.method = "POST";
	ajax.element = '';
	var vars = " ";
	ajax.onLoading = whenLoadingReboot;
	ajax.runAJAX(vars);
	}
}
function doClearReboot() {
	document.getElementById('detail').innerHTML = '';
}
var content="";
var tab="General";
function doUpdateNotes(obj,evt){
	ajax= new sack();
	var vars = " ";
	ajax.requestFile='help.php';
	if(evt=='enter'){		
		ajax.encVar("tab", obj);
	}else{
		ajax.encVar("tab", tab);
	}
	ajax.method="POST";
	ajax.element='details';
	ajax.runAJAX(vars);
}

function doSetNote(obj){
	tab=obj;	
	ajax= new sack();
	var vars = " ";
	ajax.requestFile='help.php';
	ajax.encVar("tab", obj);
	ajax.method="POST";
	ajax.element='details';
	ajax.runAJAX(vars);	
}

var dhtmlgoodies_slideSpeed = 10;	// Higher value = faster
var dhtmlgoodies_timer = 10;	// Lower value = faster

var objectIdToSlideDown = false;
var dhtmlgoodies_activeId = false;
var dhtmlgoodies_slideInProgress = false;
function showHideContent(e,inputId)
{
	if(dhtmlgoodies_slideInProgress)return;
	dhtmlgoodies_slideInProgress = true;
	if(!inputId)inputId = this.id;
	inputId = inputId + '';
	var numericId = inputId.replace(/[^0-9]/g,'');
	var answerDiv = document.getElementById('dhtmlgoodies_a' + numericId);

	objectIdToSlideDown = false;
	
	if(!answerDiv.style.display || answerDiv.style.display=='none'){		
		if(dhtmlgoodies_activeId &&  dhtmlgoodies_activeId!=numericId){			
			objectIdToSlideDown = numericId;
			slideContent(dhtmlgoodies_activeId,(dhtmlgoodies_slideSpeed*-1));
		}else{
			
			answerDiv.style.display='block';
			answerDiv.style.visibility = 'visible';
			
			slideContent(numericId,dhtmlgoodies_slideSpeed);
		}
	}else{
		slideContent(numericId,(dhtmlgoodies_slideSpeed*-1));
		dhtmlgoodies_activeId = false;
	}	
}

function slideContent(inputId,direction)
{	
	var obj =document.getElementById('dhtmlgoodies_a' + inputId);
	var contentObj = document.getElementById('dhtmlgoodies_ac' + inputId);
	height = obj.clientHeight;
	if(height==0)height = obj.offsetHeight;
	height = height + direction;
	rerunFunction = true;
	if(height>contentObj.offsetHeight){
		height = contentObj.offsetHeight;
		rerunFunction = false;
	}
	if(height<=1){
		height = 1;
		rerunFunction = false;
	}

	obj.style.height = height + 'px';
	var topPos = height - contentObj.offsetHeight;
	if(topPos>0)topPos=0;
	contentObj.style.top = topPos + 'px';
	if(rerunFunction){
		setTimeout('slideContent(' + inputId + ',' + direction + ')',dhtmlgoodies_timer);
	}else{
		if(height<=1){
			obj.style.display='none'; 
			if(objectIdToSlideDown && objectIdToSlideDown!=inputId){
				document.getElementById('dhtmlgoodies_a' + objectIdToSlideDown).style.display='block';
				document.getElementById('dhtmlgoodies_a' + objectIdToSlideDown).style.visibility='visible';
				slideContent(objectIdToSlideDown,dhtmlgoodies_slideSpeed);				
			}else{
				dhtmlgoodies_slideInProgress = false;
			}
		}else{
			dhtmlgoodies_activeId = inputId;
			dhtmlgoodies_slideInProgress = false;
		}
	}
}


var isMSIE = false;
function initShowHideDivs()
{	
	ajax= new sack();
	var vars = " ";
	ajax.requestFile='help.php';
	ajax.encVar('tab', 'General');
	ajax.method="POST";
	ajax.element='details';
	ajax.runAJAX(vars);	
	
	isMSIE = navigator.userAgent.indexOf('MSIE')>=0?true:false;
	var browserVersion = parseInt(navigator.userAgent.replace(/.*?MSIE ([0-9]+?)[^0-9].*/g,'$1'));
	if(!browserVersion)browserVersion=1;	

	var help_div=document.getElementById('helpbox');
	
	if(isMSIE && browserVersion<=6){		
		help_div.style.left = '7px';
		help_div.style.top = '20px';
		help_div.style.position = 'relative';
	}
	
	document.getElementById('bheader').style.display='none';
	var divs = document.getElementsByTagName('DIV');
	var divCounter = 1;
	for(var no=0;no<divs.length;no++){
		if(divs[no].className=='dhtmlgoodies_question'){
			divs[no].onclick = showHideContent;
			divs[no].id = 'dhtmlgoodies_q'+divCounter;
			var answer = divs[no].nextSibling;
			while(answer && answer.tagName!='DIV'){
				answer = answer.nextSibling;
			}
			answer.id = 'dhtmlgoodies_a'+divCounter;	
			contentDiv = answer.getElementsByTagName('DIV')[0];
			contentDiv.style.top = 0 - contentDiv.offsetHeight + 'px'; 	
			contentDiv.className='dhtmlgoodies_answer_content';
			contentDiv.id = 'dhtmlgoodies_ac' + divCounter;
			answer.style.display='none';
			answer.style.height='1px';
			divCounter++;
		}		
	}	
	/*For Left Menu Sliding*/
	for(var index=0;index < num_menus;index++){
		var menuObj = document.getElementById('dhtmlgoodies_menu'+index);	
		menuObj.className='dhtmlgoodies_menu';
	}

	var menuObj = document.getElementById('dhtmlgoodies_menu2');
		var mainMenuItemArray = new Array();
		
		var mainMenuItem = menuObj.getElementsByTagName('LI')[0];
		while(mainMenuItem){
			if(mainMenuItem.tagName && mainMenuItem.tagName.toLowerCase()=='li'){
				mainMenuItemArray[mainMenuItemArray.length] = mainMenuItem;
				var aTag = mainMenuItem.getElementsByTagName('A')[0];
				if(showSubOnMouseOver)
					aTag.onmouseover = showSub;	
				else
					aTag.onclick = showSub;	
			}
			mainMenuItem = mainMenuItem.nextSibling;
		}		
		
		var lis = menuObj.getElementsByTagName('A');
		for(var no=0;no<lis.length;no++){
			if(!showSubOnMouseOver)lis[no].onmouseover = stopAutoHide;
			lis[no].onmouseout = initAutoHide;
			lis[no].onmousemove = stopAutoHide;
		}

		for(var no=0;no<mainMenuItemArray.length;no++){
			var sub = mainMenuItemArray[no].getElementsByTagName('UL')[0];
			if(sub){
				mainMenuItemArray[no].id = 'mainMenuItem' + (no+1);
				var div = document.createElement('DIV');
				div.className='dhtmlgoodies_subMenu';
				document.body.appendChild(div);
				div.appendChild(sub);
				if(slideDirection=='right'){
					div.style.left = getLeftPos(mainMenuItemArray[no]) + mainMenuItemArray[no].offsetWidth + xOffsetSubMenu + 'px';
				}else{
					div.style.left = getLeftPos(mainMenuItemArray[no]) + xOffsetSubMenu + 'px';
				}
				div.style.top = getTopPos(mainMenuItemArray[no]) + 'px';
				div.id = 'subMenuDiv' + (no+1);
				sub.id = 'submenuUl' + (no+1);
				sub.style.position = 'relative';	

				if(navigator.userAgent.indexOf('Opera')>=0){
					submenuObjArray[no+1] = new Array();
					submenuObjArray[no+1]['parentDiv'] = mainMenuItemArray[no];
					submenuObjArray[no+1]['divObj'] = div;
					submenuObjArray[no+1]['ulObj'] = sub;
					submenuObjArray[no+1]['width'] = sub.offsetWidth;
					submenuObjArray[no+1]['left'] = div.style.left.replace(/[^0-9]/g,'');
				}
				sub.style.left = 1 - sub.offsetWidth + 'px';	
				
				
				
				if(browserVersion<7 && isMSIE)div.style.width = '1px';	
					
				if(navigator.userAgent.indexOf('Opera')<0){
					submenuObjArray[no+1] = new Array();
					submenuObjArray[no+1]['parentDiv'] = mainMenuItemArray[no];
					submenuObjArray[no+1]['divObj'] = div;
					submenuObjArray[no+1]['ulObj'] = sub;
					submenuObjArray[no+1]['width'] = sub.offsetWidth;
					
					submenuObjArray[no+1]['left'] = div.style.left.replace(/[^0-9]/g,'');
					if(fixedSubMenuWidth)submenuObjArray[no+1]['width'] = fixedSubMenuWidth;
				}	

				if(!document.all)div.style.width = '1px';			
					
			}			
		}
		
		menuObj.style.visibility = 'visible';
		
		window.onresize = resetPosition;
	}	
	


window.onload = initShowHideDivs;




	var timeBeforeAutoHide = 700;	// Microseconds to wait before auto hiding menu(1000 = 1 second)
	var slideSpeed_out = 10;	// Steps to move sub menu at a time ( higher = faster)
	var slideSpeed_in = 10;
		
	
	var slideTimeout_out = 25;	// Microseconds between slide steps ( lower = faster)
	var slideTimeout_in = 10;	// Microseconds between slide steps ( lower = faster)
	
	var showSubOnMouseOver = true;	// false = show sub menu on click, true = show sub menu on mouse over
	var fixedSubMenuWidth = false;	// Width of sub menu items - A number(width in pixels) or false when width should be dynamic
	
	var xOffsetSubMenu = 0; 	// Offset x-position of sub menu items - use negative value if you want the sub menu to overlap main menu
	
	var slideDirection = 'right';	// Slide to left or right ?
	
	/* Don't change anything below here */
	
	var activeSubMenuId = false;
	var activeMainMenuItem = false;
	var currentZIndex = 1000;		
	var autoHideTimer = 0;
	var submenuObjArray = new Array();
	var okToSlideInSub = new Array();
	var subPositioned = new Array();
	

	function stopAutoHide()
	{
		autoHideTimer = -1;
	}
	
	function initAutoHide()
	{
		autoHideTimer = 0;
		if(autoHideTimer>=0)autoHide();
	}
	
	function autoHide()
	{
		
		if(autoHideTimer>timeBeforeAutoHide)
		{
			
			if(activeMainMenuItem){
				activeMainMenuItem.className='';
				activeMainMenuItem = false;
			}
			
			if(activeSubMenuId){
				var obj = document.getElementById('subMenuDiv' + activeSubMenuId);
				showSub();
			}
		}else{
			if(autoHideTimer>=0){
				autoHideTimer+=50;
				setTimeout('autoHide()',50);
			}
		}
	}	
	
	function getTopPos(inputObj)
	{		
	  var returnValue = inputObj.offsetTop;
	  while((inputObj = inputObj.offsetParent) != null)returnValue += inputObj.offsetTop;
	  return returnValue;
	}
	
	function getLeftPos(inputObj)
	{
	  var returnValue = inputObj.offsetLeft;
	  while((inputObj = inputObj.offsetParent) != null)returnValue += inputObj.offsetLeft;
	  return returnValue;
	}
	
	function showSub()
	{
		var subObj = false;
		if(this && this.tagName){
			var numericId = this.parentNode.id.replace(/[^0-9]/g,'');
			okToSlideInSub[numericId] = false;
			var subObj = document.getElementById('subMenuDiv' + numericId);
			if(activeMainMenuItem)activeMainMenuItem.className='';
			if(subObj){
				if(!subPositioned[numericId]){
					if(slideDirection=='right'){
						subObj.style.left = getLeftPos(submenuObjArray[numericId]['parentDiv']) + submenuObjArray[numericId]['parentDiv'].offsetWidth + xOffsetSubMenu + 'px';
					}else{
						subObj.style.left = getLeftPos(submenuObjArray[numericId]['parentDiv']) + xOffsetSubMenu + 'px';
						
					}
					submenuObjArray[numericId]['left'] = subObj.style.left.replace(/[^0-9]/g,'');
					subObj.style.top = getTopPos(submenuObjArray[numericId]['parentDiv']) + 'px';
					subPositioned[numericId] = true;
				}				
				subObj.style.visibility = 'visible';
				subObj.style.zIndex = currentZIndex;
				currentZIndex++;	
				this.className='activeMainMenuItem';
				activeMainMenuItem = this;
			}
		}else{
			var numericId = activeSubMenuId;
		}
		if(activeSubMenuId && (numericId!=activeSubMenuId || !subObj))slideMenu(activeSubMenuId,(slideSpeed_in*-1));
		if(numericId!=activeSubMenuId && this && subObj){
			subObj.style.width = '0px';	
			slideMenu(numericId,slideSpeed_out);
			activeSubMenuId = numericId;
		}else{
			if(numericId!=activeSubMenuId)activeSubMenuId = false;
		}
		if(showSubOnMouseOver)stopAutoHide();
	}
	
	function slideMenu(menuIndex,speed){
		var obj = submenuObjArray[menuIndex]['divObj'];
		var obj2 = submenuObjArray[menuIndex]['ulObj'];
		var width = obj.offsetWidth + speed;
		if(speed<0){
			if(width<0)width = 0;
			obj.style.width = width + 'px';
			if(slideDirection=='left'){
				obj.style.left = submenuObjArray[menuIndex]['left'] - width + 'px';
				obj2.style.left = '0px';
			}else{
				obj2.style.left = width - submenuObjArray[menuIndex]['width'] + 'px' 
			}
			if(width>0 && okToSlideInSub[menuIndex])setTimeout('slideMenu(' + menuIndex + ',' + speed + ')',slideTimeout_in); else{
				obj.style.visibility = 'hidden';
				obj.style.width = '0px';
				if(activeSubMenuId==menuIndex)activeSubMenuId=false;
			}
			
		}else{
			if(width>submenuObjArray[menuIndex]['width'])width = submenuObjArray[menuIndex]['width'];
			if(slideDirection=='left'){
				obj.style.left = submenuObjArray[menuIndex]['left'] - width + 'px';
				obj2.style.left = '0px';
			}else{
				obj2.style.left = width - submenuObjArray[menuIndex]['width'] + 'px' 
			}		
			
			obj.style.width = width + 'px';
			if(width<submenuObjArray[menuIndex]['width']){
				setTimeout('slideMenu(' + menuIndex + ',' + speed + ')',slideTimeout_out);
			}else{
				okToSlideInSub[menuIndex] = true;
			}
		}
	}
	function resetPosition()
	{
		subPositioned.length = 0;
	}
		
