/*
#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
var help="test";
var id='';

function show_server_data(datasource, divID, headDiv){		
	clearTimeout(t);	
	setTimeout('hideDetail("'+divID+'","'+headDiv+'")',500);
	setTimeout('Effect.Appear("white_c")',500)
	setTimeout('get_server_data("'+datasource+'","detail")',500);
}

function get_server_data(datasource,divID){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	ajax.requestFile = datasource;
	ajax.method="POST";
	ajax.element=divID;		
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;	
}

function show_data(datasource,divId){
	clearTimeout(t);	
	new Effect.Fade(divId);
	setTimeout('Effect.Appear("'+divId+'", {duration:1})',1000)
	setTimeout('get_data("'+datasource+'","'+divId+'")',1000);
}

function get_data(datasource,divID){
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= '' + datasource;
	ajax.method="POST";
	ajax.element=divID;	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function show_openvz_disk(datasource,divId){
	clearTimeout(t);	
	new Effect.Fade(divId);
	setTimeout('Effect.Appear("'+divId+'", {duration:1})',1000)
	setTimeout('get_openvz_disk("'+datasource+'","'+divId+'")',1000);
}

function get_openvz_disk(datasource,divID){
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	var form = document.harddiskinfo;
	ajax.requestFile= '' + datasource;
	ajax.method="POST";
	ajax.encVar('disk_values',form.disk_values.value);
	ajax.encVar('disk_labels',form.disk_labels.value);
	ajax.element=divID;	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}



function show_edit_plans_data(datasource,edit_plan_checked){
	clearTimeout(t);	
	new Effect.Fade('plans_details');
	setTimeout('Effect.Appear(\'plans_details\', {duration:1})',1000)
	setTimeout('get_edit_plans_data("'+datasource+'","plans_details","'+edit_plan_checked+'")',1000);
}

function get_edit_plans_data(datasource,divID,edit_plan_checked){
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= '' + datasource;
	ajax.method="POST";
	ajax.element=divID;
	ajax.encVar('edit_plan_checked',edit_plan_checked);
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}


function checksession(){
	if(null != document.getElementById("relogin")){	
		var str=document.getElementById("relogin").value;
		if(str.indexOf('relogin') != -1){
			alert(document.getElementById("expired").value);
			window.location.reload();
		}
	}
}

function hideDetail(divID, headDiv){
	document.getElementById('bheader').style.display='block';
	document.getElementById('btitle').innerHTML = document.getElementById(headDiv).innerHTML
	var display=document.getElementById('bheader');
	display.innerHTML=document.getElementById(divID).innerHTML;
	document.getElementById('detail').innerHTML="";
	var detail = document.getElementById('bbody');
	detail.style.display='none';
	detail.style.visiblity='hidden';
}

function show_plan_data_back(datasource,divID){
	clearTimeout(t);
	var divn = "plans_details"; 		
	new Effect.Fade(divn);
	setTimeout('Effect.Appear("'+divID+'", {duration:1})',1000);
	setTimeout('get_plan_data_back("'+datasource+'","'+divID+'")',1000);
}

function get_plan_data_back(datasource,divID){
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= '' + datasource;
	ajax.encVar('back','1');
	var form = document.create_conf;
	ajax.encVar("NUMFILE_SOFT", form.NUMFILE_SOFT.value);
	ajax.encVar("NUMFILE_HARD", form.NUMFILE_HARD.value);
	ajax.encVar("DCACHESIZE_SOFT", form.DCACHESIZE_SOFT.value);
	ajax.encVar("DCACHESIZE_HARD", form.DCACHESIZE_HARD.value);
	ajax.encVar("NUMIPTENT_SOFT", form.NUMIPTENT_SOFT.value);
	ajax.encVar("NUMIPTENT_HARD", form.NUMIPTENT_HARD.value);
	ajax.encVar("AVNUMPROC_SOFT", form.AVNUMPROC_SOFT.value);
	ajax.encVar("AVNUMPROC_HARD", form.AVNUMPROC_HARD.value);
/*	ajax.encVar("MEMINFO_SOFT", form.MEMINFO_SOFT.value);*/
	ajax.encVar("MEMINFO_HARD", form.MEMINFO_HARD.value);
	ajax.encVar("DISKSPACE_SOFT", form.DISKSPACE_SOFT.value);
	ajax.encVar("DISKSPACE_HARD", form.DISKSPACE_HARD.value);
	ajax.encVar("DISKINODES_SOFT", form.DISKINODES_SOFT.value);
	ajax.encVar("DISKINODES_HARD", form.DISKINODES_HARD.value);
	ajax.encVar("CPUUNITS", form.CPUUNITS.value);
	ajax.encVar("QUOTATIME", form.QUOTATIME.value);
/*	ajax.encVar("DISABLED", form.DISABLED.value);
	ajax.encVar("ONBOOT", form.ONBOOT.value);*/
	ajax.encVar("QUOTAUGIDLIMIT", form.QUOTAUGIDLIMIT.value);
	
	ajax.encVar("CPULIMIT", form.CPULIMIT.value); 
	ajax.encVar("NAMESERVER", form.NAMESERVER.value); 
//	ajax.encVar("IPTABLES", form.IPTABLES.value);
	if(form.planaction.value!='edit'){
		ajax.encVar("CONFIGURATIONNAME", form.CONFIGURATIONNAME.value);	
	}
	ajax.method="POST";
	ajax.element=divID;	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function show_plans_data_next(datasource,divID){
	clearTimeout(t);		
	new Effect.Fade(divID);
	setTimeout('Effect.Appear("'+divID+'", {duration:1})',1000);
	setTimeout('get_plans_data_next("'+datasource+'","'+divID+'")',1000);
}

function get_plans_data_next(datasource,divID){
	clearTimeout(t);
	ajax= new sack();
	var form = document.create_conf1;
	
	ajax.encVar("KMEMSIZE_SOFT", form.KMEMSIZE_SOFT.value); 
	ajax.encVar("KMEMSIZE_HARD", form.KMEMSIZE_HARD.value); 
	ajax.encVar("LOCKEDPAGES_SOFT", form.LOCKEDPAGES_SOFT.value);
	ajax.encVar("LOCKEDPAGES_HARD", form.LOCKEDPAGES_HARD.value); 
	ajax.encVar("PRIVVMPAGES_SOFT", form.PRIVVMPAGES_SOFT.value);
	ajax.encVar("PRIVVMPAGES_HARD", form.PRIVVMPAGES_HARD.value);
	ajax.encVar("SHMPAGES_SOFT", form.SHMPAGES_SOFT.value); 
	ajax.encVar("SHMPAGES_HARD", form.SHMPAGES_HARD.value); 
	ajax.encVar("NUMPROC_SOFT", form.NUMPROC_SOFT.value);
	ajax.encVar("NUMPROC_HARD", form.NUMPROC_HARD.value); 
	ajax.encVar("PHYSPAGES_SOFT", form.PHYSPAGES_SOFT.value);
	ajax.encVar("PHYSPAGES_HARD", form.PHYSPAGES_HARD.value);
	ajax.encVar("VMGUARPAGES_SOFT", form.VMGUARPAGES_SOFT.value); 
	ajax.encVar("VMGUARPAGES_HARD", form.VMGUARPAGES_HARD.value); 
	ajax.encVar("OOMGUARPAGES_SOFT", form.OOMGUARPAGES_SOFT.value);
	ajax.encVar("OOMGUARPAGES_HARD", form.OOMGUARPAGES_HARD.value); 
	ajax.encVar("NUMTCPSOCK_SOFT", form.NUMTCPSOCK_SOFT.value);
	ajax.encVar("NUMTCPSOCK_HARD", form.NUMTCPSOCK_HARD.value);
	ajax.encVar("NUMFLOCK_SOFT", form.NUMFLOCK_SOFT.value); 
	ajax.encVar("NUMFLOCK_HARD", form.NUMFLOCK_HARD.value); 
	ajax.encVar("NUMPTY_SOFT", form.NUMPTY_SOFT.value);
	ajax.encVar("NUMPTY_HARD", form.NUMPTY_HARD.value); 
	ajax.encVar("NUMSIGINFO_SOFT", form.NUMSIGINFO_SOFT.value);
	ajax.encVar("NUMSIGINFO_HARD", form.NUMSIGINFO_HARD.value);
	ajax.encVar("TCPSNDBUF_SOFT", form.TCPSNDBUF_SOFT.value);
	ajax.encVar("TCPSNDBUF_HARD", form.TCPSNDBUF_HARD.value);
	ajax.encVar("TCPRCVBUF_SOFT", form.TCPRCVBUF_SOFT.value);
	ajax.encVar("TCPRCVBUF_HARD", form.TCPRCVBUF_HARD.value);
	ajax.encVar("OTHERSOCKBUF_SOFT", form.OTHERSOCKBUF_SOFT.value);
	ajax.encVar("OTHERSOCKBUF_HARD", form.OTHERSOCKBUF_HARD.value);
	ajax.encVar("DGRAMRCVBUF_SOFT", form.DGRAMRCVBUF_SOFT.value);
	ajax.encVar("DGRAMRCVBUF_HARD", form.DGRAMRCVBUF_HARD.value);
	ajax.encVar("NUMOTHERSOCK_SOFT", form.NUMOTHERSOCK_SOFT.value);
	ajax.encVar("NUMOTHERSOCK_HARD", form.NUMOTHERSOCK_HARD.value);
	ajax.method = "POST";
	
	var vars = " ";
	ajax.requestFile= '' + datasource;
	ajax.element=divID;
	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

/**
 * doCreateConf is used to create a conf data
 * in the server
 *
 * @author    Girish K
 * @param     datasource is the filename of redirection page
 * @return    output message
 * @date      2007-08-13
 * @deprecated
 * @see
 *
 */
function doCreateConf(){
	clearTimeout(t);
	var ajax = new sack();
	var form = document.create_conf;
	ajax.encVar("NUMFILE_SOFT", form.NUMFILE_SOFT.value);
	ajax.encVar("NUMFILE_HARD", form.NUMFILE_HARD.value);
	ajax.encVar("DCACHESIZE_SOFT", form.DCACHESIZE_SOFT.value);
	ajax.encVar("DCACHESIZE_HARD", form.DCACHESIZE_HARD.value);
	ajax.encVar("NUMIPTENT_SOFT", form.NUMIPTENT_SOFT.value);
	ajax.encVar("NUMIPTENT_HARD", form.NUMIPTENT_HARD.value);
	ajax.encVar("AVNUMPROC_SOFT", form.AVNUMPROC_SOFT.value);
	ajax.encVar("AVNUMPROC_HARD", form.AVNUMPROC_HARD.value);
/*	ajax.encVar("MEMINFO_SOFT", form.MEMINFO_SOFT.value);*/
	ajax.encVar("MEMINFO_HARD", form.MEMINFO_HARD.value);
	ajax.encVar("DISKSPACE_SOFT", form.DISKSPACE_SOFT.value);
	ajax.encVar("DISKSPACE_HARD", form.DISKSPACE_HARD.value);
	ajax.encVar("DISKINODES_SOFT", form.DISKINODES_SOFT.value);
	ajax.encVar("DISKINODES_HARD", form.DISKINODES_HARD.value);
	ajax.encVar("CPUUNITS", form.CPUUNITS.value);
	ajax.encVar("QUOTATIME", form.QUOTATIME.value);
/*	ajax.encVar("DISABLED", form.DISABLED.value);
	ajax.encVar("ONBOOT", form.ONBOOT.value);*/
	ajax.encVar("QUOTAUGIDLIMIT", form.QUOTAUGIDLIMIT.value);
	
	ajax.encVar("CPULIMIT", form.CPULIMIT.value); 
	ajax.encVar("NAMESERVER", form.NAMESERVER.value); 
//	ajax.encVar("IPTABLES", form.IPTABLES.value);
	if(form.planaction.value != 'edit'){
		ajax.encVar("CONFIGURATIONNAME", form.CONFIGURATIONNAME.value);	
	}
	ajax.encVar('planType',form.plantype.value);
	ajax.encVar('planaction',form.planaction.value);
 	
	ajax.requestFile = "../server/addnewplan-c.php";
	ajax.method = "POST";
	ajax.element = 'message';
	var vars = " ";
	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;	
	ajax.runAJAX(vars);	
}

/**
 * doAddNewNode is used to add 
 * a new node
 *
 * @author    Girish K
 * @date      2007-08-13
 * @deprecated
 * @see
 *
 */
function doAddNewNode(){	
	clearTimeout(t);
	var ajax = new sack();	
	var form = document.create_node_form;
	ajax.encVar("operating_system", form.operating_system.value); 
	ajax.encVar("configuration", form.configuration.value);
	ajax.encVar("hostname", form.hostname.value); 
	ajax.encVar("ip_address", form.ip_address.value);
	ajax.requestFile = "../server/createnode.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;	
	ajax.runAJAX(vars);
}

/**
 * doDestroyNode is used to destroy
 * the existing node
 *
 * @author    Girish K
 * @date      2007-08-13
 * @deprecated
 * @see
 *
 */
function doDestroyNode(){	
	clearTimeout(t);
	var ajax = new sack();	
	var form = document.destroy_node;
	ajax.encVar("veid", form.veid.value); 	
	if(confirm('Do You want destroy the node '+form.veid.value+' ?')){
	ajax.requestFile = "../server/destroy.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	id ='veid';
	var vars = " ";		
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;	
	ajax.runAJAX(vars);
	}
}

/**
 * show_nodelist is used to display the next page
 * of the nodelist 
 *
 * @author    Girish K
 * @param     datasource is the filename of redirection page
 * @return    output message
 * @date      2007-08-13
 * @deprecated
 * @see
 *
 */
function show_nodelist(datasource){
	clearTimeout(t);
 	new Effect.Fade('detail');	
	setTimeout('Effect.Appear(\'detail\')',1500);
	setTimeout('get_nodelist_data("'+datasource+'","detail")',1000);
}

/**
 * get_nodelist_data is used to retrieve the data
 * of next nodelist page.
 *
 * @author    Girish K
 * @param1    datasource is the filename of redirection page
 * @param2    divID is the div id for the message to display.
 * @return    output message
 * @date      2007-08-13
 * @deprecated
 * @see
 *
 */
function get_nodelist_data(datasource,divID){
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= '' + datasource;
	ajax.element=divID;
	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	var key= true;
	ajax.runAJAX(vars);
}


/**
 * doRenamePlan is used to rename the plan
 * of the plans already exists.
 *
 * @author    Girish K
 * @date      2007-09-03
 * @deprecated
 * @see
 *
 */

function doRenamePlan(){
	clearTimeout(t);
	var ajax = new sack();
	var form = document.renameplan_form;
	ajax.encVar("oldplanvalue", form.oldplanvalue.value);
	ajax.encVar("newplanvalue", form.newplanvalue.value);	
	ajax.requestFile = "../server/renameplan.php";
	ajax.method = "POST";
	ajax.element = 'plans_details';
	var vars = " ";		
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
}

/**
 * doDeletePlan is used to delete the plan
 * of the plans already exists.
 *
 * @author    Girish K
 * @date      2007-09-03
 * @deprecated
 * @see
 *
 */

function doDeletePlan(selectbox){
	clearTimeout(t);
	var ajax = new sack();
	var form = document.deleteplan_form;
	ajax.encVar("deleteplan_value", form.deleteplan_value.value);	
	if(confirm('Do You want Delete the plan '+form.deleteplan_value.value+' ?')){
	ajax.requestFile = "../server/deleteplan.php";
	ajax.method = "POST";
	ajax.element = 'plans_details';
	var vars = " ";		
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	}
}

function openEditPlanPage(){
	clearTimeout(t);
	var ajaz= new sack();
	var form=document.editplan_form;
	ajax.encVar('editplan_value',form.editplan_value.value);
	ajax.encVar('edit_plan_checked',form.edit_plan_checked.value);
	ajax.encVar('planaction','edit');
	ajax.method="POST";
	ajax.element='plans_details';
	var vars="";
	ajax.requestFile = "../server/editwizard.php";
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
}

/**
 * doAddNewPlan is used to create a 
 * simple plan with the limited values.
 *
 * @author    Girish K
 * @date      2007-09-04
 * @deprecated
 * @see
 *
 */
function doAddNewPlan(){
	clearTimeout(t);
	var ajaz= new sack();
	var form=document.easywzd_form;
	ajax.encVar('memory_vlaue',form.memory_vlaue.value);
	ajax.encVar('disk_value',form.disk_value.value);
	ajax.encVar('nameserver_value',form.nameserver_value.value);
	if(form.planaction.value!='edit'){
		ajax.encVar('planname_value',form.planname_value.value);
	}
	ajax.encVar('memory_type',form.memory_type.value);
	ajax.encVar('disk_type',form.disk_type.value);
	ajax.encVar('planType','easy');
	ajax.encVar('planaction',form.planaction.value);
	ajax.requestFile = "../server/addnewplan-c.php";
	ajax.method='POST';
	ajax.element='message';
	var vars='';
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;	
	ajax.runAJAX(vars);
}

function whenProcessingData(){		
	disable_fullscreen();			
}

function whenCompletion(){
	checksession();
	enable_fullscreen();
}

function getVersion() { 	
			
  if(navigator.appName.indexOf("Netscape")==-1){
  			var dataString = navigator.appVersion;
			var index = dataString.indexOf("MSIE");
			index = index + 5;
			dataString = dataString.replace(/;/,"Z");
			var stop = dataString.indexOf(";");
			version = dataString.substring(index,stop);
			version = parseInt(""+version);
		return this.version;
	}

}

function displayhelp(){
				var details = document.getElementById("helpbox");
		var browser=navigator.appName.toLowerCase();
	if(browser.indexOf("Microsoft Internet Explorer")==-1){
		var version =getVersion() ;
			if(version <= 6){
				details.style.left=7+"px";
				details.style.top=20+"px";
				details.style.position="relative";
			}
	}	
}
