/*
#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
	
var help="test";
var ipidGeneration = new Array("5","4","3","2");
var nsidGeneration = new Array("4","3","2");
var ipcounter=0;
var nscounter=0;
var maxvalue = 5;
var counter  = 1;
var arrayn = new Array("5","4","3","2");

function hideDetail(divID, headDiv){
	clearTimeout(t); 
	document.getElementById('bheader').style.display='block';
	document.getElementById('btitle').innerHTML=document.getElementById(headDiv).innerHTML
	var display=document.getElementById('bheader');
	display.innerHTML=document.getElementById(divID).innerHTML;
	document.getElementById('detail').innerHTML="";
	var detail = document.getElementById('bbody');
	detail.style.display='none';
	detail.style.visiblity='hidden';
	document.getElementById('bheader').style.height=168+"px";
}


function show_nodemngt_data(datasource,divID,headDiv){	
	clearTimeout(t); 
	setTimeout('hideDetail("'+divID+'","'+headDiv+'")',100);
	setTimeout('new Effect.Appear("white_c")',100);
	setTimeout('get_nodemngt_data("'+datasource+'","detail")',1000);
	counter  = 1;
}

function get_nodemngt_data(datasource,divID){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	ajax.requestFile = datasource;
	ajax.method="POST";
	ajax.element=divID;	
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

var static_var=0;
function get_nodeuptime_data(datasource) {
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	ajax.requestFile='../nmgnt/'+datasource;
	var form = document.nodeaction_form;
	if(static_var == 100){
		static_var = 0;
	}
	ajax.encVar('node_veid',form.node_veid.value);
	ajax.encVar('nodeuptime_value',static_var++);		
	ajax.method="POST";
	ajax.element='message';
	ajax.runAJAX(vars);
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = checksession;
	var key= true;
	t=setTimeout('get_nodeuptime_data("nodeuptime.php")',3000);
	counter  = 1;
}

function doNodeAction(datsource,divid){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	ajax.encVar('node_veid',form.node_veid.value);
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datsource;
	ajax.element=divid;
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function doSetHostName(datsource,divid){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	ajax.encVar('node_veid',form.node_veid.value);
	ajax.encVar('hostname',form.hostname.value);
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datsource;
	ajax.element=divid;	
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}



function doRemoveIPAction(datasource,msg){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	var iplist = form.iplist;
	ajax.encVar('node_veid',form.node_veid.value);	
	
	var ipcount=0;
	if(iplist !=null){
		for(i=0;i<iplist.length;i++){	
			if(iplist[i].selected){
				ajax.encVar('n'+ipcount,iplist[i].value);
				ipcount++;
			}
		}	
		document.getElementById('message').innerHTML='';
		if(ipcount != 0){
			ajax.encVar('ipcount',ipcount);
			ajax.method="POST";
			ajax.requestFile = '../nmgnt/'+datasource;
			ajax.element='detail';	
			ajax.onLoading=whenProcessingData;
			ajax.onCompletion = whenCompletion;
			ajax.runAJAX(vars);
			var key= true;
		}else{
			alert(msg);
		}
	}
}

function fillIps(){
clearTimeout(t); 
	ajax= new sack();
	var vars = "";
	var form = document.nodeaction_form;
	if(form.iplist !=null){
		form.iplist=null;
	}
	ajax.encVar('node_veid',form.node_veid.value);
	document.getElementById('message').innerHTML='';	
	document.getElementById('ipselectbox').innerHTML="";
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/getnodeips.php';
	ajax.element='ipselectbox';
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}



function doAddIPAction(datasource){
	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	
	ajax.encVar('node_veid',form.node_veid.value);
	
	ajax.encVar('n1',form.n1.value);
	if(document.getElementById('n2') != null){			
			ajax.encVar('n2',form.n2.value);		
	}
	if(document.getElementById('n3') != null){
		ajax.encVar('n3',form.n3.value);	
	}
	if(document.getElementById('n4') != null){
		ajax.encVar('n4',form.n4.value);
	}
	if(document.getElementById('n5') != null){
		ajax.encVar('n5',form.n5.value);
	}
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datasource;
	ajax.element='message';	
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function doSetNSAction(datasource){

	clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	ajax.encVar('node_veid',form.node_veid.value);
	
	ajax.encVar('n1',form.n1.value);
	if(document.getElementById('n2') != null){			
			ajax.encVar('n2',form.n2.value);		
	}
	if(document.getElementById('n3') != null){
		ajax.encVar('n3',form.n3.value);	
	}
	if(document.getElementById('n4') != null){
		ajax.encVar('n4',form.n4.value);
	}
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datasource;
	ajax.element='message';	
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function clearNS(){
	clearTimeout(t); 
	if(document.getElementById('n1') != null){
			document.getElementById('n1').value='';		
	}
	if(document.getElementById('n2') != null){			
			document.getElementById('n2').value='';		
	}
	if(document.getElementById('n3') != null){
			document.getElementById('n3').value='';			
	}
	if(document.getElementById('n4') != null){
			document.getElementById('n4').value='';		
	}
	if(document.getElementById('message') != null){
		document.getElementById('message').innerHTML="";
	}
}

function doSetMemoryAction(datasource){
clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	ajax.encVar('node_veid',form.node_veid.value);	
	ajax.encVar('memory_value',form.memory_value.value);
	ajax.encVar('setmemory_type',form.setmemory_type.value);
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datasource;
	ajax.element='detail';	
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;
}

function doChangeplan(datasource){
clearTimeout(t); 
	ajax= new sack();
	var vars = " ";
	var form = document.nodeaction_form;
	ajax.encVar('node_veid',form.node_veid.value);	
	ajax.encVar('plan_name',form.plan_name.value);
	ajax.method="POST";
	ajax.requestFile = '../nmgnt/'+datasource;
	ajax.element='detail';	
	ajax.onLoading=whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
	var key= true;

}

/*
function checksession(){
	if(null != document.getElementById("relogin")){	
		var str=document.getElementById("relogin").value;
		if(str.indexOf('relogin') != -1){
			alert("Sorry Your session has expired!!!!");
			window.location.reload();
		}
	}
}
*/
function whenProcessingData(){		
	clearTimeout(t); 
		disable_fullscreen();			
}

function whenCompletion(){
	clearTimeout(t); 
	checksession();
	enable_fullscreen();
}

function removetextboxes(){
	clearTimeout(t); 
	var i = document.getElementById('hiddennumber').value;
	  	i--;
	  	document.getElementById('n'+i).value='';
	  	document.getElementById('n'+i).style.display="none";
  	 	if(i != 2){
  			document.getElementById('l'+(i-1)).innerHTML = document.getElementById('l'+i).innerHTML;
  			document.getElementById('lable').style.top=document.getElementById('n'+(i-1)).style.top;
  			document.getElementById('l'+i).innerHTML ='';
  	 	document.getElementById('message').style.top= parseInt(document.getElementById('message').style.top)-30+"px";
  		}else{
  			document.getElementById('message').style.top= 400+"px";
  			document.getElementById('l'+i).innerHTML ='';
  		}
	
  		 document.getElementById('hiddennumber').value = i;
  	 	
}

function addElement() {

	clearTimeout(t); 
	document.getElementById('message').innerHTML="";
	
	if(document.getElementById('pagename').value == 'ip'){		
		maxvalue = 5;
	}else{
		maxvalue = 4;
	}
	
  	var myDiv = document.getElementById('myDiv');	

  		var num = arrayn.pop();  		

	  	var divIdName = 'myDiv'+num;	  	 

	if(counter < maxvalue){			
	
  		var textName = 'n'+num;	  	 
  		var newdiv = document.createElement('div');
  		newdiv.setAttribute('id',divIdName);
  		/*
		var htmlv=
		'<div id="'+divIdName+'">'+
		'<table id="'+divIdName+'">'+
		'<tr><td><input type="text" value="" id="'+textName+'"></td>'+
		'<td><a href="javascript:void(0)" onclick="removeElement(\''+divIdName+'\')">'+
		document.getElementById('removetype').value+'</a></td>'+
		'<td><a href="javascript:void(0)" onclick="addElement()">'+document.getElementById('addtype').value+
		'</a></td></tr></table></div>';
		*/
		newdiv.innerHTML= '<table id="'+divIdName+'">'+
		'<tr><td><input type="text" value="" name="'+textName+'" id="'+textName+'"></td>'+
		'<td><a href="javascript:void(0)" onclick="removeElement(\''+divIdName+'\')">'+
		document.getElementById('removetype').value+'</a></td>'+
		'<td><a href="javascript:void(0)" onclick="addElement()">'+document.getElementById('addtype').value+
		'</a></td></tr></table>';
		myDiv.appendChild(newdiv);
//		myDiv.innerHTML+=htmlv;		
		counter++;
	}else{
		alert('Sorry only '+maxvalue+document.getElementById('pagename').value+'\'s');
	}
}

function removeElement(divNum) { 
	clearTimeout(t); 
	document.getElementById('message').innerHTML="";
	var d = document.getElementById('myDiv');	

	var id = divNum;
	id=id.substr(5);
	d.removeChild(document.getElementById(divNum));
	arrayn.push(id);
	counter--;
} 
