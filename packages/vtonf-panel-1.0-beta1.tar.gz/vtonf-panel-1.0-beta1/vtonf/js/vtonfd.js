/*
#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

function show_vtonfd_data(datasource, divID, headDiv){
	clearTimeout(t);
	setTimeout('hideDetail("'+divID+'","'+headDiv+'")',100);
	setTimeout('new Effect.Appear("white_c")',100);
	setTimeout('get_vtonfd_data("'+datasource+'","detail")',1000);
}

function get_vtonfd_data(datasource,divID) {
	clearTimeout(t);
	ajax= new sack();
	var vars = " ";
	ajax.requestFile= datasource;
	ajax.method="POST";
	ajax.element=divID;
	ajax.onLoading = whenProcessingData;
	ajax.onCompletion = whenCompletion;
	ajax.runAJAX(vars);
}

function doChangeLoginPwd(){
	ajax = new sack();
	var form = document.form;
	ajax.encVar("pass1", form.pass1.value); 
	ajax.encVar("pass2", form.pass2.value); 
	
	ajax.requestFile = "../vtonfd/chgloginpswd.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompleted;	
	ajax.runAJAX(vars);
}
function doChangeLang(){
	ajax = new sack();
	var form = document.getElementById('languagechange');
	ajax.encVar("languageid", form.languageid.value); // recomended method of setting data to be parsed.
	ajax.requestFile = "../vtonfd/changelang.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompletedReload;	
	ajax.runAJAX(vars);
}
function doChangeTheme(){
	ajax = new sack();
	var form = document.themechange;
	ajax.encVar("themeid", form.themeid.value); // recomended method of setting data to be parsed.
	ajax.requestFile = "../vtonfd/changetheme.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompletedReload;	
	ajax.runAJAX(vars);
}
function doBasicSetup(){
	ajax = new sack();
	var form = document.basicsetup_form;
	var ip1 = form.rip1.value;
	var ip2 = form.rip2.value;
	var ip3 = form.rip3.value;
	var ip4 = form.rip4.value;
	var mip = form.mip.value;
	
	ajax.encVar("rip1",ip1);	
	ajax.encVar("rip2",ip2);
	ajax.encVar("rip3",ip3);
	ajax.encVar("rip4",ip4);
	
	ajax.encVar("hostname",form.hostname.value);
	ajax.encVar("mip",mip);	
	ajax.encVar("addr",form.addr.value);
	ajax.encVar("email",form.email.value);
	ajax.encVar("phone",form.phone.value);	
	ajax.requestFile = "../vtonfd/basicsetup.php";
	ajax.method = "POST";
	ajax.element = 'detail';
	var vars = " ";
	ajax.onLoading = whenLoading;
	ajax.onCompletion = whenCompleted;	
	ajax.runAJAX(vars);
	
}
function whenCompletedReload(){	
	checksession();
	enable_fullscreen();
	var val= document.getElementById('success').value;
	if(val != 0){
		alert(document.getElementById('success_msg').value);
		t=setTimeout('reloadWin()',1500);
	}
}
function whenCompletedChange(){	
	clearTimeout(t);
	checksession();	
	t=setTimeout('disable_fullscreen()',2000);
	t=setTimeout('enable_fullscreen()',1000);	
	setTimeout('reloadWin1()',3000);
}
function reloadWin1(){
	clearTimeout(t);
	var val=document.getElementById('change_msg').value;
	alert(val);
	window.location.reload();
}

function doRestartVtonfd(){
	clearTimeout(t);
	ajax = new sack();
	ajax.requestFile = "../vtonfd/restartvtonfd-c.php";
	ajax.method = "POST";
	ajax.element = 'message';
	var vars = " ";
	ajax.onLoading = whenCompletedChange;
	ajax.runAJAX(vars);
}
function doClearRestartVtonfd() {
	document.getElementById('detail').innerHTML = '';
}
function doUpdateSettings(){
	clearTimeout(t);
	ajax = new sack();
	ajax.requestFile = "../vtonfd/updatesetings-c.php";
	ajax.method = "POST";
	ajax.element = 'message';
	var vars = " ";
	ajax.onLoading = whenCompletedChange;
	ajax.runAJAX(vars);
}
function open_window(url){
	window.open(url);
}