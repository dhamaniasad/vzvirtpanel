<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* displayLogin method is used to 
	* display the login page
	*
	* @param     none
	* @return    none 
	*
	*/

function displayLogin() {

	include_once ('common/common_function.php');

	$theme= $_SESSION['theme'];
	$language_obj= new language_map();
	$common_obj= new common_functions();
	$logged_in= $common_obj->checkLogin();
	if ($theme == '') {
		$theme= 'default';
	}
	if ($logged_in) {
		header("Location:../services/ctrlpanel.php");
		exit;
	} else {
?>

<html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Vtonf OpenVZ VPS Server Control Panel</title>
<link href="../styles/<?php echo $theme ?>.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/ico" href="../images/vtonf_logo.jpg" /> 
</head>

<body>
<div class="login_div" >
	
<form action="../index.php" name="login" method="post">
	<div class="username_label" >
	<span class="letter">
				<?php echo $language_obj->fetch_word_login("USERNAME")?>:
	</span> 
	</div>
	<div class="username_txt" >
		<input type="text" name="user" id="user" class="login_user">
	</div>
		<script type='text/javascript' language='JavaScript'>
			if(document.getElementById) document.getElementById('user').focus();
		</script>
	<div class="pswd_label" >
		<span class="letter">
			<?php echo $language_obj->fetch_word_login("PASSWORD")?>:
		</span> 
	</div>
	<div class="pswd_txt" >
		<input type="password" name="pass" class="login_passwd">
	</div>
	<input type="hidden" name="sublogin" value="1">
	<div class="login_buton" >
		<input type="image" src="../images/login_btn.gif" >
	</div>
	<div class="lang_label" >
	<span class="letter">
		<?php echo $language_obj->fetch_word_login("LANGUAGE")?>:
	</span> 
	</div>
	<div class="lang_drop" >
		<select name="language">
	<?php


		$lang_code= $_SESSION['language'];
		$langs= $common_obj->getLanguages();
		foreach ($langs as $key => $value) {
			if ($key == $lang_code) {
				print '<option selected value="'.$value.'">'.$value.'</option>';
			} else {
				print '<option value="'.$value.'">'.$value.'</option>';
			}
		}
?>						
	</select>
	</div>
	<div class="powered_login" >
		<?php echo $language_obj->fetch_word_login("POWERED")?> BobCares
	</div>
</form>
</div>
</body>
</html>
<?php


	}
}

// To check whether the user submitted his username and password through the form
/*
  Checks to see if the user has submitted his username and password through the login form,
  if so, checks authenticity in database and creates session.
*/
?>
<?php


$message= "";
if (isset ($_POST['user'])) {
	$language_obj= new language_map();

	include_once ('common/common_function.php');
	$common_obj= new common_functions();
	/* Check that all fields were typed in */
	$flag= 0;
	if ($_POST['user'] == '' || $_POST['pass'] == '') {

		$message= $language_obj->fetch_word_login("INVALID_LOGINFILLING");
		$flag= 1;

	}
	if ($flag == 0) {
		/* Spruce up username, check length */
		/* Checks that username  and password is correct */
		$password_submitted= $_POST['pass'];
		$result= $user->checkUser($_POST['user'], $password_submitted);

		$language_value= $_POST['language'];

		$lang_code= $common_obj->getKeyValuePair('common/language_list', $language_value);
		if ($lang_code != $_SESSION['language']) {
			$common_obj->updateKeyValuePair('language', $lang_code);
		}
		$_SESSION['language']= $lang_code;
		$theme_code= $common_obj->getKeyValuePair('/etc/vtonf/setupvtonf', 'theme');
		$_SESSION['theme']= $theme_code;

		/* Check error codes */
		if ($result == 1) {
			$message= $language_obj->fetch_word_login("INVALID_LOGIN");
			//     return false;
		} else
			if ($result == 3) {
				$message= $language_obj->fetch_word_login("INVALID_LOGIN");

				//return false;
			} else
				if ($result == 0) {
					/* Username and password correct, register session variables */
					$_SESSION['username']= $_POST['user'];
					$_SESSION['password']= $password_submitted;
					//Adding for time set for expire -shein
					//		 $_SESSION['time_start']=time();
					//end of time set
				}
	}
}
?>

<div class="login_errmessage">
<?php


echo $message;
$message= '';
?>
</div>


