<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the OpenVz Menu Items
	*
	*/
	
include ('../services/checksession.php');
include ('../common/lang_conversion.php');
?>

<div class="openvz_header_left"></div>
<div class="openvz_header"><?php echo $lang_conv->fetch_word("OPENVZ")?></div>
<div class="openvz_header_right"></div>

<div class="openvz_bheader" id="icon_set">


<a href="javascript:void(0);" onclick="javascript:doSetNote('OVZKernel');
javascript:show_data('../server/ovzkernel.php','detail1');" 
onmouseover="doUpdateNotes('OVZKernel','enter')" onmouseout="doUpdateNotes('General','exit')">

	<div id="openvz_kernel" class="openvz_kernel">
		<input src="image/openvz_kernel.jpg" height="43" type="image" width="47">
	</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('Processor');
javascript:show_data('../server/openvzprocessor.php','detail1');"
 onmouseover="doUpdateNotes('Processor','enter')" onmouseout="doUpdateNotes('General','exit')">

<div id="openvz_processor" class="openvz_processor">

		<input src="image/openvz_processor.jpg" height="43" type="image" width="47">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('OVZMemory');
javascript:show_data('../server/ovzmemory.php','detail1');"
 onmouseover="doUpdateNotes('OVZMemory','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="openvz_memory" class="openvz_memory">
		<input src="image/openvz_memory.jpg" height="43" type="image" width="47">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('OVZHardDisk');
javascript:show_data('../server/ovzharddisk.php','detail1');"
 onmouseover="doUpdateNotes('OVZHardDisk','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="openvz_harddisk" class="openvz_harddisk">
		<input src="image/openvz_harddisk.jpg" height="43" type="image" width="47">
</div>

</a>
<div id="openvz_name_01" class="openvz_name_01"><?php echo $lang_conv->fetch_word('OVZKERNEL');?> </div>
<div id="openvz_name_02" class="openvz_name_02"><?php echo $lang_conv->fetch_word('PROCESSOR');?></div>
<div id="openvz_name_03" class="openvz_name_03"><?php echo $lang_conv->fetch_word('OVZMEMORY');?> </div>
<div id="openvz_name_04" class="openvz_name_04"><?php echo $lang_conv->fetch_word('OVZHARDDISK');?> </div>


<div class="openvz_detail" id="detail1">
</div>

<form name="harddiskinfo" id="harddiskinfo" method="POST">
	
  <input type="hidden" name="disk_labels" id="disk_labels" value="69*31"/>
  
  <input type="hidden" name="disk_values" id="disk_values" value="U*A"/> 
  
</form>

</div>


