<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the OpenVz Kernel Information. 
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
$val = $server->openvz_kernel();

$value = '';
$value .= '<div class="openvz_sub_header_left"></div><div id="openvz_sub_header" class="openvz_sub_header"><div class="openvz_sub_header_right"></div>'.$lang_conv->fetch_word("OPENVZ_KERNEL").'</div>'.'<div id="openvz_sub_div" class="openvz_sub_div"><br>';
$uname_r = $val['uname_r'][0];
$uname_i = $val['uname_i'][0];
$uname_host = $val['hostname'][0];

$value .= '<div class="ovzkernel_div">';
$value .= '<table class="ovzkernel_table">';
$value .= '<tr>';
$value .= '<th>';
$value .= ''.$lang_conv->fetch_word("TYPE");
;
$value .= '</th>';
$value .= '<th>';
$value .= ''.$lang_conv->fetch_word("VALUE");
;
$value .= '</th>';
$value .= '</tr>';
$value .= '<tr>';
$value .= '<td>';
$value .= 'Openvz Kernel';
$value .= '</td>';
$value .= '<td>';
$value .= $uname_r;
$value .= '</td>';
$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= 'Openvz hardware Platform';
$value .= '</td>';
$value .= '<td>';
$value .= $uname_i;
$value .= '</td>';
$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= 'Hostname';
$value .= '</td>';
$value .= '<td>';
$value .= $uname_host;
$value .= '</td>';
$value .= '</tr>';
$value .= '</table>';
$value .= '</div>';

print $value;
?>