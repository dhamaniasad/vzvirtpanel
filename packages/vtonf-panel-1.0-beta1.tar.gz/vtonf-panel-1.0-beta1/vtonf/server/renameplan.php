<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to rename
	* the plan.
	*
	*/
	
include('../services/checksession.php');
include('../lib/server.php');
include('../include/config.php');
include('../common/lang_conversion.php');
include ('../common/common_function.php');

$oldname='';
$newname='';
$string = '';

if(isset($_POST['oldplanvalue']) && isset($_POST['newplanvalue'])){

$oldname = trim($_POST['oldplanvalue']);
$newname = trim($_POST['newplanvalue']);

$string .= '<table class="table_msg">';
$string .= '<tr><th colspan=2>'.$lang_conv->fetch_word("RESULT").'</th></tr>';
if(strcmp($newname,$oldname) == 0){
	$string .= '<tr><td colspan=2 align=center>';
	$string .= $common_obj->display_message($lang_conv->fetch_word("SAMEPLANNAME")."!!",0);
	$string .='</td></tr>'; 
}else if($common_obj->isValid_FileName($newname)){
	$string .= '<tr><td colspan=2 >';
	$string .= $common_obj->display_message($lang_conv->fetch_word("PLAN_NOTEMPTY")." 0-9,a-z,.,_",0);
	$string .='</td></tr>'; 
}else if($common_obj->isConfigFileExist($newname)){ 
	$string .= '<tr><td colspan=2 align=center>';
$string .= $common_obj->display_message($lang_conv->fetch_word("PLAN_EXITS")." !!",0);
	$string .='</td></tr>'; 
}else{
	$confresult=$server->renameConf($oldname,$newname) ;
	foreach($confresult as $key){
	$string .= '<tr><td colspan=2 align=center>';
		$string .= $common_obj->display_message($key,1).''; 
	$string .='</td></tr>'; 
	}
	$string .= $common_obj->display_message($oldname.' '.$lang_conv->fetch_word("PLANRENAMED").' '.$newname,1);
}
}

if(strlen($newname)>64){
	$newname = "";
}
$lines = file($SYS_CONFIG_DIR.'/vpsconflist');
$noPlans = 0;
foreach ($lines as $line) {
	$noPlans = 1;
	break;
}
if($noPlans > 0){
?>
<div class="plans_sub_header_left"></div>
<div id="plans_sub_header" class="plans_sub_header">
<?php echo $lang_conv->fetch_word("RENAMEPLAN")?></div>
<div class="plans_sub_header_right"></div>

<div id="plans_sub_div" class="plans_sub_div"><br>

<div class="renameplan_subhead"> <?php echo $lang_conv->fetch_word("SELECT_PLAN")?></div>
<form id="renameplan_form" name="renameplan_form" method="POST" onsubmit="return false">
<div class="renameplan_dropdown">

  <select name="oldplanvalue" id="oldplanvalue"  
  onchange="javascript:document.getElementById('newplanvalue').value='';clearErrorMessage()">
   <?php    	
	foreach ($lines as $line) {
		echo  "<option value=\"$line\">$line</option>";
	}
	?>
  </select>
  
</div>
<div class="renameplan_text_subhead"><?php echo $lang_conv->fetch_word("ENTER_NEW_PLAN_NAME")?></div>

<div class="renameplan_text">
    
  <input type="text" id="newplanvalue" name="newplanvalue" value="<?php echo $newname;?>" maxlength=20/>  
  
</div>
<div class="renameplan_btn">

  <a href="javascript:void(0);" class="buttonstyle" onclick="doRenamePlan();">
  <?php echo $lang_conv->fetch_word("RENAMEPLAN") ?>
    </a>  
  
</div><br>
<div class="renameplan_message_style" id="message" >
<?php

} else {
	$string = '<font class="norecords_plans" >&nbsp;<center>'.
				 '<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.
				 $lang_conv->fetch_word("PLZCREATE_PLAN").'</b></center></font>';	
}
print $string;
?>
</div>
</form>  
</div>
