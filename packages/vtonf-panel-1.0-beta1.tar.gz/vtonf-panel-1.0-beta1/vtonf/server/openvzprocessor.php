<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the OpenVz processor Information.
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
$val = $server->openvz_processor();
$value = '';

$value .= '<div class="openvz_sub_header_left"></div>'.'<div id="openvz_sub_header" class="openvz_sub_header">'.$lang_conv->fetch_word("OPENVZ_PROCESSOR").'</div><div class="openvz_sub_header_pro_right"></div>
<div id="openvz_sub_div" class="openvz_sub_div"><br>';

$value .= '<div class="ovzproc_div">';
$value .= '<table class="ovzproc_table">';
$value .= '<tr>';
$value .= '<th>';
$value .= ''.$lang_conv->fetch_word("TYPE");
$value .= '</th>';
$value .= '<th>';
$value .= ''.$lang_conv->fetch_word("VALUE");
$value .= '</th>';
$value .= '</tr>';

foreach ($val as $key) {
    $key = spliti(":", $key);
    $value .= '<tr>';
    $value .= '<td>';
    $value .= ''.$key[0];
    $value .= '</td>';
    $value .= '<td>';
    $value .= ''.$key[1];
    $value .= '</td>';
    $value .= '</tr>';

}

$value .= '</table>';
$value .= '</div>';

$value .= '</div>';
print $value;
?> 


