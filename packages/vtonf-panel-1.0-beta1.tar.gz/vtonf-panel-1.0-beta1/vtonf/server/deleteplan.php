<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the delete plan page
	*
	*/

include ('../services/checksession.php');
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');
$string = '';
$string1 = '';

if (isset ($_POST['deleteplan_value'])) {

    $planname = trim($_POST['deleteplan_value']);

    $planInUse = 1;

    $lines = file($SYS_CONFIG_DIR.'/veidvsostemplate');

    foreach ($lines as $line) {
        list ($veid, $os, $pln) = split(':', $line);

        if (!strcmp(trim($pln), trim($planname))) {
            $planInUse = 0;
            break;
        }
    }
    $string1 .= '<table class="table_msg">';
    $string1 .= '<tr><th colspan=2>'.$lang_conv->fetch_word("RESULT").'</th></tr>';

    if ($planInUse) {
        $string = $server->deleteConf($planname);
        foreach ($string as $i) {
            $string1 .= '<tr><td>';
            $string1 .= $common_obj->display_message($i, 1);
            ;
            $string1 .= '</td></tr>';
        }
        $string1 .= '<tr><td>';
        $string1 .= $common_obj->display_message($lang_conv->fetch_word("DELETEDPLAN"), 1).' '.
        $common_obj->display_message($planname, 1);
        $string1 .= '</td></tr>';
    } else {
        $string1 .= '<tr><td align=center>';
        $string1 .= $common_obj->display_message($lang_conv->fetch_word("PLANINUSE"), 0);
        $string1 .= '</td></tr>';
    }
    $string1 .= '</table>';
}

$lines = file($SYS_CONFIG_DIR.'/vpsconflist');

$noPlans = 0;
foreach ($lines as $line) {
    $noPlans = 1;
    break;
}
if ($noPlans > 0) {
?>
<div class="plans_sub_header_left"></div>
<div id="plans_sub_header" class="plans_sub_header">
<?php echo $lang_conv->fetch_word("DELETEPLAN")?></div>
<div class="plans_sub_header_right"></div>

<div id="plans_sub_div" class="plans_sub_div"><br>

<div class="delete_plan_subhead">
<?php echo $lang_conv->fetch_word("SELECT_PLAN")?> </div>
<form id="deleteplan_form" name="deleteplan_form" method="POST" 
onsubmit="return false">

<div class="delete_plan_dropdown">

  <select id="deleteplan_value" name="deleteplan_value"  onchange="clearErrorMessage()">
  <?php

    foreach ($lines as $line) {
        echo "<option value=\"$line\">$line</option>";
    }
?>
  </select>
  
</div>
<div class="deleteplan_btn">

  <a href="javascript:void(0);" class="buttonstyle" onclick="doDeletePlan();">
  <?php echo $lang_conv->fetch_word("DELETEPLAN")?>
  </a>   
  
</div>
<div class="deleteplan_message_style"  id="message">
<?php


} else {
    $string1 = '<font class="norecords_plans" >&nbsp;<center>'.'<b>'.
    $lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.
    $lang_conv->fetch_word("PLZCREATE_PLAN").'</b></center></font>';
}
print $string1;
?>
</div>
</div>
</div>