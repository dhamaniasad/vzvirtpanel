<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the plans menu items
	*
	*/
	
 
include('../services/checksession.php');
include('../common/lang_conversion.php');

?>
<div class="plans_header_left"></div>
<div class="plans_header" ><?php echo $lang_conv->fetch_word("PLANS")?></div>
<div class="plans_header_right"></div>

<div class="plans_bheader" id="icon_set">


<a href="javascript:void(0);" onclick="javascript:doSetNote('EasyWZD');
javascript:show_data('../server/easywizard.php','plans_details');" 
onmouseover="doUpdateNotes('EasyWZD','enter')" onmouseout="doUpdateNotes('General','exit')">

	<div id="easy_wizard_icon" class="easy_wizard_icon">
		<input src="image/easy_wizard.jpg" height="43" type="image" width="47">
	</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('ADVANCEDPLANWIZARD');
javascript:show_data('../server/advancedwizard.php','plans_details');"
 onmouseover="doUpdateNotes('ADVANCEDPLANWIZARD','enter')" onmouseout="doUpdateNotes('General','exit')">

<div id="adv_wzd_icon" class="adv_wzd_icon">
		<input src="image/adv_wzd.jpg" height="43" type="image" width="47">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('EDITEASYPLAN');
javascript:show_edit_plans_data('../server/editplan.php','easy');"
 onmouseover="doUpdateNotes('EDITEASYPLAN','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="editplan_icon" class="editplan_icon">
		<input src="image/editplan.jpg" height="43" type="image" width="47">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('EDITADVPLAN');
javascript:show_edit_plans_data('../server/editplan.php','adv');"
 onmouseover="doUpdateNotes('EDITADVPLAN','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="editadvplan_icon" class="editadvplan_icon">
		<input src="image/editadvplan.jpg" height="43" type="image" width="47">
</div>

</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('DeletePlan');
javascript:show_data('../server/deleteplan.php','plans_details');"
 onmouseover="doUpdateNotes('DeletePlan','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="deleteplan_icon" class="deleteplan_icon">
		<input src="image/deleteplan.jpg" height="43" type="image" width="47">
</div>

</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('RenamePlan');
javascript:show_data('../server/renameplan.php','plans_details');"
 onmouseover="doUpdateNotes('RenamePlan','enter')" onmouseout="doUpdateNotes('General','exit')">
<div id="renameplan_icon" class="renameplan_icon">
		<input src="image/renameplan.jpg" height="43" type="image" width="47">
</div>
</a>
<?php

$lang_conv = new language_map();
?>

<div class="easywzd_name"><?php echo $lang_conv->fetch_word('EasyWZD');?> </div>
<div class="advwzd_name"><?php echo $lang_conv->fetch_word('ADVANCEDPLANWIZARD');?></div>
<div class="editplan_name"><?php echo $lang_conv->fetch_word('EDITEASYPLAN');?> </div>
<div class="editadvplan_name"><?php echo $lang_conv->fetch_word('EDITADVPLAN');?> </div>
<div class="deleteplan_name"><?php echo $lang_conv->fetch_word('DeletePlan');?> </div>
<div class="renameplan_name"><?php echo $lang_conv->fetch_word('RenamePlan');?> </div>

<div class="plans_details" id="plans_details">
</div>
</div>
