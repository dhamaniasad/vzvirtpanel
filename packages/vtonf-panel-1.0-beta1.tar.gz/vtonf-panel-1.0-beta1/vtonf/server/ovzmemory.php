<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the OpenVz Memory Information.
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');

$val = $server->openvz_memory();
$value = '';
$value .= '<div class="openvz_sub_header_left"></div><div id="openvz_sub_header" class="openvz_sub_header">'.$lang_conv->fetch_word("OPENVZ_MEMORY").'</div><div class="openvz_sub_header_mem_right"></div>
<div id="openvz_sub_div" class="openvz_sub_div"><br>';

$memTotal = $val[0];
$memFree = $val[1];
$swapTotal = $val[11];
$swapFree = $val[12];
$buffers = $val[2];
$cached = $val[3];
$swapCached = $val[4];
$active = $val[5];
$inactive = $val[6];

$line1t = spliti(":", $memTotal);
$line2t = spliti(":", $memFree);
$line3t = spliti(":", $swapTotal);
$line4t = spliti(":", $swapFree);
$line5t = spliti(":", $buffers);
$line6t = spliti(":", $cached);
$line7t = spliti(":", $swapCached);
$line8t = spliti(":", $active);
$line9t = spliti(":", $inactive);

$line1 = array ();
$line2 = array ();
$line3 = array ();
$line4 = array ();
$line5 = array ();
$line6 = array ();
$line7 = array ();
$line8 = array ();
$line9 = array ();

$j = 0;
for ($i = 0; $i < count($line1t); $i ++) {
    if (strcasecmp(trim($line1t[$i]), '') != 0) {
        $line1[$j] = $lang_conv->fetch_word(strtoupper(trim($line1t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line2t); $i ++) {
    if (strcasecmp(trim($line2t[$i]), '') != 0) {
        $line2[$j] = $lang_conv->fetch_word(strtoupper(trim($line2t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line3t); $i ++) {
    if (strcasecmp(trim($line3t[$i]), '') != 0) {
        $line3[$j] = $lang_conv->fetch_word(strtoupper(trim($line3t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line4t); $i ++) {
    if (strcasecmp(trim($line4t[$i]), '') != 0) {
        $line4[$j] = $lang_conv->fetch_word(strtoupper(trim($line4t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line5t); $i ++) {
    if (strcasecmp(trim($line5t[$i]), '') != 0) {
        $line5[$j] = $lang_conv->fetch_word(strtoupper(trim($line5t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line6t); $i ++) {
    if (strcasecmp(trim($line6t[$i]), '') != 0) {
        $line6[$j] = $lang_conv->fetch_word(strtoupper(trim($line6t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line7t); $i ++) {
    if (strcasecmp(trim($line7t[$i]), '') != 0) {
        $line7[$j] = $lang_conv->fetch_word(strtoupper(trim($line7t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line8t); $i ++) {
    if (strcasecmp(trim($line8t[$i]), '') != 0) {
        $line8[$j] = $lang_conv->fetch_word(strtoupper(trim($line8t[$i])));
        $j ++;
    }
}

$j = 0;
for ($i = 0; $i < count($line9t); $i ++) {
    if (strcasecmp(trim($line9t[$i]), '') != 0) {
        $line9[$j] = $lang_conv->fetch_word(strtoupper(trim($line9t[$i])));
        $j ++;
    }
}

$usedMem = $line1[1] - $line2[1];

$lineUsedMem[0] = $lang_conv->fetch_word("MEMUSED");
$lineUsedMem[1] = $common_obj->convert_kb_mb($usedMem."KB");

$usedSwap = $line3[1] - $line4[1];
$lineUsedSwap[0] = $lang_conv->fetch_word("SWAPUSED");
$lineUsedSwap[1] = $common_obj->convert_kb_mb($usedSwap."KB");

$line1[1] = $common_obj->convert_kb_mb($line1[1]);
$line2[1] = $common_obj->convert_kb_mb($line2[1]);
$line3[1] = $common_obj->convert_kb_mb($line3[1]);
$line4[1] = $common_obj->convert_kb_mb($line4[1]);
$line5[1] = $common_obj->convert_kb_mb($line5[1]);
$line6[1] = $common_obj->convert_kb_mb($line6[1]);
$line7[1] = $common_obj->convert_kb_mb($line7[1]);
$line8[1] = $common_obj->convert_kb_mb($line8[1]);
$line9[1] = $common_obj->convert_kb_mb($line9[1]);

$value .= '<div class="ovzmem_div">';
$value .= '<table class="ovzmem_table">';

$value .= '<tr>';
$value .= '<th>';
$value .= $lang_conv->fetch_word("TYPE");
$value .= '</th>';
$value .= '<th>';
$value .= $lang_conv->fetch_word("VALUE");
$value .= '</th>';
$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line1[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line1[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line2[0];
$value .= '</td>';

$value .= '<td>';
$value .= $line2[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$lineUsedMem[0];
$value .= '</td>';

$value .= '<td>';
$value .= $lineUsedMem[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line3[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line3[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line4[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line4[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$lineUsedSwap[0];
$value .= '</td>';

$value .= '<td>';
$value .= $lineUsedSwap[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line5[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line5[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line6[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line6[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line7[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line7[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line8[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line8[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '<tr>';
$value .= '<td>';
$value .= ''.$line9[0];
$value .= '</td>';

$value .= '<td>';
$value .= ''.$line9[1];
$value .= '</td>';

$value .= '</tr>';

$value .= '</table>';
$value .= '<font class="smallfont">* '.$lang_conv->fetch_word("ALLFIELDSMB").'</font>';
$value .= '</div>';
//$value .= '</div>';

print $value;

//code below is newly added 

$memtot = split(" kB", trim($line1t[1]));
$memfree = split(" kB", trim($line2t[1]));
$swaptot = split(" kB", trim($line3t[1]));
$swapfree = split(" kB", trim($line4t[1]));

$memtot = trim($memtot[0]);
$memfree = trim($memfree[0]);
$swaptot = trim($swaptot[0]);
$swapfree = trim($swapfree[0]);

$GET1["disk_values"] = '';
$GET2["disk_labels"] = '';
$value1 .= '<div class="ovzmem_pie_div">';
$value1 .= '<table class="ovzhdd">';
$value1 .= '<tr>';
$value1 .= '<th colspan=2 >';
$value1 .= ''.$lang_conv->fetch_word("TYPE");
$value1 .= '</th>';

$value1 .= '<th  >';
$value1 .= ''.$lang_conv->fetch_word("PARTITION_GRAPH");
$value1 .= '</th>';

$value1 .= '<th colspan=3 >';
$value1 .= ''.$lang_conv->fetch_word("PARTITION_INFO");
$value1 .= '</th>';
$value1 .= '</tr>';
$row = 0;

$value1 .= '<tr>';
$value1 .= '<td colspan=2 >';
$value1 .= 'RAM';
$value1 .= '</td>';
$value1 .= '<td >';
$availpercentage = intval(($memfree / $memtot) * 100);
$usedpercentage = (100 - $availpercentage);
$GET1["disk_values"] = $usedpercentage.'*'.$availpercentage;
$GET2["disk_labels"] = $lang_conv->fetch_word("USED").'*'.$lang_conv->fetch_word("AVAILABLE");

if ($usedpercentage > 90) {
    $col1 = "FF130B"; //if greater than 90% showing in RED 
    $col2 = "3415FF"; //if greater than 90% showing in BLUE 
} else {
    $col1 = "23C8FF";
    $col2 = "003466";
}

$value1 .= '<img src="../server/piechart.php?'.'disk_values='.$GET1["disk_values"].'&disk_labels='.$GET2["disk_labels"].'&col1='.$col1.'&col2='.$col2.'"/>';
$value1 .= '</td>';
$value1 .= '<td colspan=3 >';

$value1 .= $lang_conv->fetch_word("TOTAL_SPACE").' - '.$common_obj->convert_kb_mb($memtot."KB").'<br>';
$value1 .= $lang_conv->fetch_word("USED_SPACE").'  - '.$common_obj->convert_kb_mb(($memtot - $memfree)."KB").'<br>';
$value1 .= $lang_conv->fetch_word("FREE_SPACE").'  - '.$common_obj->convert_kb_mb($memfree."KB").'<br>';
$value1 .= '</td>';
$value1 .= '</tr>';
//$common_obj->convert_kb_mb($usedSwap."KB");
//----------------------	
$value1 .= '<tr>';
$value1 .= '<td colspan=2 >';
$value1 .= 'SWAP';
$value1 .= '</td>';
$value1 .= '<td >';
$availpercentage = intval(($swapfree / $swaptot) * 100);
$usedpercentage = (100 - $availpercentage);
$GET1["disk_values"] = $usedpercentage.'*'.$availpercentage;
$GET2["disk_labels"] = $lang_conv->fetch_word("USED").'*'.$lang_conv->fetch_word("AVAILABLE");

if ($usedpercentage > 90) {
    $col1 = "FF130B"; //if greater than 90% showing in RED 
    $col2 = "3415FF"; //if greater than 90% showing in BLUE 
} else {
    $col1 = "23C8FF";
    $col2 = "003466";
}

$value1 .= '<img src="../server/piechart.php?'.'disk_values='.$GET1["disk_values"].'&disk_labels='.$GET2["disk_labels"].'&col1='.$col1.'&col2='.$col2.'"/>';
$value1 .= '</td>';
$value1 .= '<td colspan=3 >';

$value1 .= $lang_conv->fetch_word("TOTAL_SPACE").' - '.$common_obj->convert_kb_mb($swaptot."KB").'<br>';
$value1 .= $lang_conv->fetch_word("USED_SPACE").'  - '.$common_obj->convert_kb_mb(($swaptot - $swapfree)."KB").'<br>';
$value1 .= $lang_conv->fetch_word("FREE_SPACE").'  - '.$common_obj->convert_kb_mb($swapfree."KB").'<br>';
$value1 .= '</td>';
$value1 .= '</tr>';

$value1 .= '</table>';
$value1 .= '<font class="error_msg">&#8226;</font><font class="small_font">'.$lang_conv->fetch_word("INDICATE_RAM").' 90%</font>';
$value1 .= '</div>';
$value1 .= '</div>';
$_POST['rand'] = ''.rand(10000);
print $value1;
?>

