<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
	* This file is used to save the 
	* configuration or plan.
	*
	*/

include ('../services/checksession.php');
include ('../common/common_function.php');
include_once ('../common/lang_conversion.php');

$string = '';
$valid = 0;
$planType = $_POST['planType'];
$planaction = $_POST['planaction'];

$string .= '<table class="table_msg">';
$string .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';

if ($planType == 'easy') {
    $valid = 0;
    include ('../lib/confvalues.php');
    if ($_POST['planaction'] == 'edit') {
        $CONFIGURATIONNAME = $_SESSION["CONFIGURATIONNAME"];
    } else {
        $CONFIGURATIONNAME = trim($_POST['planname_value']);
        $_SESSION['CONFIGURATIONNAME'] = $CONFIGURATIONNAME;
    }
    $PRIVVMPAGES_SOFT = trim($_POST['disk_value']);
    $_SESSION['DISKSPACE_SOFT'] = $PRIVVMPAGES_SOFT; //Disk space
    $PRIVVMPAGES_HARD = trim($_POST['disk_value']);
    $_SESSION['DISKSPACE_HARD'] = $PRIVVMPAGES_HARD;
    $MEMINFO_SOFT = trim($_POST['memory_vlaue']); // RAM
    $_SESSION['PRIVVMPAGES_SOFT'] = $MEMINFO_SOFT;
    $MEMINFO_HARD = trim($_POST['memory_vlaue']);
    $_SESSION['PRIVVMPAGES_HARD'] = $MEMINFO_HARD;
    $NAMESERVER = trim($_POST['nameserver_value']);
    $_SESSION['NAMESERVER'] = $NAMESERVER;
    $stringt = '';
    $memoryType = $_POST['memory_type'];
    $diskType = $_POST['disk_type'];

    if ($common_obj->is_ValidNumeric($_SESSION['PRIVVMPAGES_SOFT'], $memoryType)) {
        $stringt .= " ".$common_obj->display_message($lang_conv->fetch_word("MEM_NOTEMPTY"), 0);
    } else if ($common_obj->is_ValidNumeric($_SESSION['DISKSPACE_HARD'], $diskType)) {
        $stringt .= "".$common_obj->display_message($lang_conv->fetch_word("DISK_NOTEMPTY"), 0);
    } else if ($common_obj->isValid_NameServer($_SESSION['NAMESERVER'])) {
		$stringt = $lang_conv->fetch_word("NS_NOTEMPTY")." <b>ex:[1-255].[0-255].[0-255].[0-255]</b>";
        $stringt = $common_obj->display_message($stringt, 0);
   	} else if ($common_obj->isValid_FileName($CONFIGURATIONNAME)) {
		$stringt = $lang_conv->fetch_word("PLAN_NOTEMPTY")." 0-9,a-z,.,_";
		$stringt = $common_obj->display_message($stringt, 0);
	} else if (!($_POST['planaction'] == 'edit') && $common_obj->isConfigFileExist($CONFIGURATIONNAME)) {
		$stringt = $lang_conv->fetch_word("PLAN_EXITS")." !!";
		$stringt = $common_obj->display_message($stringt, 0);
	} else {
		$memory = intval($_SESSION['PRIVVMPAGES_SOFT']);
        if ($memoryType == 'MB') {
			$memvalue = 1024.0;
		} else {
			$memvalue = 1024.0 * 1024.0;
		}
        $mem = $memory * $memvalue / 4;
        $mem = sprintf("%.0f", $mem);
        $_SESSION['PRIVVMPAGES_SOFT'] = $mem;
        $_SESSION['PRIVVMPAGES_HARD'] = $mem;

        /*Disk calculation*/

		if ($diskType == 'MB') {
        	$diskvalue = 1024.0;
		} else {
        	$diskvalue = 1024.0 * 1024.0;
		}

        $disk = intval($_SESSION['DISKSPACE_HARD']);
        $disk = $diskvalue * $disk;
        $disk = sprintf("%.0f", $disk);
        $_SESSION['DISKSPACE_HARD'] = $disk;
        $_SESSION['DISKSPACE_SOFT'] = $disk;
        $diskcomp = 1048576;
        $memcmp = 32768;
		$valid = 1;

	}
    if ($valid == 0) {
        $string .= '<tr><td>';
        $string .= $common_obj->display_message($stringt, 0);
        $string .= '</td></tr>';
    } else {
        $string .= save_confFile($CONFIGURATIONNAME);
    }

} else {
    $_SESSION['NUMFILE_SOFT'] = trim($_POST['NUMFILE_SOFT']);
    $_SESSION['NUMFILE_HARD'] = trim($_POST['NUMFILE_HARD']);
    $_SESSION['DCACHESIZE_SOFT'] = trim($_POST['DCACHESIZE_SOFT']);
    $_SESSION['DCACHESIZE_HARD'] = trim($_POST['DCACHESIZE_HARD']);
    $_SESSION['NUMIPTENT_SOFT'] = trim($_POST['NUMIPTENT_SOFT']);
    $_SESSION['NUMIPTENT_HARD'] = trim($_POST['NUMIPTENT_HARD']);
    $_SESSION['AVNUMPROC_SOFT'] = trim($_POST['AVNUMPROC_SOFT']);
    $_SESSION['AVNUMPROC_HARD'] = trim($_POST['AVNUMPROC_HARD']);
    $_SESSION['MEMINFO_HARD'] = trim($_POST['MEMINFO_HARD']);
    $_SESSION['DISKSPACE_SOFT'] = trim($_POST['DISKSPACE_SOFT']);
    $_SESSION['DISKSPACE_HARD'] = trim($_POST['DISKSPACE_HARD']);
    $_SESSION['DISKINODES_SOFT'] = trim($_POST['DISKINODES_SOFT']);
    $_SESSION['DISKINODES_HARD'] = trim($_POST['DISKINODES_HARD']);
    $_SESSION['CPUUNITS'] = trim($_POST['CPUUNITS']);
    $_SESSION['QUOTATIME'] = trim($_POST['QUOTATIME']);
    $_SESSION['QUOTAUGIDLIMIT'] = trim($_POST['QUOTAUGIDLIMIT']);

    $_SESSION['CPULIMIT'] = trim($_POST['CPULIMIT']);
    $_SESSION['NAMESERVER'] = trim($_POST['NAMESERVER']);

    $postvars = $_POST;

    foreach ($_POST as $key => $value) {
        if (strlen($value) > 100) {
            $_SESSION[$key] = "";
        }
    }

    if (($_POST['planaction'] != 'edit')) {
        $_SESSION['CONFIGURATIONNAME'] = trim($_POST['CONFIGURATIONNAME']);
    }
}

if ($planType != 'easy') {
		$valid = 0 ;
				$stringt = '';
			if($common_obj->is_InRange($_SESSION['KMEMSIZE_SOFT'],$_SESSION['KMEMSIZE_HARD'])){ 	
				$stringt = "KMEMSIZE  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
				
			}else if($common_obj->is_InRange($_SESSION['LOCKEDPAGES_SOFT'],$_SESSION['LOCKEDPAGES_HARD'])){ 
				$stringt .=  "LOCKEDPAGES  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
				
			}else if($common_obj->is_InRange($_SESSION['PRIVVMPAGES_SOFT'],$_SESSION['PRIVVMPAGES_HARD'])){ 
				$stringt .=  "PRIVVMPAGES ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
				
			}else if($common_obj->is_InRange($_SESSION['SHMPAGES_SOFT'],$_SESSION['SHMPAGES_HARD'])){							
	 			$stringt .=  "SHMPAGES ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMPROC_SOFT'],$_SESSION['NUMPROC_HARD'])){
				$stringt .=  "NUMPROC  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");				 
			}else if($common_obj->is_InRange($_SESSION['PHYSPAGES_SOFT'],$_SESSION['PHYSPAGES_HARD'])){			
				$stringt .=  "PHYSPAGES  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");								
			}else if($common_obj->is_InRange($_SESSION['VMGUARPAGES_SOFT'],$_SESSION['VMGUARPAGES_HARD'])){
				$stringt .=  "VMGUARPAGES ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");				 
			}else if($common_obj->is_InRange($_SESSION['OOMGUARPAGES_SOFT'],$_SESSION['OOMGUARPAGES_HARD'])){
				$stringt .=  "OOMGUARPAGES  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMTCPSOCK_SOFT'],$_SESSION['NUMTCPSOCK_HARD'])){
				$stringt .=  "NUMTCPSOCK  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMFLOCK_SOFT'],$_SESSION['NUMFLOCK_HARD'])){
				$stringt .=  "NUMFLOCK  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMPTY_SOFT'],$_SESSION['NUMPTY_HARD'])){
				$stringt .=  "NUMPTY  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMSIGINFO_SOFT'],$_SESSION['NUMSIGINFO_HARD'])){
				$stringt .=  "NUMSIGINFO ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['TCPSNDBUF_SOFT'],$_SESSION['TCPSNDBUF_HARD'])){
				$stringt .=  "TCPSNDBUF  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['TCPRCVBUF_SOFT'],$_SESSION['TCPRCVBUF_HARD'])){
				$stringt .=  "TCPRCVBUF  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['OTHERSOCKBUF_SOFT'],$_SESSION['OTHERSOCKBUF_HARD'])){ 
				$stringt .=  "OTHERSOCKBUF ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['DGRAMRCVBUF_SOFT'],$_SESSION['DGRAMRCVBUF_HARD'])){
				$stringt .=  "DGRAMRCVBUF  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMOTHERSOCK_SOFT'],$_SESSION['NUMOTHERSOCK_HARD'])){
				$stringt .=  "NUMOTHERSOCK  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMFILE_SOFT'],$_SESSION['NUMFILE_HARD'])){
				$stringt .=  "NUMFILE ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['DCACHESIZE_SOFT'],$_SESSION['DCACHESIZE_HARD'])){
				$stringt .=  "DCACHESIZE  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['NUMIPTENT_SOFT'],$_SESSION['NUMIPTENT_HARD'])){
				$stringt .=  "NUMIPTENT  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['AVNUMPROC_SOFT'],$_SESSION['AVNUMPROC_HARD'])){
				$stringt .=  "AVNUMPROC  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if(!($_SESSION['MEMINFO_HARD'] <= 1 && $_SESSION['MEMINFO_HARD'] != '')){ 
				$stringt .=  "MEMINFO  ".$lang_conv->fetch_word("MUSTZEROONE");
			}else if($common_obj->is_InRange($_SESSION['DISKSPACE_SOFT'],$_SESSION['DISKSPACE_HARD'])){
				$stringt .=  "DISKSPACE  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if($common_obj->is_InRange($_SESSION['DISKINODES_SOFT'],$_SESSION['DISKINODES_HARD'])){
				$stringt .=  "DISKINODES  ".$lang_conv->fetch_word("COUNDNOTBEEMPTY");
			}else if(!($_SESSION['CPUUNITS'] >= 1000 && $_SESSION['CPUUNITS'] < 2000 && $_SESSION['CPUUNITS'] != '')){ 
				$stringt .=  "CPUUNITS ".$lang_conv->fetch_word("VALIDRANGE");
			}else if(!($_SESSION['QUOTATIME'] <= 1  && $_SESSION['QUOTATIME'] != '')){ 
				$stringt .=  "QUOTATIME ".$lang_conv->fetch_word("MUSTZEROONE");
			}else if(!($_SESSION['QUOTAUGIDLIMIT'] <= 1 && $_SESSION['QUOTAUGIDLIMIT'] != '')){ 
				$stringt .=  "QUOTAUGIDLIMIT ".$lang_conv->fetch_word("MUSTZEROONE");
			}else if(!($_SESSION['CPULIMIT'] <= 1 && $_SESSION['CPULIMIT'] != '')){
				$stringt .=  "CPULIMIT ".$lang_conv->fetch_word("MUSTZEROONE");
			}else if($common_obj->isValid_NameServer($_SESSION['NAMESERVER'])){
				 $stringt .= "".$lang_conv->fetch_word("NS_NOTEMPTY")." <b>ex:[1-255].[0-255].[0-255].[0-255]</b>";
			}else if(($common_obj->isValid_FileName($_SESSION['CONFIGURATIONNAME']))){ 
				$stringt .= $lang_conv->fetch_word("PLAN_NOTEMPTY")." 0-9,a-z,.,_";				
			}else if( !($_POST['planaction']=='edit') && $common_obj->isConfigFileExist($_SESSION['CONFIGURATIONNAME'])){ 
				$stringt .= $lang_conv->fetch_word("PLAN_EXITS")." !!";
			}else{					
				$valid = 1;
			}	
			if($valid == 1){				
				$string .=  save_confFile($_SESSION['CONFIGURATIONNAME']);
			}else{
				$string .= '<tr><td >';
				$string .= $common_obj->display_message($stringt,0);
				$string .= '</td></tr >';
			}
}
$string .= '</table>';
print $string;

/**
	* save_confFile is used to 
	* write the configiration file in the path specified
	*
	* @param     $CONFIGURATIONNAME is the file name
	* @return    none
	*
	*/

function save_confFile($CONFIGURATIONNAME) {
    include ('../include/config.php');
    include_once ('../lib/server.php');
    $server = new server();
    include_once ('../common/common_function.php');

    $string1 = '';
    $file_path = $_CONF_PATH.$CONFIGURATIONNAME;
    $CONF_FILE = fopen($file_path, 'w');

    fwrite($CONF_FILE, "KMEMSIZE"."=\"".$_SESSION['KMEMSIZE_SOFT'].":".$_SESSION['KMEMSIZE_HARD']."\""."\n");
    fwrite($CONF_FILE, "LOCKEDPAGES"."=\"".$_SESSION['LOCKEDPAGES_SOFT'].":".$_SESSION['LOCKEDPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "PRIVVMPAGES"."=\"".$_SESSION['PRIVVMPAGES_SOFT'].":".$_SESSION['PRIVVMPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "SHMPAGES"."=\"".$_SESSION['SHMPAGES_SOFT'].":".$_SESSION['SHMPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMPROC"."=\"".$_SESSION['NUMPROC_SOFT'].":".$_SESSION['NUMPROC_HARD']."\""."\n");
    fwrite($CONF_FILE, "PHYSPAGES"."=\"".$_SESSION['PHYSPAGES_SOFT'].":".$_SESSION['PHYSPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "VMGUARPAGES"."=\"".$_SESSION['VMGUARPAGES_SOFT'].":".$_SESSION['VMGUARPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "OOMGUARPAGES"."=\"".$_SESSION['OOMGUARPAGES_SOFT'].":".$_SESSION['OOMGUARPAGES_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMTCPSOCK"."=\"".$_SESSION['NUMTCPSOCK_SOFT'].":".$_SESSION['NUMTCPSOCK_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMFLOCK"."=\"".$_SESSION['NUMFLOCK_SOFT'].":".$_SESSION['NUMFLOCK_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMPTY"."=\"".$_SESSION['NUMPTY_SOFT'].":".$_SESSION['NUMPTY_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMSIGINFO"."=\"".$_SESSION['NUMSIGINFO_SOFT'].":".$_SESSION['NUMSIGINFO_HARD']."\""."\n");
    fwrite($CONF_FILE, "TCPSNDBUF"."=\"".$_SESSION['TCPSNDBUF_SOFT'].":".$_SESSION['TCPSNDBUF_HARD']."\""."\n");
    fwrite($CONF_FILE, "TCPRCVBUF"."=\"".$_SESSION['TCPRCVBUF_SOFT'].":".$_SESSION['TCPRCVBUF_HARD']."\""."\n");
    fwrite($CONF_FILE, "OTHERSOCKBUF"."=\"".$_SESSION['OTHERSOCKBUF_SOFT'].":".$_SESSION['OTHERSOCKBUF_HARD']."\""."\n");
    fwrite($CONF_FILE, "DGRAMRCVBUF"."=\"".$_SESSION['DGRAMRCVBUF_SOFT'].":".$_SESSION['DGRAMRCVBUF_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMOTHERSOCK"."=\"".$_SESSION['NUMOTHERSOCK_SOFT'].":".$_SESSION['NUMOTHERSOCK_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMFILE"."=\"".$_SESSION['NUMFILE_SOFT'].":".$_SESSION['NUMFILE_HARD']."\""."\n");
    fwrite($CONF_FILE, "DCACHESIZE"."=\"".$_SESSION['DCACHESIZE_SOFT'].":".$_SESSION['DCACHESIZE_HARD']."\""."\n");
    fwrite($CONF_FILE, "NUMIPTENT"."=\"".$_SESSION['NUMIPTENT_SOFT'].":".$_SESSION['NUMIPTENT_HARD']."\""."\n");
    fwrite($CONF_FILE, "AVNUMPROC"."=\"".$_SESSION['AVNUMPROC_SOFT'].":".$_SESSION['AVNUMPROC_HARD']."\""."\n");
    fwrite($CONF_FILE, "MEMINFO"."=\"".$_SESSION['MEMINFO_SOFT'].":".$_SESSION['MEMINFO_HARD']."\""."\n");
    fwrite($CONF_FILE, "DISKSPACE"."=\"".$_SESSION['DISKSPACE_SOFT'].":".$_SESSION['DISKSPACE_HARD']."\""."\n");
    fwrite($CONF_FILE, "DISKINODES"."=\"".$_SESSION['DISKINODES_SOFT'].":".$_SESSION['DISKINODES_HARD']."\""."\n");
    fwrite($CONF_FILE, "CPUUNITS"."=\"".$_SESSION['CPUUNITS']."\""."\n");
    fwrite($CONF_FILE, "QUOTATIME"."=\"".$_SESSION['QUOTATIME']."\""."\n");
    fwrite($CONF_FILE, "DISABLED"."=\"".$_SESSION['DISABLED']."\""."\n");
    fwrite($CONF_FILE, "ONBOOT"."=\"".$_SESSION['ONBOOT']."\""."\n");
    fwrite($CONF_FILE, "QUOTAUGIDLIMIT"."=\"".$_SESSION['QUOTAUGIDLIMIT']."\""."\n");
    fwrite($CONF_FILE, "NAMESERVER"."=\"".$_SESSION['NAMESERVER']."\""."\n");
    fwrite($CONF_FILE, "CPULIMIT"."=\"".$_SESSION['CPULIMIT']."\""."\n");
    fwrite($CONF_FILE, "VE_ROOT"."=\"".$_SESSION['VE_ROOT']."\""."\n");
    fwrite($CONF_FILE, "VE_PRIVATE"."=\"".$_SESSION['VE_PRIVATE']."\""."\n");
    fwrite($CONF_FILE, "IPTABLES"."=\"".$_SESSION['IPTABLES']."\""."\n");

    $confresult = $server->CreateConf($_SESSION['CONFIGURATIONNAME']);
    $stringt = '';
    $lang_conv = new language_map();
    $common_obj = new common_functions();
    $string1 .= '<tr><td >';
    if ($_POST['planaction'] == 'edit') {
        $stringt .= ''.$lang_conv->fetch_word("UPDATEDPLAN").' <b>'.$_SESSION['CONFIGURATIONNAME'].'</b>';
    } else {
        $stringt .= ''.$lang_conv->fetch_word("CREATEDPLAN").' <b>'.$_SESSION['CONFIGURATIONNAME'].'</b>';
    }

    $string1 .= $common_obj->display_message($stringt, 1);
    $string1 .= '</td></tr>';
    $string1 .= '<tr><td >';
    $stringt = $confresult[1];
    $string1 .= $common_obj->display_message($stringt, 1);
    $string1 .= '</td></tr>';

    return $string1;
}
?>

