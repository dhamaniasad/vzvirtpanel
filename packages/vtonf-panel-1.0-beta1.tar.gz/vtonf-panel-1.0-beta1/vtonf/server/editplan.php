 <?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the Node List for editing Plans
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');

if (isset ($_POST['edit_plan_checked'])) {
    $edit_plan_checked = trim($_POST['edit_plan_checked']);
}
$lines = file($SYS_CONFIG_DIR.'/vpsconflist');
$noPlans = 0;
foreach ($lines as $line) {
    $noPlans = 1;
    break;
}
if ($noPlans > 0) {
?>

<div class="plans_sub_header_left"></div>
<div id="plans_sub_header" class="plans_sub_header"><?php echo $lang_conv->fetch_word("EDITPLAN")?></div>
<div class="plans_sub_header_right"></div>

<div id="plans_sub_div" class="plans_sub_div">

<div class="edit_plan_subhead"><?php echo $lang_conv->fetch_word("OPENPLAN")?></div>
<form id="editplan_form" name="editplan_form" method="POST" onsubmit="return false">

<div class="edit_plan_dropdown">

  <select id="editplan_value" name="editplan_value">
  <?php


    foreach ($lines as $line) {
        echo "<option value=\"$line\">$line</option>";
    }
?>
  </select>
 </div>
  <input type="hidden" id="edit_plan_checked" name="edit_plan_checked" value="<?php echo $edit_plan_checked ?>"/>
<div class="editplan_btn" >

  <a href="javascript:void(0);" class="buttonstyle" onclick="openEditPlanPage();">
  <?php echo $lang_conv->fetch_word('OPENPLAN');?>
  </a>  
  
</div>

</div>
<?php


} else {
    $outputmsg = '<font class="norecords_plans" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_PLAN").'</b></center></font>';
    print $outputmsg;
}
?>
</form>

</div>