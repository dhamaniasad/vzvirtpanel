<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the Easy Wizard plan page
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
$string = '<div class="plans_sub_header_left"></div><div id="plans_sub_header" class="plans_sub_header">
'.$lang_conv->fetch_word("EASYWZD").'
</div><div class="plans_sub_header_right"></div>
<div id="easywzd_sub_div" class="easywzd_sub_div"><br>

  <form  method="POST" name="easywzd_form" id="easywzd_form">
  
<div class="memory_sub_head">'.$lang_conv->fetch_word("EASY_MEMORY").'
</div>
<div class="memory_text">
  <input type="text" name="memory_vlaue" id="memory_vlaue" maxlength=6/>  
</div>

<div class="memory_type">

  <select name="memory_type" id="memory_type">
    <option value="MB">MB</option>
    <option value="GB">GB</option>    
  </select> 

</div>

<div class="easy_help_buttn" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'EASY_MEMINFO\')" onmouseover="doUpdateNotes(\'EASY_MEMINFO\',\'enter\')"  
 onmouseout="doUpdateNotes(\'General\',\'exit\')">
 	<img src="image/help_butt.jpg" >
 </a>
</div>

<div class="disk_sub_head">'.$lang_conv->fetch_word("EASY_DISK").'</div>
<div class="disk_text">
  <input type="text" name="disk_value" id="disk_value" maxlength=6 value=""/>    
</div>

<div class="disk_type">

  <select name="disk_type" id="disk_type">
    <option value="MB">MB</option>
    <option value="GB">GB</option>    
  </select> 

</div>
<div class="disk_help_buttn" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'EASY_DISKSPACE\');"  
		onmouseover="doUpdateNotes(\'EASY_DISKSPACE\',\'enter\')"  
 onmouseout="doUpdateNotes(\'General\',\'exit\')">
 <img src="image/help_butt.jpg" ></a>
</div>

<div class="nameserver_sub_head">'.$lang_conv->fetch_word("EASY_NAMESERVER").'</div>
<div class="nameserver_text">
  <input type="text" name="nameserver_value" id="nameserver_value" value=""/>    
</div>

<div class="nameserver_help_buttn" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NAMESERVER\');"  
		onmouseover="doUpdateNotes(\'NAMESERVER\',\'enter\')"  
 onmouseout="doUpdateNotes(\'General\',\'exit\')">
<img src="image/help_butt.jpg"  >'.'</a>
</div>

<div class="planname_sub_head">'.$lang_conv->fetch_word("EASY_PLANNAME").'
</div>
<div class="planname_text">		
  <input type="text" name="planname_value" id="planname_value" value="" maxlength=20/>    
</div>

<div class="planname_help_buttn" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'CONFIGURATIONNAME\');" 
onmouseover="doUpdateNotes(\'CONFIGURATIONNAME\',\'enter\')" onmouseout="doUpdateNotes(\'General\',\'exit\')">
<img src="image/help_butt.jpg"  ></a>
</div>
<div class="easywzd_btn">	
  <a href="javascript:void(0);" class="buttonstyle" onclick="doAddNewPlan()">'.$lang_conv->fetch_word("CREATEPLAN").'</a>  
</div>
<input type="hidden" id="name="planaction" name="planaction" value="add"/>
  </form>
<div class="allfields_style" >	
	<b>'.$lang_conv->fetch_word("ALLFIELDS").'</b>
</div>
  <div id="message" class="easywzd_msg_style" ></div>
  
</div>';

print $string;
?>