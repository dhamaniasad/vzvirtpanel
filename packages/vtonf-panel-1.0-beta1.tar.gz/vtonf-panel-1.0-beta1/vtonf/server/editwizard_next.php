<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the next page of a Edit Advanced Wizard plan page
	*
	*/
	
include('../services/checksession.php');
include('../lib/server.php');
include('../common/lang_conversion.php');

 	$postvars = $_POST;

	foreach($_POST as $key => $value ){
 		
		if(strlen($value) < 100){
 			$_SESSION[$key] = $value;
		}else{
			$_SESSION[$key] = "";
		}
	}
	
$string ='



<div class="main_conf_2">
<div id="Layer3" class="conf_heading">'.$lang_conv->fetch_word("EDIT_ADVANCEDPLANWIZARD").'</div>

<div class="long_line"></div> 

<div class="conf_soft_heading">'.$lang_conv->fetch_word("SOFTLIMIT").'</div>' .
		'<div class="conf_hard_heading">'.$lang_conv->fetch_word("HARDLIMIT").'</div>

<form id="create_conf" name="create_conf" method="POST" onsubmit="return false">

<div id="Layer4" class="labels_listn1" >NUMFILE</div>


<div id="Layer5" class="txt_fieldn1" >

    <input id="NUMFILE_SOFT" name="NUMFILE_SOFT"  type="text" value="'.  $_SESSION['NUMFILE_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn1" >


    <input id="NUMFILE_HARD" name="NUMFILE_HARD" type="text" value="'.  $_SESSION['NUMFILE_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn1" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMFILE\');" onmouseover="doUpdateNotes(\'NUMFILE\',\'enter\')"  
onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn2" >DCACHESIZE</div>

<div id="Layer5" class="txt_fieldn2" >

    <input id="DCACHESIZE_SOFT" name="DCACHESIZE_SOFT"  type="text" value="'.  $_SESSION['DCACHESIZE_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn2" >

    <input id="DCACHESIZE_HARD" name="DCACHESIZE_HARD" type="text" value="'.  $_SESSION['DCACHESIZE_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn2" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'DCACHESIZE\');" onmouseover="doUpdateNotes(\'DCACHESIZE\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>

<div id="Layer4" class="labels_listn3" >NUMIPTENT</div>

<div id="Layer5" class="txt_fieldn3" >

    <input id="NUMIPTENT_SOFT" name="NUMIPTENT_SOFT"  type="text" value="'.  $_SESSION['NUMIPTENT_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn3" >


    <input id="NUMIPTENT_HARD" name="NUMIPTENT_HARD" type="text" value="'.  $_SESSION['NUMIPTENT_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn3" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMIPTENT\');" onmouseover="doUpdateNotes(\'NUMIPTENT\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>



<div id="Layer4"  class="labels_listn4" >AVNUMPROC</div>


<div id="Layer5" class="txt_fieldn4" >

    <input id="AVNUMPROC_SOFT" name="AVNUMPROC_SOFT"  type="text" value="'.  $_SESSION['AVNUMPROC_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn4" >


    <input id="AVNUMPROC_HARD" name="AVNUMPROC_HARD" type="text" value="'.  $_SESSION['AVNUMPROC_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn4" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'AVNUMPROC\');" onmouseover="doUpdateNotes(\'AVNUMPROC\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn5" >MEMINFO</div>

<div id="Layer5" class="txt_fieldn5" >

<label id="MEMINFO_SOFT" name="MEMINFO_SOFT">'.$_SESSION["MEMINFO_SOFT"].'</label>

</div>
<div id="Layer5" class="txt_fieldtn5" >


    <input id="MEMINFO_HARD" name="MEMINFO_HARD" type="text" value="'.  $_SESSION['MEMINFO_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn5" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'MEMINFO\');" onmouseover="doUpdateNotes(\'MEMINFO\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>

<div id="Layer4"  class="labels_listn6" >DISKSPACE</div>

<div id="Layer5" class="txt_fieldn6" >

    <input id="DISKSPACE_SOFT" name="DISKSPACE_SOFT"  type="text" value="'.  $_SESSION['DISKSPACE_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn6" >


    <input id="DISKSPACE_HARD" name="DISKSPACE_HARD" type="text" value="'.  $_SESSION['DISKSPACE_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn6" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'DISKSPACE\');" onmouseover="doUpdateNotes(\'DISKSPACE\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn7" >DISKINODES</div>

<div id="Layer5" class="txt_fieldn7" >

    <input id="DISKINODES_SOFT" name="DISKINODES_SOFT"  type="text" value="'.  $_SESSION['DISKINODES_SOFT'] .'">

</div>
<div id="Layer5" class="txt_fieldtn7" >


    <input id="DISKINODES_HARD" name="DISKINODES_HARD" type="text" value="'.  $_SESSION['DISKINODES_HARD'] .'">

</div>
<div id="Layer5" class="help_buttn7" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'DISKINODES\');" onmouseover="doUpdateNotes(\'DISKINODES\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>

<div id="Layer4" class="labels_listn8" >CPUUNITS</div>


<div id="Layer5" class="txt_fieldn8" >

    <input id="CPUUNITS" name="CPUUNITS"  type="text" value="'.  $_SESSION['CPUUNITS'] .'">

</div>
<div id="Layer5" class="help_buttn8" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'CPUUNITS\');" onmouseover="doUpdateNotes(\'CPUUNITS\',\'enter\')"
  onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn9" >QUOTATIME</div>


<div id="Layer5" class="txt_fieldn9" >

    <input id="QUOTATIME" name="QUOTATIME"  type="text" value="'.  $_SESSION['QUOTATIME'] .'">

</div>
<div id="Layer5" class="help_buttn9" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'QUOTATIME\');" onmouseover="doUpdateNotes(\'QUOTATIME\',\'enter\')"
  onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn10" >DISABLED</div>


<div id="Layer5" class="txt_fieldn10" >	
<label id="DISABLED" name="DISABLED">'.$_SESSION["DISABLED"].'</label>
  

</div>
<div id="Layer5" class="help_buttn10" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'DISABLED\');" onmouseover="doUpdateNotes(\'DISABLED\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn11" >ONBOOT</div>


<div id="Layer5" class="txt_fieldn11" >
<label id="ONBOOT" name="ONBOOT">'.$_SESSION["ONBOOT"].'</label>

</div>
<div id="Layer5" class="help_buttn11" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'ONBOOT\');" onmouseover="doUpdateNotes(\'ONBOOT\',\'enter\')"
  onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn12" >QUOTAUGIDLIMIT</div>


<div id="Layer5" class="txt_fieldn12" >

    <input id="QUOTAUGIDLIMIT" name="QUOTAUGIDLIMIT"  type="text" value="'.  $_SESSION['QUOTAUGIDLIMIT'] .'">

</div>
<div id="Layer5" class="help_buttn12" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'QUOTAUGIDLIMIT\');" onmouseover="doUpdateNotes(\'QUOTAUGIDLIMIT\',\'enter\')"
  onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn13" >CPULIMIT</div>


<div id="Layer5" class="txt_fieldn13" >

    <input id="CPULIMIT" name="CPULIMIT"  type="text" value="'.  $_SESSION['CPULIMIT'] .'">

</div>
<div id="Layer5" class="help_buttn13" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'CPULIMIT\');" onmouseover="doUpdateNotes(\'CPULIMIT\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>

<div id="Layer4" class="labels_listn14" >NAMESERVER</div>


<div id="Layer5" class="txt_fieldn14" >

    <input id="NAMESERVER" name="NAMESERVER"  type="text" value="'.  $_SESSION['NAMESERVER'] .'">

</div>
<div id="Layer5" class="help_buttn14" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NAMESERVER\');" onmouseover="doUpdateNotes(\'NAMESERVER\',\'enter\')"  
onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn15" >VE_ROOT</div>


<div id="Layer5" class="txt_fieldn15" >
<label id="VE_ROOT" name="VE_ROOT">'.$_SESSION["VE_ROOT"].'</label>

</div>
<div id="Layer5" class="help_buttn15" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'VE_ROOT\');" onmouseover="doUpdateNotes(\'VE_ROOT\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn16">VE_PRIVATE</div>


<div id="Layer5" class="txt_fieldn16" >
<label id="VE_PRIVATE" name="VE_PRIVATE" >'.$_SESSION["VE_PRIVATE"].'</label>

</div>
<div id="Layer5" class="help_buttn16" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'VE_PRIVATE\');" onmouseover="doUpdateNotes(\'VE_PRIVATE\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn17" >IPTABLES</div>


<div id="Layer5" class="txt_fieldn17" >
    <input id="IPTABLES" name="IPTABLES" disabled=true type="text" value="'.  $_SESSION['IPTABLES'] .'">

</div>
<div id="Layer5" class="help_buttn17" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'IPTABLES\');" onmouseover="doUpdateNotes(\'IPTABLES\',\'enter\')" 
 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div id="Layer4" class="labels_listn18" >CONFIGURATION NAME</div>


<div id="Layer5" class="txt_fieldn18" >
		<label id="CONFIGURATIONNAME" name="CONFIGURATIONNAME" >'.$_SESSION["CONFIGURATIONNAME"].'</label>
</div>
<div id="Layer5" class="help_buttn18" >
<a href="javascript:void(0);" onclick="javascript:doSetNote(\'CONFIGURATIONNAME\');" 
onmouseover="doUpdateNotes(\'CONFIGURATIONNAME\',\'enter\')"  
onmouseout="doUpdateNotes(\'General\',\'exit\')">
<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
</div>


<div class="conf_back" >
	<a class="red_tag" href="javascript:void(0);" 
	onclick="javascript:show_plan_data_back(\'../server/editwizard.php\',\'plans_details\');">
	&#171;&nbsp;'. $lang_conv->fetch_word('BACK') .'</a>
</div>

<div class="mandatory_nextpage_style" >	
	<b><pre><font class="fontred">'.$lang_conv->fetch_word("ALLFIELDS").
'</font></pre></b></div>
<div id="Layer5" class="createconf_buton_div">
<a href="javascript:void(0);" class="buttonstyle"  onclick="doCreateConf()" >'.
$lang_conv->fetch_word("UPDATEPLAN").'</a>
</div> 
<div id="message" class="config_msg"></div>
		<input type="hidden" value="1" id="back" name="back"/>' .
		'<input type="hidden" value="adv" id="plantype" name="plantype"/>' .
		'<input type="hidden" id="name="planaction" name="planaction" value="edit"/>		
</form>
</div>';

print $string;
?>
