<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the Destroy Node plan page
	*
	*/
	
include('../services/checksession.php');
include('../lib/server.php');
include('../common/lang_conversion.php');
include('../common/common_function.php');

$outputmsg = '';

if(isset($_POST['veid'])){
	$veid = $_POST['veid'];

		$outputmsg .= '<table class="table_msg">';
		$outputmsg .= '<tr><th colspan=2>'.$lang_conv->fetch_word("RESULT").'</th></tr>';
		$outputmsg .= '<tr><td>';
		$outputmsg .= $lang_conv->fetch_word("DESTROYING_NODE").' ...... '.$veid;
		$outputmsg .= '</td></tr>';
		$val=$server->DestroyNode($veid);
		foreach($val as $key){
			$outputmsg .= '<tr><td >';
			$outputmsg .=  $key;
			$outputmsg .= '</td></tr>';
		}
		$outputmsg .= '</table>';
		$outputmsg = $common_obj->display_message($outputmsg,1);
}

$listval=$server->NodeListing();
$range = count($listval);
if($range > 0){ 
	
?>
<div class="destroy_node_header_left"></div>
<div id="Layer3"  class="destroy_node_header"><?php echo $lang_conv->fetch_word("DESTROYNODE")?></div>
<div class="destroy_node_header_right"></div>

<div class="destroy_node_div">

<div id="Layer4"  class="node_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?> : </div>
<div id="Layer5">
  <form name="destroy_node" method="post" onsubmit="return false">  
  
    <select id="veid" name="veid" class="destroy_drop_down" onchange="clearErrorMessage()">
<?php

for($i=0;$i<$range;$i++)
{	
	list($vied, $nproc, $status,$ip,$hostname) = split(':', $listval[$i][0]);
	if(strcmp(trim($hostname),'') == 0){
		$hostname = ''.$lang_conv->fetch_word("UNKNOWN");
	}
	echo("<option value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");	
}
?>
    </select>
  
  <div class="destroy_btn">
  	<a href="javascript:void(0);" class="buttonstyle"	 
   		onclick="javascript:doDestroyNode();">
  	<?php echo $lang_conv->fetch_word("DESTROYNODE")?>
  </a>
</div>
<div id="message" class="destroy_message_style" >
<?php 
} else {
	$outputmsg = '<font class="norecords_server" >&nbsp;<center>'.
				 '<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.
				 $lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';	
}
print $outputmsg;
?>
</div>
  </form>

 </div>
