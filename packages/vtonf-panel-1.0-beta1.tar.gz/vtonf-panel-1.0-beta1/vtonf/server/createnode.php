<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Create Node page
	*
	*/

include ('../services/checksession.php');
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');

$string1 = '';
$ostemplate = '';
$hostname = '';
$ip = '';
$config = '';
if (isset ($_POST['operating_system']) && isset ($_POST['configuration']) && 
isset ($_POST['hostname']) && isset ($_POST['ip_address'])) {
    $ostemplate = trim($_POST['operating_system']);
    $config = trim($_POST['configuration']);
    $hostname = trim($_POST['hostname']);
    $ip = trim($_POST['ip_address']);
    $host_flag1 = 1;
    $ip_flag1 = 1;
    $host_flag = 1;
    $ip_flag = 1;
    $config_flag = 1;
    $host_ip_flag1 = 1;

    $string1 .= '<table class="table_msg">';
    $string1 .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';

    if ($common_obj->valid_hostname($hostname)) {
        $host_flag1 = 0;
    }
    if (strlen($hostname) < 16) {
        if (!$host_flag1) {
            if ($common_obj->isValid_NameServer($hostname)) {
                $host_ip_flag1 = 0;
            }
        }
    } else {
    if (!$host_flag1) {
       		$host_ip_flag1 = 0;
        	$hostname = "";
	}
    }

    $allhostnames = $server->getAllHostnames();
    foreach ($allhostnames as $line) {
        if ($line == $hostname) {
            $host_flag = 0;
            break;
        }
    }

    if (strlen($ip) < 16) {
        if ($common_obj->isValid_NameServer($ip)) {
            $ip_flag1 = 0;
        }
        $allips = $server->getAllIpAddress();
        foreach ($allips as $line) {
            if ($line == $ip) {
                $ip_flag = 0;
                break;
            }
        }
    } else {
        $ip_flag1 = 0;
        $ip = "";
    }

    if ($config == '') {
        $config_flag = 0;
    }
    if (!$host_ip_flag1 && !$host_flag1) {
        $string1 .= '<tr><td >';
        $string1 .= $common_obj->display_message($lang_conv->fetch_word("HOSTNAME_EMPTY"), 0);
        $string1 .= '</tr></td>';
    } else
        if ($host_flag == 0) {
            $string1 .= '<tr><td >';
            $string1 .= $common_obj->display_message($lang_conv->fetch_word("HOSTNAME_UNIQUE"), 0);
            $string1 .= '</tr></td>';
        } else
            if ($ip_flag1 == 0) {
                $string1 .= '<tr><td >';
                $string1 .= $common_obj->display_message($lang_conv->fetch_word("IPADRREMPTY"), 0);
                $string1 .= '</tr></td>';
            } else
                if ($ip_flag == 0) {
                    $string1 .= '<tr><td >';
                    $string1 .= $common_obj->display_message($lang_conv->fetch_word("IPADRR_UNIQUE"), 0);
                    $string1 .= '</tr></td>';
                } else
                    if ($config_flag == 0) {
                        $string1 .= '<tr><td >';
                        $string1 .= $common_obj->display_message($lang_conv->fetch_word("NOCONFIG_CREATE"), 0);
                        $string1 .= '</tr></td>';
                    } else {

                        $lastnodeid = $server->getlastvid();
                        $max_id = $common_obj->getKeyValuePair('/etc/vtonf/setupvtonf', 'endlimit');

                        if (intval($lastnodeid[0]) == 0) {
                            $veid = $common_obj->getKeyValuePair('/etc/vtonf/setupvtonf', 'startlimit') + 1;
                        } else {
                            $veid = intval($lastnodeid[0]) + 1;
                        }

                        if (intval($veid) > intval($max_id)) {
                            $string1 .= '<tr><td >';
                            $string1 .= $common_obj->display_message($lang_conv->fetch_word("MAX_LIMIT"), 0);
                            $string1 .= '</tr></td>';
                        } else {
                            $createresult = $server->CreateNode($veid, $ostemplate, $config, $hostname, $ip);
                            $string1 .= '<tr><td >';
                            $string1 .= $common_obj->display_message($lang_conv->fetch_word("NODENUM").' '.
                            $veid.' '.$lang_conv->fetch_word("HAS_CREATED"), 1);
                            $string1 .= '</tr></td>';
                            foreach ($createresult as $line) {
                                $string1 .= '<tr><td >';
                                $string1 .= $common_obj->display_message($line, 1);
                                $string1 .= '</tr></td>';
                            }

                        }
                    }
    $string1 .= '</table>';
}
?>
<div class="create_node_header_left"></div>
<div class="create_node_header"><?php echo $lang_conv->fetch_word("CREATENODE")?></div>
<div class="create_node_header_right"></div>
<div  class="createnode_div">

<div   class="o_system_box"><?php echo $lang_conv->fetch_word("OPERATINGSYSTEM") ?>  : </div>
<div   class="select_conf_box"><?php echo $lang_conv->fetch_word("SELECT_CONF")?>: </div>
<div   class="hostname_box"><?php echo $lang_conv->fetch_word("HOSTNAME")?>  : </div>
<div   class="ip_address_box">
<?php echo $lang_conv->fetch_word("IP_ADDRESS") ?> : 
</div>

<form name="create_node_form" id="create_node_form" method="post" onSubmit="return false">

<div >
    <select name="operating_system" class="osname_drop_down">
    	<?php


$lines = file($SYS_CONFIG_DIR.'/ostemplatelist');
// loop for taking the os files;
foreach ($lines as $line) {
    if (strcasecmp(trim($line), trim($ostemplate)) == 0) {
        echo "<option selected value=\"$line\">$line</option>";
    } else {
        echo "<option value=\"$line\">$line</option>";
    }
}
?>
    </select>
</div>

<!--configuration list-->
<div >
    <select name="configuration" class="conf_drop_down">
       <?php


$lines = file($SYS_CONFIG_DIR.'/vpsconflist');
// loop for taking the os files;
foreach ($lines as $line) {
    if (strcasecmp(trim($line), trim($config)) == 0) {
        echo "<option selected value=\"$line\">$line</option>";
    } else {
        echo "<option value=\"$line\">$line</option>";
    }
}
?>
    </select>
</div>


<div >
    <input id="hostname_node" type="text" name="hostname" class="hostname_text_box" value="<?php echo $hostname?>">
</div>

<div >
    <input id="ip_address" type="text" name="ip_address" class="ip_text_box" value="<?php echo $ip?>"> 
</div>
 
<div class="nodecreate_btn">
	<a href="javascript:void(0);" class="buttonstyle" 
	onclick="javascript:doAddNewNode()">
		<?php echo $lang_conv->fetch_word("CREATENODE")?>
	</a>
</div>

<div class="successful_message" id="successful_message">
  
<?php


print $string1;
?>
</div>

</form>

</div> 





