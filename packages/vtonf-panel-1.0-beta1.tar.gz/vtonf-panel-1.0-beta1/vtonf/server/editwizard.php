<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the Edit Easy or Advanced Wizard plan page
	*
	*/
	
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');

if (isset ($_POST['editplan_value'])) {
    $planname = trim($_POST['editplan_value']);
    $_SESSION['CONFIGURATIONNAME'] = $planname;

    $path = $_CONF_VZ_PATH.'ve-'.$planname.'.conf-sample';
    $assocarray = array ();
    $lines = file($path);

    foreach ($lines as $line) {
        $line = trim($line);
        if (strlen($line)) {
            if (strrpos($line, '#') === false) {
                $equalsplit = split("=", $line);
                $assocarray[$equalsplit[0]] = $equalsplit[1];
            }
        }
    }
    foreach ($assocarray as $key => $value) {
        $key = strtoupper($key);
        $value = str_replace('"', '', $value);
        if (strrpos($value, ':') === false) {
            $_SESSION[$key] = $value;
        } else {
            $splitted = split(':', $value);
            $softkey = $key.'_SOFT';
            $hardkey = $key.'_HARD';
            $_SESSION[$softkey] = $splitted[0];
            $_SESSION[$hardkey] = $splitted[1];
        }
    }
}
$plantype = '';
if (isset ($_POST["edit_plan_checked"])) {
    $plantype = $_POST["edit_plan_checked"];
}

if ($plantype == 'easy') {

    $string = '
    	
    	<div id="plans_sub_header" class="plans_sub_header">
    	'.$lang_conv->fetch_word("EDIT_EASYWZD").'
    	</div>
    	<div id="easywzd_sub_div" class="easywzd_sub_div"><br>
    	
    	  <form  method="POST" name="easywzd_form" id="easywzd_form">
    	  
    	<div class="memory_sub_head">'.$lang_conv->fetch_word("EASY_MEMORY").'
    	</div>
    	<div class="memory_text">
    	  <input type="text" name="memory_vlaue" id="memory_vlaue" value="'.getMemory().'"/>  
    	</div>
    	
    	<div class="memory_type">
    	
    	  <select name="memory_type" id="memory_type">
    	    <option value="MB">MB</option>
    	    <option value="GB">GB</option>    
    	  </select> 
    	
    	</div>
    	
    	<div class="easy_help_buttn" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'EASY_MEMINFO\')" onmouseover="doUpdateNotes(\'EASY_MEMINFO\',\'enter\')"  
    	 onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	 	<img src="image/help_butt.jpg" >
    	 </a>
    	</div>
    	
    	<div class="disk_sub_head">'.$lang_conv->fetch_word("EASY_DISK").'</div>
    	<div class="disk_text">
    	  <input type="text" name="disk_value" id="disk_value" value="'.getDiskSpace().'"/>    
    	</div>
    	
    	<div class="disk_type">
    	
    	  <select name="disk_type" id="disk_type">
    	    <option value="MB">MB</option>
    	    <option value="GB">GB</option>    
    	  </select> 
    	
    	</div>
    	<div class="disk_help_buttn" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'EASY_DISKSPACE\');"  
    			onmouseover="doUpdateNotes(\'EASY_DISKSPACE\',\'enter\')"  
    	 onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	 <img src="image/help_butt.jpg" ></a>
    	</div>
    	
    	<div class="nameserver_sub_head">'.$lang_conv->fetch_word("EASY_NAMESERVER").'</div>
    	<div class="nameserver_text">
    	  <input type="text" name="nameserver_value" id="nameserver_value" value="'.$_SESSION["NAMESERVER"].'"/>    
    	</div>
    	
    	<div class="nameserver_help_buttn" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NAMESERVER\');" onmouseover="doUpdateNotes(\'NAMESERVER\'.\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg"  ></a>
    	</div>
    	
    	<div class="planname_sub_head">'.$lang_conv->fetch_word("EASY_PLANNAME").'
    	</div>
    	<div class="planname_text">
    			<label for="planname_value">'.$_SESSION["CONFIGURATIONNAME"].'</label>	
    	</div>
    	
    	<div id="Layer5" class="planname_help_buttn" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'CONFIGURATIONNAME\');" 
    	onmouseover="doUpdateNotes(\'CONFIGURATIONNAME\'.\'enter\')" onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg"  ></a>
    	</div>
    	<div class="easywzd_btn">	
    	  <a href="javascript:void(0);" class="buttonstyle" onclick="doAddNewPlan()">'.$lang_conv->fetch_word("UPDATEPLAN").'</a>  
    	</div>
    	<input type="hidden" id="name="planaction" name="planaction" value="edit"/>
    	  </form>
    	  <div id="message" class="easywzd_msg_style"></div>
    	  
    	</div>';
    print $string;

} else {
    $postvars = $_POST;

    foreach ($_POST as $key => $value) {

        if (strlen($value) < 100) {
            $_SESSION[$key] = $value;
        } else {
            $_SESSION[$key] = "";
        }
    }
    $string = ''.'<form id="create_conf1" name="create_conf1" method="POST" onsubmit="return false">'.'<div id="main_conf_1">'.'<div id="Layer3" class="conf_heading">'.$lang_conv->fetch_word("EDIT_ADVANCEDPLANWIZARD").'</div>'.'<div class="long_line"></div>'.'<div class="conf_soft_heading">'.$lang_conv->fetch_word("SOFTLIMIT").'</div>'.'<div class="conf_hard_heading">'.$lang_conv->fetch_word("HARDLIMIT").'</div>'.'<div id="Layer4" class="labels_list1">KMEMSIZE</div>'.'<div id="Layer5" class="txt_field1" >'.'<input id="KMEMSIZE_SOFT" name="KMEMSIZE_SOFT" type="text" value="'.$_SESSION["KMEMSIZE_SOFT"].'">
    	</div>
    	<div id="Layer125" class="txt_fieldt1" >
    	    <input id="KMEMSIZE_HARD" name="KMEMSIZE_HARD" type="text" value="'.$_SESSION["KMEMSIZE_HARD"].'">
    	</div>
    	<div id="Layer15" class="help_butt1">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'KMEMSIZE\');"
    	 onmouseover="doUpdateNotes(\'KMEMSIZE\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4" class="labels_list2" >LOCKEDPAGES</div>
    	
    	<div id="Layer5" class="txt_field2" >
    	
    	<input id="LOCKEDPAGES_SOFT" name="LOCKEDPAGES_SOFT"  type="text" value="'.$_SESSION["LOCKEDPAGES_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt2" >
    	    <input id="LOCKEDPAGES_HARD" name="LOCKEDPAGES_HARD" type="text" value="'.$_SESSION["LOCKEDPAGES_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt2" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'LOCKEDPAGES\');"
    	 onmouseover="doUpdateNotes(\'LOCKEDPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	 <img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4" class="labels_list3" >PRIVVMPAGES</div>
    	
    	
    	<div id="Layer5" class="txt_field3" >
    	
    	    <input id="PRIVVMPAGES_SOFT" name="PRIVVMPAGES_SOFT"  type="text" value="'.$_SESSION["PRIVVMPAGES_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt3" >
    	
    	
    	    <input id="PRIVVMPAGES_HARD" name="PRIVVMPAGES_HARD" type="text" value="'.$_SESSION["PRIVVMPAGES_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt3" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'PRIVVMPAGES\');" 
    	onmouseover="doUpdateNotes(\'PRIVVMPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4" class="labels_list4" >SHMPAGES</div>
    	
    	<div id="Layer5" class="txt_field4" >
    	    <input id="SHMPAGES_SOFT" name="SHMPAGES_SOFT"  type="text" value="'.$_SESSION["SHMPAGES_SOFT"].'">
    	</div>
    	<div id="Layer5" class="txt_fieldt4" >
    	    <input id="SHMPAGES_HARD" name="SHMPAGES_HARD" type="text" value="'.$_SESSION["SHMPAGES_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt4" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'SHMPAGES\');" 
    	onmouseover="doUpdateNotes(\'SHMPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4" class="labels_list5" >NUMPROC</div>
    	
    	<div id="Layer5" class="txt_field5" >
    	
    	    <input id="NUMPROC_SOFT" name="NUMPROC_SOFT"  type="text" value="'.$_SESSION["NUMPROC_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt5" >
    	
    	
    	    <input id="NUMPROC_HARD" name="NUMPROC_HARD" type="text" value="'.$_SESSION["NUMPROC_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt5" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMPROC\');" 
    	onmouseover="doUpdateNotes(\'NUMPROC\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4" class="labels_list6" >PHYSPAGES</div>
    	
    	
    	<div id="Layer5" class="txt_field6" >';

    $string .= '<input id="PHYSPAGES_SOFT" name="PHYSPAGES_SOFT" type="text" value="'.$_SESSION["PHYSPAGES_SOFT"].'">
    	</div><div id="Layer5" class="txt_fieldt6" >
    	    <input id="PHYSPAGES_HARD" name="PHYSPAGES_HARD" type="text" value="'.$_SESSION["PHYSPAGES_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt6" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'PHYSPAGES\');" 
    	onmouseover="doUpdateNotes(\'PHYSPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	<div id="Layer4"  class="labels_list7">VMGUARPAGES</div>
    	
    	<div id="Layer5" class="txt_field7" >
    	    <input id="VMGUARPAGES_SOFT" name="VMGUARPAGES_SOFT"  type="text" value="'.$_SESSION["VMGUARPAGES_SOFT"].'">
    	</div>
    	<div id="Layer5" class="txt_fieldt7" >
    	
    	    <input id="VMGUARPAGES_HARD" name="VMGUARPAGES_HARD" type="text" value="'.$_SESSION["VMGUARPAGES_HARD"].'">    
    	</div>
    	<div id="Layer5" class="help_butt7" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'VMGUARPAGES\');" 
    	onmouseover="doUpdateNotes(\'VMGUARPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4" class="labels_list8">OOMGUARPAGES</div>
    	
    	<div id="Layer5" class="txt_field8" >
    	
    	    <input id="OOMGUARPAGES_SOFT" name="OOMGUARPAGES_SOFT"  type="text" value="'.$_SESSION["OOMGUARPAGES_SOFT"].'">
    	
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt8" >
    	
    	
    	    <input id="OOMGUARPAGES_HARD" name="OOMGUARPAGES_HARD" type="text" value="'.$_SESSION["OOMGUARPAGES_HARD"].'">
    	
    	</div>
    	
    	<div id="Layer5" class="help_butt8" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'OOMGUARPAGES\');" 
    	onmouseover="doUpdateNotes(\'OOMGUARPAGES\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4" class="labels_list9" >NUMTCPSOCK</div>
    	
    	<div id="Layer5" class="txt_field9" >
    	    <input id="NUMTCPSOCK_SOFT" name="NUMTCPSOCK_SOFT"  type="text" value="'.$_SESSION["NUMTCPSOCK_SOFT"].'">
    	
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt9" >
    	    <input id="NUMTCPSOCK_HARD" name="NUMTCPSOCK_HARD" type="text" value="'.$_SESSION["NUMTCPSOCK_HARD"].'">
    	
    	</div>
    	
    	<div id="Layer5" class="help_butt9" >
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMTCPSOCK\');" onmouseover="doUpdateNotes(\'NUMTCPSOCK\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	<div id="Layer4"  class="labels_list10" >NUMFLOCK</div>
    	
    	<div id="Layer5" class="txt_field10" >
    	    <input id="NUMFLOCK_SOFT" name="NUMFLOCK_SOFT"  type="text" value="'.$_SESSION["NUMFLOCK_SOFT"].'">
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt10" >
    	    <input id="NUMFLOCK_HARD" name="NUMFLOCK_HARD" type="text" value="'.$_SESSION["NUMFLOCK_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt10">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMFLOCK\');" 
    	onmouseover="doUpdateNotes(\'NUMFLOCK\',\'enter\')"  onmouseout="doUpdateNotes(\'General\',\'exit\')">
    	<img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4"  class="labels_list11" >NUMPTY</div>
    	
    	<div id="Layer5" class="txt_field11" >
    	    <input id="NUMPTY_SOFT" name="NUMPTY_SOFT"  type="text" value="'.$_SESSION["NUMPTY_SOFT"].'">
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt11" >
    	    <input id="NUMPTY_HARD" name="NUMPTY_HARD" type="text" value="'.$_SESSION["NUMPTY_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt11">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMPTY\');" onmouseover="doUpdateNotes(\'NUMPTY\',\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4"  class="labels_list12" >NUMSIGINFO</div>
    	
    	<div id="Layer5" class="txt_field12" >
    	    <input id="NUMSIGINFO_SOFT" name="NUMSIGINFO_SOFT"  type="text" value="'.$_SESSION["NUMSIGINFO_SOFT"].'">
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt12" >
    	    <input id="NUMSIGINFO_HARD" name="NUMSIGINFO_HARD" type="text" value="'.$_SESSION["NUMSIGINFO_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt12">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMSIGINFO\');" onmouseover="doUpdateNotes(\'NUMSIGINFO\',\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4"  class="labels_list13" >TCPSNDBUF</div>
    	
    	<div id="Layer5" class="txt_field13" >
    	    <input id="TCPSNDBUF_SOFT" name="TCPSNDBUF_SOFT"  type="text" value="'.$_SESSION["TCPSNDBUF_SOFT"].'">
    	</div>
    	
    	<div id="Layer5" class="txt_fieldt13" >
    	    <input id="TCPSNDBUF_HARD" name="TCPSNDBUF_HARD" type="text" value="'.$_SESSION["TCPSNDBUF_HARD"].'">
    	</div>
    	<div id="Layer5" class="help_butt13">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'TCPSNDBUF\');" onmouseover="doUpdateNotes(\'TCPSNDBUF\',\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4" class="labels_list14" >TCPRCVBUF</div>
    	
    	
    	<div id="Layer5" class="txt_field14" >
    	
    	    <input id="TCPRCVBUF_SOFT" name="TCPRCVBUF_SOFT"  type="text" value="'.$_SESSION["TCPRCVBUF_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt14" >
    	
    	
    	    <input id="TCPRCVBUF_HARD" name="TCPRCVBUF_HARD" type="text" value="'.$_SESSION["TCPRCVBUF_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt14">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'TCPRCVBUF\');" onmouseover="doUpdateNotes(\'TCPRCVBUF\',\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	
    	<div id="Layer4" class="labels_list15" >OTHERSOCKBUF</div>
    	
    	
    	<div id="Layer5" class="txt_field15" >
    	
    	    <input id="OTHERSOCKBUF_SOFT" name="OTHERSOCKBUF_SOFT"  type="text" value="'.$_SESSION["OTHERSOCKBUF_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt15" >
    	
    	
    	    <input id="OTHERSOCKBUF_HARD" name="OTHERSOCKBUF_HARD" type="text" value="'.$_SESSION["OTHERSOCKBUF_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt15">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'OTHERSOCKBUF\');" onmouseover="doUpdateNotes(\'OTHERSOCKBUF\',\'enter\')" 
    	 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4" class="labels_list16" >DGRAMRCVBUF</div>
    	
    	
    	<div id="Layer5" class="txt_field16" >
    	
    	    <input id="DGRAMRCVBUF_SOFT" name="DGRAMRCVBUF_SOFT"  type="text" value="'.$_SESSION["DGRAMRCVBUF_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt16" >
    	
    	
    	    <input id="DGRAMRCVBUF_HARD" name="DGRAMRCVBUF_HARD" type="text" value="'.$_SESSION["DGRAMRCVBUF_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt16">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'DGRAMRCVBUF\');" onmouseover="doUpdateNotes(\'DGRAMRCVBUF\',\'enter\')"  
    	onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	
    	
    	<div id="Layer4" class="labels_list17" >NUMOTHERSOCK</div>
    	
    	<div id="Layer5" class="txt_field17" >
    	
    	    <input id="NUMOTHERSOCK_SOFT" name="NUMOTHERSOCK_SOFT"  type="text" value="'.$_SESSION["NUMOTHERSOCK_SOFT"].'">
    	
    	</div>
    	<div id="Layer5" class="txt_fieldt17" >
    	
    	
    	    <input id="NUMOTHERSOCK_HARD" name="NUMOTHERSOCK_HARD" type="text" value="'.$_SESSION["NUMOTHERSOCK_HARD"].'">
    	
    	</div>
    	<div id="Layer5" class="help_butt17">
    	<a href="javascript:void(0);" onclick="javascript:doSetNote(\'NUMOTHERSOCK\');" onmouseover="doUpdateNotes(\'NUMOTHERSOCK\',\'enter\')" 
    	 onmouseout="doUpdateNotes(\'General\',\'exit\')"><img src="image/help_butt.jpg" border="0" height="20" width="20"></a>
    	</div>
    	<div class="mandatory_style" >	
    		<b><pre><font class="fontred">'.$lang_conv->fetch_word("ALLFIELDS").'</font></pre></b>
    	</div>
    	<div class="next_style">	
    		<a class="red_tag" href="javascript:void(0);" 
    		onclick="javascript:show_plans_data_next(\'../server/editwizard_next.php\',\'plans_details\');">'.$lang_conv->fetch_word("NEXT").'&nbsp;&#187;</a>
    	</div>
    	<div class="conf_detail" id="detail1"></div>
    	</div><input type="hidden" id="name="planaction" name="planaction" value="edit"/>
    	</form>';

    print $string;
}

	  /**
		* getDiskSpace is used to calculate 
		* the DiskSpace
		*
		* @param     none
		* @return    $diskVal  
		*
		*/
function getDiskSpace() {

    $diskvalue = intval($_SESSION["DISKSPACE_HARD"]);
    $diskvalue = $diskvalue / 1024.0;
    $_SESSION["DISKSPACE_HARD"] = ''.intval($diskvalue);
    $diskVal = $_SESSION["DISKSPACE_HARD"];
    return $diskVal;
}

	  /**
		* getMemory is used to calculate 
		* the Memory Value
		*
		* @param     none
		* @return    $diskVal  
		*
		*/
function getMemory() {

    $mem = intval($_SESSION["PRIVVMPAGES_SOFT"]);
    $mem = ($mem * 4) / 1024;
    $_SESSION["PRIVVMPAGES_SOFT"] = ''.intval($mem);
    $diskVal = $_SESSION["PRIVVMPAGES_SOFT"];
    return $diskVal;

}
?>