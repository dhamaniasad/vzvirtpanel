<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the OpenVz HardDisk Information
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
$val = $server->openvz_harddisk();
$value = '';
$value .= '<div class="openvz_sub_header_left"></div><div id="openvz_sub_header"  class="openvz_sub_header">'.$lang_conv->fetch_word("OPENVZ_HARDDISK").'</div>
<div class="openvz_sub_header_hd_right"></div>';

$value .= '<div id="openvz_sub_div" class="openvz_sub_div"><br>';
$count = 0;
foreach ($val as $key) {
    if (trim($key) != '') {
        $splitted[$count] = split(" ", trim($key));
        $count ++;
    }
}

$GET1["disk_values"] = '';
$GET2["disk_labels"] = '';
$value .= '<div class="ovzhdd_div">';
$value .= '<table class="ovzhdd">';
$value .= '<tr>';
$value .= '<th colspan=2 >';
$value .= ''.$lang_conv->fetch_word("PARTITION");
$value .= '</th>';

$value .= '<th  >';
$value .= ''.$lang_conv->fetch_word("PARTITION_GRAPH");
$value .= '</th>';

$value .= '<th colspan=3 >';
$value .= ''.$lang_conv->fetch_word("PARTITION_INFO");
$value .= '</th>';
$value .= '</tr>';
$row = 0;
for ($index = 0; $index < sizeof($splitted); $index ++) {
    $value .= '<tr>';
    $value .= '<td colspan=2 >';
    $value .= $splitted[$index][5];
    $value .= '</td>';
    $value .= '<td >';
    $usedpercentage = intval(trim(str_replace("%", "", $splitted[$index][4])));
    $availpercentage = (100 - $usedpercentage);
    $GET1["disk_values"] = $usedpercentage.'*'.$availpercentage;
    $GET2["disk_labels"] = $lang_conv->fetch_word("USED").'*'.$lang_conv->fetch_word("AVAILABLE");

    if ($usedpercentage > 90) {
        $col1 = "FF130B"; /*if greater than 90% showing in RED */
        $col2 = "3415FF"; /*if greater than 90% showing in BLUE */
    } else {
        $col1 = "23C8FF";
        $col2 = "003466";
    }

    $value .= '<img src="../server/piechart.php?'.'disk_values='.$GET1["disk_values"].'&disk_labels='.$GET2["disk_labels"].'&col1='.$col1.'&col2='.$col2.'"/>';
    $value .= '</td>';
    $value .= '<td colspan=3 >';

    $value .= $lang_conv->fetch_word("TOTAL_SPACE").' - '.$splitted[$index][1].'<br>';
    $value .= $lang_conv->fetch_word("USED_SPACE").'  - '.$splitted[$index][2].'<br>';
    $value .= $lang_conv->fetch_word("FREE_SPACE").'  - '.$splitted[$index][3].'<br>';
    $value .= '</td>';
    $value .= '</tr>';
}

$value .= '</table>';
$value .= '<font class="error_msg">&#8226;</font><font class="small_font">'.$lang_conv->fetch_word("INDICATE_DISK").' 90%</font>';
$value .= '</div>';
$_POST['rand'] = "121";
print $value;
?>