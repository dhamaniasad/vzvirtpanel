<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to modify the 
	* status of the node.
	*
	*/
	
include ('../services/checksession.php');
$veid = trim($_POST['node_veid']);
$cstatus = trim($_POST['cstatus']);
print '<br><br>';

if ($cstatus == 'ususpend') {
    include ('../nmgnt/nodeususpend-c.php');
    print nodeususpendmsg($veid);
} else
    if ($cstatus == 'restart') {
        include ('../nmgnt/noderestart-c.php');
        print noderestartmsg($veid);
    } else
        if ($cstatus == 'stop') {
            include ('../nmgnt/nodestop-c.php');
            print nodestopmsg($veid);
        } else
            if ($cstatus == 'mount') {
                include ('../nmgnt/mountnode-c.php');
                print nodemountmsg($veid);
            } else
                if ($cstatus == 'umount') {
                    include ('../nmgnt/umountnode-c.php');
                    print nodeumountmsg($veid);
                } else
                    if ($cstatus == 'suspend') {
                        include ('../nmgnt/nodesuspend-c.php');
                        print nodesuspendmsg($veid);
                    } else {
                        include ('../nmgnt/nodestart-c.php');
                        print nodestartmsg($veid);
                    }
?>

