<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view 
	* the previous page of a Nodelisting Page
	*
	*/
	
include ('../services/checksession.php');
include ('../lib/server.php');
include ('../include/config.php');
include ('../common/lang_conversion.php');

$lang_conv = new language_map();
$listval = $server->NodeListing();

$running_bckgrnd_class = "running_bckgrnd_color";
$stopped_bckgrnd_class = "stopped_bckgrnd_color";
$mounted_bckgrnd_class = "mounted_bckgrnd_color";

$bckrnd = "";
$status_image_path = "";
$os_image_path = "";
?>



<div id="Layer3" class="node_listing_h">
<?php echo $lang_conv->fetch_word('NODELISTING'); ?></div>
<br><div class="total_nodes_div">
<?php


$total_nodes = count($listval);
$back = 1;
$_SESSION['STARTROW'] = $_SESSION['STARTROW'] - $_NODELISTING_PER_PAGE;
$_SESSION['ENDROW'] = $_SESSION['ENDROW'] - $_NODELISTING_PER_PAGE;

$startvalue = $_SESSION['STARTROW'];
$endvalue = $_SESSION['ENDROW'];
if ($startvalue == 0) {
    $back = 0;
}

if ($back == 1) {
    print '<a class="red_tag" href="javascript:void(0);" onclick="javascript:show_nodelist(\'../server/nodelist_back.php\')">&#171;';
    print '&nbsp;'.$lang_conv->fetch_word('BACK').'</a><b>&nbsp;';
}
print ($startvalue +1).'&nbsp;-&nbsp;';

if ($endvalue <= $total_nodes) {
    print $endvalue;
} else {
    print $total_nodes;
}
print '&nbsp;'.$lang_conv->fetch_word("OF").'&nbsp;'.$total_nodes.'&nbsp;</b>';
print '<a class="red_tag" href="javascript:void(0);" '.'onclick="javascript:show_nodelist(\'../server/nodelist_next.php\')">';
print $lang_conv->fetch_word('NEXT').'&#187;</a>';
?>
</div>

<div id="nodelisting" class="node_listing_div">

 <table> 
 
 <tr>	
 	<td class="veid_table_head">    VEID   </td>
 	<td  class="nproc_table_head">   NPROC  </td> 
 	<td colspan="2" class="status_table_head">   STATUS </td>
 	<td  class="ip_table_head">IP </td>
 	<td  class="hostname_table_head">HOSTNAME </td>
 	<td  class="os_table_head">OS</td>
 </tr>
 
      
 
	<?php


for ($i = $startvalue; $i < $endvalue; $i ++) {
    if ($total_nodes <= $i || $listval[$i][0] == '') {
        break;
    }
    list ($vied, $nproc, $status, $ip, $hostname) = split(':', $listval[$i][0]);

    $len = strlen($hostname);
    if ($len >= 32) {
        $hostname = wordwrap($hostname, 32, '<br>', true);
    }
    if ($status == "running") {
        $bckrnd_color = $running_bckgrnd_class;
    } else
        if ($status == "stopped") {
            $bckrnd_color = $stopped_bckgrnd_class;
        } else {
            $bckrnd_color = $mounted_bckgrnd_class;
        }
    $os_name = trim($server->getOSname($vied));
    print ('
    		<tr>
    			<td class="'.$bckrnd_color.'" >'.$vied.'</td>
    			<td class="'.$bckrnd_color.'" >'.$nproc.'</td>
    			<td class="'.$bckrnd_color.'" >'.$status.'</td>		
    			<td  class="'.$bckrnd_color.'">'.'<a onclick="showdialogdiv(\''.$vied.'\',\''.$status.'\');" href="javascript:void(0);">'.'<img class="image_measure" title="'.$status.'" src="../styles/image/'.$status.'">	
    			</td>
    			<td  class="'.$bckrnd_color.'">'.$ip.'</td>
    			<td  class="'.$bckrnd_color.'">'.$hostname.'</td>
    			<td   class="'.$bckrnd_color.'">'.'<img  class="image_measure" title="'.$os_name.'" src="../styles/image/'.$os_name.'">			
    			</td>
    		</tr>
    		');

}
print '<tr>';

if ($back == 1) {
    print '
    	 	<td align="left">
    	   	<a class="red_tag" href="javascript:void(0);" onclick="javascript:show_nodelist(\'../server/nodelist_back.php\')">&#171;';
    print '&nbsp;'.$lang_conv->fetch_word('BACK').'</a></td>
    		<td colspan="4">	</td>';
} else {
    print '<td colspan="6">	</td>';
}

print '<td  align="right" colspan="2">
			<a class="red_tag" href="javascript:void(0);" onclick="javascript:show_nodelist(\'../server/nodelist_next.php\')">';
print '&nbsp;'.$lang_conv->fetch_word('NEXT').'&#187;</a>
			</td>';
print '</tr>';
?>
</table>
</div> 
 