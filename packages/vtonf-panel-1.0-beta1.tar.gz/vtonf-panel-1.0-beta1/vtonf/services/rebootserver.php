<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to reboot the  
	* server.
	*
	*/
	
include ('checksession.php');
include ('../common/lang_conversion.php');
$string = '';
if (isset ($_POST['reboot'])) {
    include ('../lib/services.php');
    include ('../common/common_function.php');
    $vpservice->reboot_server();
    $string .= '<table class="table_msg">';
    $string .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';

    $string .= '<tr><td colspan=2 >';
    $string .= $common_obj->display_message($lang_conv->fetch_word("REBOOTSUCSS").'!!!', 1);
    $string .= '</td></tr>';
    $string .= '</table>';
}
?>

<div class="reboot_header_left"></div>
<div class="reboot_header">
	<?php echo $lang_conv->fetch_word("REBOOTSERVER")?>
</div>
<div class="reboot_header_right"></div>

	<form action="" method="post" id="rebootform" name="rebootform">
<div class="reboot_div">
	<div class="reboot_question" >
		<?php echo $lang_conv->fetch_word("ARE_SURE_REBOOT")?>?
	</div>
	<div class="reboot_btn">
		<a href="javascript:void(0);" class="buttonstyle"  onclick="doReboot()">
		<?php echo $lang_conv->fetch_word("YES")?></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="javascript:void(0);" class="buttonstyle"  onclick="doClearReboot()">
		<?php echo $lang_conv->fetch_word("NO")?></a>
	</div>
	<input type="hidden" id="rebootmsg" name="rebootmsg" 
	value="<?php echo $lang_conv->fetch_word("REBOOTMSG")?>"/>
<div id="message" class="reboot_message">
<?php

print $string;
?>
</div>
</form>
</div>