<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is the main Vtonf Control Panel
	* Page for viewing all the items.
	*
	*/
	
session_start();
$_SESSION['time_start']=time();
if(!(isset($_SESSION['username']))){
	header("Location:../index.php");
exit;
}
require('../include/config.php');
require('../common/common_function.php');
require ('../common/lang_conversion.php');

$lang_conv = new language_map();

$theme = trim($_SESSION['theme']);
if(strcasecmp($theme,'')==0){
	$theme='default';
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $lang_conv->fetch_word("VTONF_TITLE")?></title>

<script src="../js/vtonf.js" type="text/javascript"> </script>
<script src="../js/vtonfadd.js" type="text/javascript"> </script>
<script src="../js/vtonfadd_server.js" type="text/javascript"> </script>
<script src="../js/vtonf_nodemgnt.js" type="text/javascript"></script>
<script src="../js/vtonfd.js" type="text/javascript"></script>
<script src="../js/prototype.js" type="text/javascript"></script>
<script src="../js/scripteffect.js" type="text/javascript"></script>

<NOSCRIPT>
<meta http-equiv="Refresh" content="0; URL=noscript.html">
</NOSCRIPT> 
<link href="../styles/<?php echo $theme?>.css" rel="stylesheet" type="text/css">
 <link rel="shortcut icon" type="image/ico" href="../images/vtonf_logo.jpg" />
</head>
<body>

<div id="fullscreen"  class="masking-class" style="display:none;">

<div id="loadingimage" class="loading-image" style="display:block;">
</div>
<div id="modaldialog" class="modaldialog_div" style="display:none;">

	<form name="execute" id="execute" method="post">
	
  <table class="modaldialog">
  <tr>
  <th colspan=12>&nbsp;</th>
  <th>
  <a href="javascript:void(0);" onclick="closedialog()">
  	<?php echo $lang_conv->fetch_word("CLOSE")?>
  </a>
  </tr>
   <tr>
      <th id="dynamicnode_id" colspan=13></th>       
  </th>
    </tr>
    <tr>
      <td colspan=8>&nbsp;</td>
    </tr> 
    <tr>
      <th><?php echo $lang_conv->fetch_word("START")?></th>
      <th>&nbsp;</th>
      <th><?php echo $lang_conv->fetch_word("STOP")?></th>
      <th colspan=2>&nbsp;</th>
      <th><?php echo $lang_conv->fetch_word("MOUNT")?></th>
      <th>&nbsp;</th>
      <th><?php echo $lang_conv->fetch_word("UMOUNT")?></th>
      <th colspan=2>&nbsp;</th>
      <th><?php echo $lang_conv->fetch_word("SUSPEND")?></th>
      <th>&nbsp;</th>
      <th cellspacing="4"><?php echo $lang_conv->fetch_word("USUSPEND")?></th>
    </tr>    
    <tr>
      <td align=center><input checked="true" id="nodest" name="nodest" type="radio" value="start"></td>
      <td>&nbsp;</td>
      <td align=center><input id="nodest" name="nodest" type="radio" value="stop" ></td>
      <td colspan=2>&nbsp;</td>
      <td align=center><input id="nodest" name="nodest" type="radio" value="mount" ></td> 
      <td>&nbsp;</td>
      <td align=center><input id="nodest" name="nodest" type="radio" value="umount"></td>
      <td colspan=2>&nbsp;</td>
      <td align=center><input id="nodest" name="nodest" type="radio" value="suspend" ></td>
      <td>&nbsp;</td>
      <td align=center><input id="nodest" name="nodest" type="radio" value="ususpend" ></td>
    </tr>    
    <tr>
      <td colspan=13>&nbsp;</td>
    </tr> 
    <tr>
      <td colspan=12>
      &nbsp;
      </td>
      <td>
      	<a href="javascript:void(0);" class="buttonstyle" onclick="doExectuedialog()">
    	  <?php echo $lang_conv->fetch_word("EXECUTE")?> 
      	</a>
      </td>
    </tr>
     <tr>
      <td colspan=13>&nbsp;</td>
    </tr>    
  </table>
  <input type="hidden" name="vid" id="vid"/>
  <input type="hidden" name="pstatus" id="pstatus"/>
  <input type="hidden" name="node_name" id="node_name" 
  value="<?php echo $lang_conv->fetch_word("NODE")?>"/>
 	</form>
</div>
</div>


<div id="main"> <!--Start div-->
<div class="header">
	<div id="logo"  class="logo" >
		<img  src="../images/vtonf_logo.jpg">
	</div>
	<div class="vtonf_trans">
		V T O N F
	</div>
	<div class="version_vtonf">
		Vtonf Control Panel Version: <?php echo $common_obj->getVtonfVerion()?> 
	</div>
	<div class="powered_trans" >
		<?php echo $lang_conv->fetch_word("POWERED")?> BobCares
	</div>
</div>

<div class="fullheader">

<a id="home_tag" href="ctrlpanel.php" >	
	<div class="home_div" id="home">
		
		<div class="home_image">
			<input type="image" src="image/home.gif" width=15 height=14>
		</div>
		<div class="home_label">  
	    	 	<font class="fonthome">HOME</font>
		</div>
	</div>
</a>

	<a id="logout_tag" href="../login/logout.php"  >
<div class="logout_div"  id="logout" >
	<div class="logout_label">  
	    	<font class="fontlogout">LOGOUT</font>  
	</div>
    	  
</div>
	</a>	

</div>
<div class="left_menu" id="left_menu"><!--Left Menu div-->
	<div class="menu_bg" id="menu_bg"><!--Left Menu BGCOLor div-->
	
	<div id="dhtmlgoodies_question" class="dhtmlgoodies_question">
		<a href="javascript:void(0);" onclick="return false;" 
			class="menu_server_pos">		
		<font class="menu_font">S E R V E R</font>
	</a>
	</div>
	
<div class="dhtmlgoodies_answer">
<div>	
	
<div id="dhtmlgoodies_menu0">
	<ul>	
		<li>
			<a href="javascript:void(0);"  
			onclick="show_server_data('../server/nodelist.php','server_icon_set','server_head');return false;">		
				<?php echo $lang_conv->fetch_word('NODELISTING'); ?>		
			</a>
		</li>		
		<li>
			<a href="javascript:void(0);"  id="123"  
			onclick="show_server_data('../server/createnode.php','server_icon_set','server_head');return false;">
				<?php echo $lang_conv->fetch_word('CREATENODE'); ?>		
			</a>
		</li>		
		<li>
			<a href="javascript:void(0);"  
			onclick="show_server_data('../server/destroy.php','server_icon_set','server_head');return false;">		
				<?php echo $lang_conv->fetch_word('DESTROYNODE'); ?>
			</a>
		</li>		
		<li>
			<a href="javascript:void(0);" onclick="show_server_data('../server/plans.php','server_icon_set','server_head');return false;">		
				<?php echo $lang_conv->fetch_word('PLANS'); ?>
			</a>  
		</li>
				
		<li>
			<a href="javascript:void(0);" 
			onclick="show_server_data('../server/openvz.php','server_icon_set','server_head');return false;">
				<?php echo $lang_conv->fetch_word('OPENVZ'); ?>
			</a>		
		</li>		
</ul>
</div>
	
</div>
</div>

<div class="dhtmlgoodies_question">
	<a href="javascript:void(0);" onclick="return false;" 
	class="menu_services_pos">		
		<font class="menu_font">S E R V I C E S</font>
	</a>
</div>

<div class="dhtmlgoodies_answer">
<div>
	
<div id="dhtmlgoodies_menu1">
	<ul>
		<li>
			<a href="javascript:void(0);"  
				onclick="show_services_data('changerootpasswd.php','service_icon_set','services_head');return false;">
			<?php echo $lang_conv->fetch_word('CHANGE_ROOT_PSWD'); ?>
			</a>
		</li>
		<li>
			<a href="javascript:void(0);"  
				onclick="show_services_data('changenoderootpwd.php','service_icon_set','services_head');return false;">
			<?php echo $lang_conv->fetch_word("CHANGE_NODE_PSWD"); ?>
			</a>
		</li>
		<li>
			<a href="javascript:void(0);" 
				onclick="show_services_data('restartve.php','service_icon_set','services_head');return false;">
			<?php echo $lang_conv->fetch_word("RESTARTVE"); ?>
			</a>		
		</li>
		<li>
			<a href="javascript:void(0);" 
				onclick="show_services_data('rebootserver.php','service_icon_set','services_head');return false;">
			<?php echo $lang_conv->fetch_word("REBOOTSERVER"); ?>
			</a>
		</li>
		<li>
			<a href="javascript:void(0);" 
				onclick="show_serverload_data('serverload.php','service_icon_set','services_head');return false;">
			<?php echo $lang_conv->fetch_word("SERVERLOAD"); ?>
			</a>
		</li>
	</ul>
</div>
		
</div>
</div>

<div class="dhtmlgoodies_question">
<a href="javascript:void(0);" onclick="return false;" 
	class="menu_ngmt_pos">		
		<font class="menu_font"><?php echo $lang_conv->fetch_word('NODEMANAGEMENT');?></font>
	</a>
</div>

<div  class="dhtmlgoodies_answer">
<div>
		
<div id="dhtmlgoodies_menu2">
	<ul>	
		<li>
				<a href="javascript:void(0);" >
					<?php echo $lang_conv->fetch_word('NODE'); ?>&#187;
				</a>
			<ul>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodestart.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('NODESTART'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodestop.php','nodemngt_icon_set','nodemngt_head');" >
					<?php echo $lang_conv->fetch_word('NODESTOP');?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/noderestart.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('NODERESTART');?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodesuspend.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('SUSPENDNODE');?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodeususpend.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('USUSPENDNODE');?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/mountnode.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('MOUNTNODE'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/umountnode.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('UMOUNTNODE'); ?>
					</a>
				</li>
			</ul>				
		 </li>		 			
			<li>
				<a href="javascript:void(0);" >
					<?php echo $lang_conv->fetch_word('SET'); ?>&#187;
				</a>	
			<ul>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/sethostname.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('SETHOSTNAME'); ?>
					</a>
				</li>
				<li><a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/setnameservers.php','nodemngt_icon_set','nodemngt_head');">
						<?php echo $lang_conv->fetch_word('SETNAMESERVERS'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/setharddiskspace.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('SETHARDDISKSPACE'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/setmemory.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('SETMEMORY'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/addip.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('ADDIP'); ?>
					</a>
				</li>
				<li>
					<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/removeip.php','nodemngt_icon_set','nodemngt_head');">
					<?php echo $lang_conv->fetch_word('REMOVEIP'); ?>
					</a>
				</li>
			</ul>		
		</li>		
			<li>
				<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/meminfo.php','nodemngt_icon_set','nodemngt_head');">
				<?php echo $lang_conv->fetch_word('NODEMEMUSAGE'); ?>
				</a>
			</li>		
			<li>
				<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodestatus.php','nodemngt_icon_set','nodemngt_head');">
				<?php echo $lang_conv->fetch_word('STATUS'); ?>
				</a>
			</li>
		
			<li>
				<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/nodeuptime.php','nodemngt_icon_set','nodemngt_head');">
				<?php echo $lang_conv->fetch_word('UPTIME'); ?>
				</a>
			</li>
		
			<li>
				<a href="javascript:void(0);" onclick="javascript:show_nodemngt_data('../nmgnt/changeplan.php','nodemngt_icon_set','nodemngt_head');">
				<?php echo $lang_conv->fetch_word('CHANGEPLAN'); ?>
				</a>
			</li>		
	</ul>
</div>	
	
</div>
</div>

<div class="dhtmlgoodies_question">

<a href="javascript:void(0);" onclick="return false;"  class="menu_vtonfd_pos">		
		<font class="menu_font">V T O N F</font>
	</a>
</div>

<div class="dhtmlgoodies_answer">
<div>
<div id="dhtmlgoodies_menu4">
	<ul>	
		<li>
			<a href="javascript:void(0);" 
			onclick="show_vtonfd_data('../vtonfd/basicsetup.php','vtonf_icon_set','vtonf_head');" >
				<?php echo $lang_conv->fetch_word('BASICSETUP');?>
			</a>
		</li>		
		<li>
			<a href="javascript:void(0);" 
			onclick="javascript:show_vtonfd_data('../vtonfd/restartvtonfd.php','vtonf_icon_set','vtonf_head')">
				<?php echo $lang_conv->fetch_word('RESTARTVTONFD');?>
			</a>
		</li>		
		<li>
			<a href="javascript:void(0);" 
			onclick="javascript:show_vtonfd_data('../vtonfd/chgloginpswd.php','vtonf_icon_set','vtonf_head')">
				<?php echo $lang_conv->fetch_word('CHANGELOGNPSWD');?>
			</a>
		</li>	
		<li>
			<a href="javascript:void(0);" 
			onclick="show_vtonfd_data('../vtonfd/updatesettings.php','vtonf_icon_set','vtonf_head')">
				<?php echo $lang_conv->fetch_word('UPDATESETTINGS');?>
			</a>
		</li>	
		<li>
			<a href="javascript:void(0);" 
			onclick="show_vtonfd_data('../vtonfd/changetheme.php','vtonf_icon_set','vtonf_head')" >
				<?php echo $lang_conv->fetch_word('CHANGETHEME');?>
			</a>
		</li>	
		<li>
			<a href="javascript:void(0);" 
			onclick="show_vtonfd_data('../vtonfd/changelang.php','vtonf_icon_set','vtonf_head')" >
				<?php echo $lang_conv->fetch_word('CHANGELANG');?>
			</a>
		</li>		
	</ul>
</div>
</div>
</div>

<div class="dhtmlgoodies_question">

<a href="javascript:void(0);" onclick="return false;" class="menu_suprt_pos">		
		<font class="menu_font">SUPPORT SECTION</font>
	</a>
</div>

<div class="dhtmlgoodies_answer">
<div>
<div id="dhtmlgoodies_menu3">
	<ul>	
		<li>
			<a href="http://www.wiki.vtonf.com" target="_blank">
				<?php echo $lang_conv->fetch_word('REFERENCEMANUAL');?>
			</a>
		</li>		
		<li>
			<a href="http://www.support.vtonf.com" target="_blank">
				<?php echo $lang_conv->fetch_word('HELPDESK');?>
			</a>
		</li>		
		<li>
			<a href="http://www.news.vtonf.com" target="_blank">
				<?php echo $lang_conv->fetch_word('NEWSSECTION');?>
			</a>
		</li>		
	</ul>
</div>
</div>
</div>


<div id="helpbox">
<table id="help_table" border=1>
    <tr>
      <th>
      <?php echo $lang_conv->fetch_word("HELP") ?>
      </th>
    </tr>
    <tr>
      <td id="details"></td>
    </tr>    
</table>
    </div>
	
</div>

<div id="menu_color" class="menu_color"></div>
</div>

<div class="content_area" id="content_area"><!--Content div-->
<div class="white_c" id="white_c"> <!--White_C upper shadow div-->

<div id="white_c_t"  class="white_c_t"></div><!--White_C_T Cornershadow div-->

<div class="server_head_left"></div>
	<div class="main_head" id="btitle"></div>
<div class="server_head_right"></div>
<div class="bheader" id="bheader"></div>
<div class="detail" id="detail"></div>
<div id="bbody">

<div class="server_icon_set" id="server_icon_set">

<a href="javascript:void(0);" id="12" 
 onclick="javascript:doSetNote('NodeList');
 javascript:show_server_data('../server/nodelist.php','server_icon_set','server_head');" 
onmouseover="doUpdateNotes('NodeList','enter');"  onmouseout="doUpdateNotes('General','exit');">

	<div id="nodelisting_icon"  class="nodelisting_icon">
		<input type="image" src="image/nodelisting_icon.jpg" width="47" height="43">
	</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('AddNode');
javascript:show_server_data('../server/createnode.php','server_icon_set','server_head');" 
onmouseover="doUpdateNotes('AddNode','enter');" 
 onmouseout="doUpdateNotes('General','exit');">

<div id="nodecreate_icon" class="nodecreate_icon">
		<input type="image" src="image/nodecreate_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('Destroy');
javascript:show_server_data('../server/destroy.php','server_icon_set','server_head');"
 onmouseover="doUpdateNotes('Destroy','enter')" 
 onmouseout="doUpdateNotes('General','exit')">
<div id="destroy_icon" class="destroy_icon">
		<input type="image" src="image/destroy_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('AddConf');
javascript:show_server_data('../server/plans.php','server_icon_set','server_head');"
 onmouseover="doUpdateNotes('AddConf','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="confcreate_icon" class="confcreate_icon">
		<input type="image" src="image/confcreate_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('Openvz');
javascript:show_server_data('../server/openvz.php','server_icon_set','server_head');" 
onmouseover="doUpdateNotes('Openvz','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="openvz_icon" class="openvz_icon">
		<input type="image" src="image/openvz_icon.jpg" width="47" height="43">
</div>
</a>

<div id="nodelisting_name" class="nodelisting_name"><?php echo $lang_conv->fetch_word('NODELISTING');?></div>
<div id="createnode_name"  class="createnode_name"><?php echo $lang_conv->fetch_word('CREATENODE');?></div>
<div id="destroynode_name"  class="destroynode_name"><?php echo $lang_conv->fetch_word('DESTROYNODE');?></div>
<div id="createconf_name"  class="createconf_name"><?php echo $lang_conv->fetch_word('PLANS');?></div>
<div id="openvz_name"  class="openvz_name"><?php echo $lang_conv->fetch_word('OPENVZ');?></div>


</div>

<div id="service_icon_set" class="service_icon_set">

<a href="javascript:void(0);" onclick="javascript:doSetNote('ChangeRoot');
javascript:show_services_data('changerootpasswd.php','service_icon_set','services_head');" 
onmouseover="doUpdateNotes('ChangeRoot','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="pswdserver_icon"  class="pswdserver_icon">
		<input type="image" src="image/pswdserver_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="javascript:void(0);" onclick="javascript:doSetNote('ChangeNode');
javascript:show_services_data('changenoderootpwd.php','service_icon_set','services_head')" 
onmouseover="doUpdateNotes('ChangeNode','enter')" onmouseout="doUpdateNotes('General','exit')">
	<div id="pswdnode_icon"  class="pswdnode_icon">
		<input type="image" src="image/pswdnode_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="javascript:void(0);" onclick="javascript:doSetNote('RestartVE');
javascript:show_services_data('restartve.php','service_icon_set','services_head')" 
onmouseover="doUpdateNotes('RestartVE','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="restartve_icon"  class="restartve_icon">
		<input type="image" src="image/restartve_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="javascript:void(0);" onclick="javascript:doSetNote('Reboot');
show_services_data('rebootserver.php','service_icon_set','services_head')"
 onmouseover="doUpdateNotes('Reboot','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="restartserver_icon"  class="restartserver_icon">
		<input type="image" src="image/restartserver_icon.jpg" width="47" height="43" >
	</div>
</a>
<a href="javascript:void(0);" onclick="javascript:doSetNote('Load');
show_serverload_data('serverload.php','service_icon_set','services_head')" 
onmouseover="doUpdateNotes('Load','enter')"  
onmouseout="doUpdateNotes('General','exit')">
	<div id="serverload_icon"  class="serverload_icon">
		<input type="image" src="image/serverload_icon.jpg" width="47" height="43" >
	</div>
</a>

<div id="pswdserver_name"  class="pswdserver_name"><?php echo $lang_conv->fetch_word('PASSWORDSERVER');?></div>
<div id="pswdnode_name"  class="pswdnode_name">&nbsp;&nbsp;&nbsp; <?php echo $lang_conv->fetch_word('PASSWORDNODE');?></div>
<div id="restartve_name"  class="restartve_name"><?php echo $lang_conv->fetch_word('RESTARTVE');?></div>
<div id="restartserver_name"  class="restartserver_name"><?php echo $lang_conv->fetch_word('REBOOTSERVER');?></div>
<div id="serverload_name"  class="serverload_name">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<?php echo $lang_conv->fetch_word('SERVERLOAD');?></div>

</div>

<div id="nodemngt_icon_set" class="nodemngt_icon_set">

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODESTART');
javascript:show_nodemngt_data('../nmgnt/nodestart.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODESTART','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="nodestart_icon" class="nodestart_icon">
		<input type="image" src="image/nodestart_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODESTOP');
javascript:show_nodemngt_data('../nmgnt/nodestop.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODESTOP','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="nodestop_icon" class="nodestop_icon">
		<input type="image" src="image/nodestop_icon.jpg" width="47" height="43">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('NODERESTART');
javascript:show_nodemngt_data('../nmgnt/noderestart.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODERESTART','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="noderestart_icon" class="noderestart_icon">
		<input type="image" src="image/noderestart_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODESUSPEND');
javascript:show_nodemngt_data('../nmgnt/nodesuspend.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODESUSPEND','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="suspend_icon" class="suspend_icon">
		<input type="image" src="image/suspendnode_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODEUSUSPEND');
javascript:show_nodemngt_data('../nmgnt/nodeususpend.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODEUSUSPEND','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="ususpend_icon" class="ususpend_icon">
		<input type="image" src="image/ususpendnode_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODEMOUNT');
javascript:show_nodemngt_data('../nmgnt/mountnode.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODEMOUNT','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="mount_icon" class="mount_icon">
		<input type="image" src="image/nodemount_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODEUMOUNT');
javascript:show_nodemngt_data('../nmgnt/umountnode.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODEUMOUNT','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="umount_icon" class="umount_icon">
		<input type="image" src="image/nodeumount_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('ADDIP');
javascript:show_nodemngt_data('../nmgnt/addip.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('ADDIP','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="addip_icon" class="addip_icon">
		<input type="image" src="image/moreip_icon.jpg" width="47" height="43">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('REMOVEIP');
javascript:show_nodemngt_data('../nmgnt/removeip.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('REMOVEIP','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="removeip_icon" class="removeip_icon">
		<input type="image" src="image/removeip_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODESETHOSTNAME');
javascript:show_nodemngt_data('../nmgnt/sethostname.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODESETHOSTNAME','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="hostname_icon" class="hostname_icon">
		<input type="image" src="image/hostname_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('SETNAMSERVER');
javascript:show_nodemngt_data('../nmgnt/setnameservers.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('SETNAMSERVER','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="addnameservers_icon" class="addnameservers_icon">
		<input type="image" src="image/addnameservers_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('SETMEMORY');
javascript:show_nodemngt_data('../nmgnt/setmemory.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('SETMEMORY','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="addmem_icon" class="addmem_icon">
		<input type="image" src="image/addmem_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('SETSPACE');
javascript:show_nodemngt_data('../nmgnt/setharddiskspace.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('SETSPACE','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="addspace_icon" class="addspace_icon">
		<input type="image" src="image/addspace_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('NODEMEMUSAGE');
javascript:show_nodemngt_data('../nmgnt/meminfo.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODEMEMUSAGE','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="ostemplates_icon" class="ostemplates_icon">
		<input type="image" src="image/ostemplates_icon.jpg" width="47" height="43">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('NODESTATUS');
javascript:show_nodemngt_data('../nmgnt/nodestatus.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODESTATUS','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="status_icon" class="status_icon">
		<input type="image" src="image/status_icon.jpg" width="47" height="43">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('NODEUPTIME');
javascript:show_nodemngt_data('../nmgnt/nodeuptime.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NODEUPTIME','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="uptime_icon" class="uptime_icon">
		<input type="image" src="image/uptime_icon.jpg" width="47" height="43">
</div>
</a>


<a href="javascript:void(0);" onclick="javascript:doSetNote('NUMPROCESSALLOC');
javascript:show_nodemngt_data('../nmgnt/allram.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('NUMPROCESSALLOC','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="numprocess_icon" class="numprocess_icon">
		<input type="image" src="image/numprocess_icon.jpg" width="47" height="43">
</div>
</a>

<a href="javascript:void(0);" onclick="javascript:doSetNote('CHANGEPLAN');
javascript:show_nodemngt_data('../nmgnt/changeplan.php','nodemngt_icon_set','nodemngt_head');"
 onmouseover="doUpdateNotes('CHANGEPLAN','enter')"  onmouseout="doUpdateNotes('General','exit')">
<div id="changeplan_icon" class="changeplan_icon">
		<input type="image" src="image/changeplan_icon.jpg" width="47" height="43">
</div>
</a>

<div id="nodestart_name"  class="nodestart_name"><?php echo $lang_conv->fetch_word('NODESTART'); ?></div>
<div id="nodestop_name"  class="nodestop_name"><?php echo $lang_conv->fetch_word('NODESTOP'); ?></div>
<div id="noderestart_name"  class="noderestart_name"><?php echo $lang_conv->fetch_word('NODERESTART'); ?> </div>
<!--
<div id="noderebuild_name"  class="noderebuild_name">
</div>-->
<div id="suspendnode_name"  class="suspendnode_name"><?php echo $lang_conv->fetch_word('SUSPENDNODE'); ?></div>
<div id="ususpend_name"  class="ususpend_name"><?php echo $lang_conv->fetch_word('USUSPENDNODE'); ?></div>
<div id="mount_unmount_name"  class="mount_unmount_name"><?php echo $lang_conv->fetch_word('MOUNTNODE'); ?></div>
<div id="umount_name"  class="umount_name"><?php echo $lang_conv->fetch_word('UMOUNTNODE'); ?></div>
<div id="addip_name"  class="addip_name"><?php echo $lang_conv->fetch_word('ADDIP'); ?></div>
<div id="removeip_name"  class="removeip_name"><?php echo $lang_conv->fetch_word('REMOVEIP'); ?></div>
<div id="hostname_name"  class="hostname_name"><?php echo $lang_conv->fetch_word('SETHOSTNAME'); ?></div>
<div id="addnameservers_name"  class="addnameservers_name"><?php echo $lang_conv->fetch_word('SETNAMESERVERS'); ?></div>
<div id="addmem_name"  class="addmem_name"><?php echo $lang_conv->fetch_word('SETMEMORY'); ?></div>
<div id="addspace_name"  class="addspace_name"><?php echo $lang_conv->fetch_word('SETHARDDISKSPACE'); ?> </div>
<div id="ostemplates_name"  class="ostemplates_name"><?php echo $lang_conv->fetch_word('NODEMEMUSAGE'); ?></div>
<div id="status_name"  class="status_name"><?php echo $lang_conv->fetch_word('STATUS'); ?></div>
<div id="uptime_name"  class="uptime_name"><?php echo $lang_conv->fetch_word('UPTIME'); ?></div>
<div id="numprocess_name"  class="numprocess_name"><?php echo $lang_conv->fetch_word('NODEFREEMEM'); ?> </div>
<div id="changeplan_name"  class="changeplan_name"><?php echo $lang_conv->fetch_word('CHANGEPLAN'); ?> </div>


</div>


<div id="vtonf_icon_set" class="vtonf_icon_set">

<a href="#" onclick="javascript:doSetNote('BASICSETUP');
javascript:show_vtonfd_data('../vtonfd/basicsetup.php','vtonf_icon_set','vtonf_head');" 
onmouseover="doUpdateNotes('BASICSETUP','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="basicsetup_icon"  class="basicsetup_icon">
		<input type="image" src="image/basicsetup_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="#" onclick="javascript:doSetNote('RESTARTVTONFD');
javascript:show_vtonfd_data('../vtonfd/restartvtonfd.php','vtonf_icon_set','vtonf_head')" 
onmouseover="doUpdateNotes('RESTARTVTONFD','enter')" onmouseout="doUpdateNotes('General','exit')">
	<div id="restartvtonfd_icon"  class="restartvtonfd_icon">
		<input type="image" src="image/restartvtonfd_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="#" onclick="javascript:doSetNote('CHANGELOGINPSWD');
javascript:show_vtonfd_data('../vtonfd/chgloginpswd.php','vtonf_icon_set','vtonf_head')" 
onmouseover="doUpdateNotes('CHANGELOGINPSWD','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="changeploginpswd_icon"  class="changeploginpswd_icon">
		<input type="image" src="image/changeploginpswd_icon.jpg" width="47" height="43">
	</div>
</a>
<a href="#" onclick="javascript:doSetNote('UPDATESETTINGS');
show_vtonfd_data('../vtonfd/updatesettings.php','vtonf_icon_set','vtonf_head')"
 onmouseover="doUpdateNotes('UPDATESETTINGS','enter')"  onmouseout="doUpdateNotes('General','exit')">
	<div id="updatesettings_icon"  class="updatesettings_icon">
		<input type="image" src="image/updatesettings_icon.jpg" width="47" height="43" >
	</div>
</a>
<a href="#" onclick="javascript:doSetNote('CHANGETHEME');
show_vtonfd_data('../vtonfd/changetheme.php','vtonf_icon_set','vtonf_head')" 
onmouseover="doUpdateNotes('CHANGETHEME','enter')"  
onmouseout="doUpdateNotes('General','exit')">
	<div id="changetheme_icon"  class="changetheme_icon">
		<input type="image" src="image/changetheme_icon.jpg" width="47" height="43" >
	</div>
</a>

<a href="#" onclick="javascript:doSetNote('CHANGELANG');
show_vtonfd_data('../vtonfd/changelang.php','vtonf_icon_set','vtonf_head')" 
onmouseover="doUpdateNotes('CHANGELANG','enter')"  
onmouseout="doUpdateNotes('General','exit')">
	<div id="changelang_icon"  class="changelang_icon">
		<input type="image" src="image/changelang_icon.jpg" width="47" height="43" >
	</div>
</a>

<div id="basicsetp_name"  class="basicsetp_name">
	<?php echo $lang_conv->fetch_word('BASICSETUP');?>
</div>
<div id="restartvtonfd_name"  class="restartvtonfd_name">
	<?php echo $lang_conv->fetch_word('RESTARTVTONFD');?>
</div>
<div id="changeloginpswd_name"  class="changeloginpswd_name">
	<?php echo $lang_conv->fetch_word('CHANGELOGNPSWD');?>
</div>
<div id="updatesettings_name"  class="updatesettings_name">
	<?php echo $lang_conv->fetch_word('UPDATESETTINGS');?>
</div>
<div id="changetheme_name"  class="changetheme_name">
	<?php echo $lang_conv->fetch_word('CHANGETHEME');?>
</div>
<div id="changetlang_name"  class="changelang_name">
	<?php echo $lang_conv->fetch_word('CHANGELANG');?>
</div>

</div>


<div id="support_icon_set" class="support_icon_set">

<a href="#" onclick="javascript:doSetNote('VTONF_SUPPORT');open_window('http://www.wiki.vtonf.com');"
 onmouseover="doUpdateNotes('VTONF_SUPPORT','enter')"  onmouseout="doUpdateNotes('General','exit')">

<div id="refmanual_icon"  class="refmanual_icon">
	<img src="image/refmanual_icon.jpg" width="47" height="43" border="0">
</div>
</a>


<a href="#" onclick="javascript:doSetNote('VTONF_HELPDESK');open_window('http://www.support.vtonf.com');"
 onmouseover="doUpdateNotes('VTONF_HELPDESK','enter')"  onmouseout="doUpdateNotes('General','exit')">

<div id="helpdesk_icon"  class="helpdesk_icon">
		<img  src="image/helpdesk_icon.jpg" width="47" height="43" border="0">
		</div>
</a>

<a href="#" onclick="javascript:doSetNote('VTONF_NEWS');open_window('http://www.news.vtonf.com');"
 onmouseover="doUpdateNotes('VTONF_NEWS','enter')"  onmouseout="doUpdateNotes('General','exit')">

<div id="newsec_icon"  class="newsec_icon">
<img type="image" src="image/newsec_icon.jpg" width="47" height="43" border="0">
</div>
</a>

<div id="refmanual_name"  class="refmanual_name"><?php echo $lang_conv->fetch_word('REFERENCEMANUAL');?></div>
<div id="helpdesk_name"  class="helpdesk_name"><?php echo $lang_conv->fetch_word('HELPDESK');?></div>
<div id="newsection_name"  class="newsection_name"><?php echo $lang_conv->fetch_word('NEWSSECTION');?> </div>
</div>

<div class="server_head_left"></div>
<div id="server_head"  class="server_head"><?php echo $lang_conv->fetch_word('SERVER');?></div>
<div class="server_head_right"></div>

<div class="services_head_left"></div>
<div id="services_head"  class="services_head"><?php echo $lang_conv->fetch_word('SERVICES');?></div>
<div class="services_head_right"></div>

<div class="nodemngt_head_left"></div>
<div id="nodemngt_head"  class="nodemngt_head"><?php echo $lang_conv->fetch_word('NODEMANAGEMENT');?> </div>
<div class="nodemngt_head_right"></div>

<div class="vtonf_head_left"></div>
<div id="vtonf_head"  class="vtonf_head"><?php echo $lang_conv->fetch_word('VTONF_HEAD');?> </div>
<div class="vtonf_head_right"></div>

<div class="support_head_left"></div>
<div id="support_head"  class="support_head"><?php echo $lang_conv->fetch_word('SUPPORTSECTION');?> </div>
<div class="support_head_right"></div>

</div>

<div id="white_c_b"  class="white_c_b"></div>
</div>


<div class="white_r01">
<div id="white_r_t"  class="white_r_t"></div>
<div id="Layer2"  class="white_r_b"></div>
</div>

</div>

</div>
</body>
</html>
