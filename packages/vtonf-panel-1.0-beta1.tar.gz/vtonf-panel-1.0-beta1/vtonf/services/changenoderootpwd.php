<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to change the  
	* password of node. 
	*
	*/
	
include ('checksession.php');
include ('../lib/services.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
include ('../common/common_function.php');
$string = '';

if (isset ($_POST['vid'])) {
    $temp = split("-", $_POST['vid']);
    $vid = trim($temp[0]);

    $vpsuser = "root";
    $vpspasswd1 = trim($_POST['pass']);
    $vpspasswd2 = trim($_POST['pass1']);

    $string .= '<table class="table_msg">';
    $string .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';
    if (!($vpspasswd1 == $vpspasswd2)) {
        $string .= '<tr><td colspan=2 align=center>';
        $string .= $common_obj->display_message($lang_conv->fetch_word("BOTHPSWDSMATCH")."!! ", 0);
        $string .= '</td></tr>';
    } else {
        if (strlen($vpspasswd1) < 6) {
            $string .= '<tr><td colspan=2 align=center>';
            $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSSIXCHR")." !!!", 0);
            $string .= '</td></tr>';
        } else
            if (strlen($vpspasswd1) > 32) {
                $string .= '<tr><td colspan=2 align=center>';
                $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSMORECHR")."!!!", 0);
                $string .= '</td></tr>';
            } else {
                $val = $vpservice->change_passwd_node($vid, $vpsuser, $vpspasswd1);
                if (2 == $val) {
                    $string .= '<tr><td colspan=2 align=center>';
                    $string .= "Please enter correct informations";
                    $string .= '</td></tr>';
                } else
                    if ($val != 0) {
                        $string .= '<tr><td colspan=2 align=center>';
                        $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDCHNGSUCESS")." !!! ", 1);
                        $string .= '</td></tr>';
                    } else {
                        $string .= '<tr><td colspan=2 align=center>';
                        $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDCHNGFAIL")."!!!", 0);
                        $string .= '</td></tr>';
                    }
            }
    }
    $string .= '</table>';
    $string .= '</font>';
}
$val = $vpservice->getVpsId();
$range = count($val);

if ($range > 0) {
?>
<p>&nbsp;</p>
<div class="changenode_header_left"></div>
<div class="changenode_header"><?php echo $lang_conv->fetch_word("CHANGE_NODE_PSWD")?></div>
<div class="changenode_header_right"></div>

<div class="changenode_div">
<form action="" id="form" name="form" method="post">
	     <div class="vid_style" >
	     <?php echo $lang_conv->fetch_word("SELECT_NODEID")?>:
	     </div>
			<div class="changenode_dropdown">
			<select name="vid"   onchange="clearErrorMessage()">
			<?php

    for ($i = 0; $i < $range; $i ++) {
        list ($vied, $nproc, $status, $ip, $hostname) = split(':', $val[$i][0]);
        if (strcmp(trim($hostname), '') == 0) {
            $hostname = ''.$lang_conv->fetch_word("UNKNOWN");
        }

        if (strtoupper($status) == 'RUNNING')
            echo ("<option value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
    }
?>
			</select>
			</div>
	     <div class="chng_pswd_style" >
	     <?php echo $lang_conv->fetch_word("NODE_PSWD")?> :
	     </div>
	     <div class="chndpassword_text">
	     <input type="password" name="pass" maxlength="30"  >
	</div>
	
	     <div class="chang_repswd_style" > 
	     <?php echo $lang_conv->fetch_word("REENTER_ROOT_PSWD")?>:
	     </div>
	     <div class="chndrepassword_text">
	     <input type="password" name="pass1" maxlength="30" >
	</div>
		<div class="change_node_button">
        <a href="javascript:void(0);" class="buttonstyle"  onclick="doChangeNodePwd()">
        <?php echo $lang_conv->fetch_word("CHANGE")?></a>
        </div>
</form>
<div id="message" class="chgnode_style" >
<?php

} else {
    $string = '<font class="norecords_server" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $string;
?>
</div>
</div>



