<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is help file for showing  
	* the help content for Vtonf Control Panel.
	*
	*/
	

include('../include/config.php');
//Bugfix on help section in language
session_start();
/////
if (!(isset ($_SESSION['language']))) {
	$language_code = trim('en');
} else {
	$language_code = trim($_SESSION['language']);
}
$flag = 0;

$filepath = $_ABS_PATH.'doc/lang/help_'.$language_code;

$lines = file($filepath); 
$tab = trim($_POST['tab']);

foreach ($lines as $line) {
	if ($line != '') {
		list ($key, $value) = split(':', trim($line));

		if ($key == $tab) {
			if (trim($value) != '') {
				$help = $value;
				$flag = 1;
			}
			break;
		}
	}
}

if ($flag == 0) {
	$help = getDefault_text($tab);
}

print $help;



	  /**
		* getDefault_text is used to get the
		* default(English) help text.
		*
		* @param     $keyvalue  Help Key Value.
		* @return    $help  Default Help Text Value.
		*
		*/
function getDefault_text($keyvalue) {
include('../include/config.php');
	$lines = file($_ABS_PATH.'doc/lang/help', FILE_SKIP_EMPTY_LINES);
	$help = $keyvalue;
	foreach ($lines as $line) {
		if ($line != '') {
			list ($key, $value) = split(':', $line);
			if ($key == $keyvalue) {
				if (trim($value) != '') {
					$help = $value;
					$flag = 1;
					break;
				}
			}
		}
	}
	return $help;
}
?>
