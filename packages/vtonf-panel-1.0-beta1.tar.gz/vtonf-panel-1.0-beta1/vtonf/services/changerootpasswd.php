<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to change the  
	* root password of the server.
	*
	*/
	
include ('checksession.php');
include ('../common/lang_conversion.php');
include ('../lib/services.php');
include ('../common/common_function.php');
$string = "";

if (isset ($_POST['pass1']) && isset ($_POST['pass2'])) {

    $vpspasswd1 = trim($_POST['pass1']);
    $vpspasswd2 = trim($_POST['pass2']);

    $string .= '<table class="table_msg">';
    $string .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';
    if (!($vpspasswd1 == $vpspasswd2)) {
        $string .= '<tr><td colspan=2 align=center>';
        $string .= $common_obj->display_message($lang_conv->fetch_word("BOTHPSWDSMATCH")."!! ", 0);
        $string .= '</td></tr>';
    } else {
        if (strlen($vpspasswd1) < 6) {
            $string .= '<tr><td colspan=2 align=center>';
            $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSSIXCHR")." !!!", 0);
            $string .= '</td></tr>';
        } else
            if (strlen($vpspasswd1) > 32) {
                $string .= '<tr><td colspan=2 align=center>';
                $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDSMORECHR")."!!!", 0);
                $string .= '</td></tr>';
            } else {
                $val = $vpservice->change_passwd_mainserver($vpspasswd1);
                if ($val != 0) {
                    $string .= '<tr><td colspan=2 align=center>';
                    $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDCHNGSUCESS")." !!! ", 1);
                    $string .= '</td></tr>';
                } else {
                    $string .= '<tr><td colspan=2 align=center>';
                    $string .= $common_obj->display_message($lang_conv->fetch_word("PSWDCHNGFAIL")."!!!", 0);
                    $string .= '</td></tr>';
                }
            }
    }
    $string .= '</table>';
    $string .= '</font>';
}
?>

<p>&nbsp;</p>
<div class="chrt_header_left"></div>
<div class="chrt_header">
<?php echo $lang_conv->fetch_word("CHANGE_ROOT_PSWD")?></div>
<div class="chrt_header_right"></div>

<div class="chrt_listing_div">
<form action="" id="form" method="post">
   
	     <div class="root_style" > 
		    <?php echo $lang_conv->fetch_word("ROOT_PSWD")?> :
		 </div>
	    <div class="password_text">
	    	<input type="password" name="pass1" maxlength="30" >
		</div>
	     <div class="reenter_style" > 
	     	<?php echo $lang_conv->fetch_word("REENTER_ROOT_PSWD")?>:
	     </div>	
	     <div class="repassword_text" >
	     <input type="password" name="pass2" maxlength="30"  >
	     </div>
	     <div class="chrt_button">
	    	<a href="javascript:void(0);" class="buttonstyle"  onclick="doChangePwd()">
	    	<?php echo $lang_conv->fetch_word("CHANGE")?> 
       		 </a>
        </div>
    
</form>
<div id="message" class="chrt_pswd_style" >
<?php

print $string;
?>
</div>
</div>



