<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used validate the 
	* session for Vtonf Control Panel.
	*
	*/
	
session_start();

if(!(isset($_SESSION['username']))){
	echo "Are you kidding ?";
	include('../common/lang_conversion.php');
	$lang_conv = new language_map();
?>
	<input type="hidden" value="relogin" name="relogin" id="relogin"/> 
	<input type="hidden" value="<?php echo $lang_conv->fetch_word('EXPIRED')?>" name="expired" id="expired"/>
	
<?php
	session_destroy();
	echo '<meta http-equiv="refresh" content="0;../index.php" />';
	exit;	
	}
/* Setting expire time limit*/
$end_time=time();
$start_time=$_SESSION['time_start'];  
$ItemStartDate=$start_time;
$ItemEndDate = $end_time;
$TimeLeft = $ItemEndDate - $ItemStartDate; 
 if($TimeLeft > 0)
        {
        $ADayInSecs = 24 * 60 * 60;
        $Days = $TimeLeft / $ADayInSecs;
        $Days = intval($Days);
       
        $TimeLeft = $TimeLeft - ($Days * $ADayInSecs);
        $Hours = $TimeLeft / (60 * 60);
        $Hours = intval($Hours);
        $TimeLeft = $TimeLeft - ($Hours * 60 * 60);
       
        $Minutes = $TimeLeft / 60;
        $Minutes = intval($Minutes);
        $TimeLeft = $TimeLeft - ($Minutes * 60);
       
        $Seconds = $TimeLeft;
        $Seconds = intval($Seconds);
       
        $TimeLeft = $TimeLeft - ($Seconds / 60 * 60 );
        $MilliSeconds = $TimeLeft; 
	}
// limiting to 5 minute
$time_out=5;
 if($Minutes<$time_out){
    $_SESSION['time_start']=$end_time;
	}else{
	session_destroy();
echo '<input type="hidden" value="relogin" name="relogin" id="relogin"/>';
  } 
?>
