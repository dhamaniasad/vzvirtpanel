<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to restart the  
	* Virtual Environment.
	*
	*/
	
include ('checksession.php');
include ('../common/lang_conversion.php');
include ('../lib/server.php');
$string = '';
if (isset ($_POST['vemsg'])) {

    include ('../lib/services.php');
    include ('../common/common_function.php');

    $restartve->restart_ve();

    $string .= '<table class="table_msg">';
    $string .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("RESULT").'</th></tr>';

    $string .= '<tr><td colspan=2 >';
    $string .= $common_obj->display_message($lang_conv->fetch_word("RESTARTVESUCSS").'!!!', 1);
    $string .= '</td></tr>';
    $string .= '</table>';

}

$listval = $server->NodeListing();
$range = count($listval);
if ($range > 0) {
?>
<div class="restartve_header_left"></div>
<div class="restartve_header">
	<?php echo $lang_conv->fetch_word("RESTARTVE")?>
</div>
<div class="restartve_header_right"></div>

<form action="" method="post" id="restartve" name="restartve">
<div class="restartve_div">


<div class="restartve_question">
	<?php echo $lang_conv->fetch_word("ARE_SURE_RESTARTVE")?> ?
</div>
<div class="restartve_btn">
	<a href="javascript:void(0);" class="buttonstyle"  onclick="doRestartVE('restartve.php')"> 
	<?php echo $lang_conv->fetch_word("YES")?></a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="javascript:void(0);" class="buttonstyle"  onclick="doClearRestartVE()"> 
	<?php echo $lang_conv->fetch_word("NO")?></a>
</div>
<input type="hidden" name="vemsg" id="vemsg" 
value="<?php echo $lang_conv->fetch_word("RESTARTVEMSG")?>"/>

<div id="message" class="restartve_message">
<?php
} else {
    $string = '<font class="norecords_server" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $string;
?>
</div>
</form>
</div>


