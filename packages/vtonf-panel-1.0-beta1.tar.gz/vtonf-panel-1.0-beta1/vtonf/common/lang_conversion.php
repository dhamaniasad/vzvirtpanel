<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
  * 
  * All the Language related mapping
  * functions are included in this file
  *  
  */

if(!isset($_SESSION)){ 
       session_start();
}

class language_map {

	  /**
		* fetch_word is used to 
		* get the word for the input word
		* for the corressponding language
		*
		* @param     $inputword  input word
		* @return    $outputword 
		*
		*/
	
	function fetch_word($inputword) {
		$file_path = '../doc/lang/lang';
		$inputword = strtoupper($inputword);
		$language_code = $_SESSION['language'];
		$file_path1 = trim(trim($file_path)."_".trim($language_code));
		$flag = 0;
		$outputword = '';
		if (file_exists($file_path1)) {
			$FILE = file($file_path1);
			foreach ($FILE as $line) {
			$line = trim($line);

				if (strcasecmp($line,'')!=0) {
					list ($key, $value) = split(":", $line);
					if (strcasecmp($inputword,$key)==0) {
						if (strcasecmp($value,'')!=0) {
							$outputword = $value;
							$flag = 1;
						}
						break;
					}
				}
			}
		} else {
			$outputword = $this->getDefault_word($inputword,$file_path);
		}

		if ($flag == 0) {
			$outputword = $this->getDefault_word($inputword,$file_path);
		}
		return $outputword;
	}
	

	  /**
		* fetch_word_login is used to 
		* get the word for the input word
		* at the time of login
		* 
		*
		* @param     $inputword  input word
		* @return    $outputword 
		*
		*/
	
	function fetch_word_login($inputword) {
		$file_path = 'doc/lang/lang';
		$inputword = strtoupper($inputword);
		$language_code = $_SESSION['language'];
		$file_path1 = trim(trim($file_path)."_".trim($language_code));
		$flag = 0;
		if (file_exists($file_path1)) {
			$FILE = file($file_path1);
			foreach ($FILE as $line) {
			$line = trim($line);

				if (strcasecmp($line,'')!=0) {
					list ($key, $value) = split(":", $line);
					if (strcasecmp($inputword,$key)==0) {
						if (strcasecmp($value,'')!=0) {
							$outputword = $value;
							$flag = 1;
						}
						break;
					}
				}
			}
		} else {
			$outputword = $this->getDefault_word($inputword,$file_path);
		}

		if ($flag == 0) {
			$outputword = $this->getDefault_word($inputword,$file_path);
		}
		return $outputword;
	}

	  /**
		* getDefault_word is used to 
		* get the default word 
		* by formatting the input word
		* 
		*
		* @param     $inputword  input word
		* @return    $outputword 
		*
		*/

	function getDefault_word($inputword,$file_path) {
		$file_path = $file_path.'_en';		
		$inputword = strtoupper($inputword);
		$flag = 0;
		
		if (file_exists($file_path)) {			
			$FILE = file($file_path);
			foreach ($FILE as $line) {
				$line = trim($line);
				
				list($key,$value) = split(':', $line);
				if (strcasecmp($inputword,$key)==0) {
					if (strcasecmp($value,'')!=0) {
						$outputword = $value;
						$flag = 1;
					}
					break;
				}
			}
		}

		if ($flag == 0) {
			$inputword = str_ireplace("_"," ",$inputword);
			$outputword = ucwords(strtolower($inputword));
		}

		return $outputword;
	}
}
$lang_conv = new language_map();

?>