<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * All the Common functions are 
 * included in this php file.
 *
 */

class common_functions {

      /**
		* isValid_FileName is used to 
		* check whether filename given is valid or not
		*
		* @param     $configuration_name  configuration file name
		* @return    0  or 1
		*
		*/
	function isValid_FileName($configuration_name) {
		$configuration_name = trim($configuration_name);
		if (strlen($configuration_name) <= 0 || strlen($configuration_name) > 32) {
			return 1;
		}
			if (is_numeric($configuration_name)) {
				return 1;
			}			
				if (!ereg("^[a-zA-Z][a-zA-Z0-9\.\_]+$", $configuration_name)) {			
				return 1;
			}			
		
		return 0;
	}

	  /**
		* isValid_NameServer is used to 
		* check whether nameserver is valid or not
		*
		* @param     $nameserver  nameserver value
		* @return    0  or 1
		*
		*/
		
	function isValid_NameServer($nameserver) {

		$flag1 = 0;
		$flag2 = 0;
		$flag3 = 0;
		$flag4 = 0;

		$split_arry = split('\.', $nameserver);

		if ($nameserver == long2ip(ip2long($nameserver))) {
			if (!(count($split_arry) == 4)) {
				return 1;
			}

			if ((is_numeric($split_arry[0])) && (intval($split_arry[0]) != 0) && (intval($split_arry[0]) <= 255)) {
				$flag1 = 1;
			}
			if ((is_numeric($split_arry[1])) && (intval($split_arry[1]) >= 0) && (intval($split_arry[1]) <= 255)) {
				$flag2 = 1;
			}

			if ((is_numeric($split_arry[2])) && (intval($split_arry[2]) >= 0) && (intval($split_arry[2]) <= 255)) {
				$flag3 = 1;
			}
			if ((is_numeric($split_arry[3])) && (intval($split_arry[3]) >= 0) && (intval($split_arry[3]) <= 255)) {
				$flag4 = 1;
			}
		} else {
			return 1;
		}

		if ($flag1 && $flag2 && $flag3 && $flag4) {
			return 0;
		} else {
			return 1;
		}
	}

	  /**
		* valid_hostname is used to 
		* check whether hostname entered is valid or not
		* cheks whether any spaces or length greater than 64 	
		*
		* @param     $hostname hostname value
		* @return    0  or 1
		*
		*/

	function valid_hostname($hostname) {
		if (strlen($hostname) > 64) {
			return 1;
		} else {
			$domain_array = explode(".", $hostname);

			if (sizeof($domain_array) < 2) {
				return 1;
			} else {

				for ($i = 0; $i < sizeof($domain_array); $i ++) {
					if (!ereg("^[A-Za-z0-9][A-Za-z0-9-]+$", $domain_array[$i])) {
						return 1;
					} 
				}
			}
		}
		return 0;
	}

	  /**
		* isConfigFileExist is used to 
		* check whether config file exists or not
		*
		* @param     $configfilename  configuration file name
		* @return    0  or 1
		*
		*/

	function isConfigFileExist($configfilename) {
		include ('../include/config.php');
		$lines = file($SYS_CONFIG_DIR.'vpsconflist');
		foreach ($lines as $line) {
			$line = trim($line);
			if ($configfilename == $line) {
				return 1;
			}
		}
		return 0;
	}

	 /**
		* isValid_email is used to 
		* validate the email address
		*
		* @param     $email email address
		* @return    0  or 1
		*
		*/

	function isValid_email($email) {
		$pattern = "/^[\ a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,6}$/i";
		if (preg_match($pattern, $email)) {
			return 0;
		} else {
			return 1;
		}

	}

	  /**
		* isValid_phone is used to 
		* validate the email address
		*
		* @param     $phone Phone Number
		* @return    0  or 1
		*
		*/

	function isValid_phone($phone) {
		if (is_numeric($phone)) {
			return 0;
		} else {
			return 1;
		}
	}

	  /**
		* getLanguages is used to 
		* get the languages available
		*
		* @param     none
		* @return    $langs contains language list
		*
		*/

	function getLanguages() {
		$langs = array ();
		if (file_exists('common/language_list')) {
			$lang_list = file('common/language_list');
			foreach ($lang_list as $line) {
				if ($line != '') {
					list ($key, $value) = split(":", $line);
					if ($key != "") {
						$langs[$value] = $key;
					}
				}
			}
		} else {
			$langs['en'] = 'English';
		}

		return $langs;
	}

	  /**
		* getVtonfVerion is used to 
		* get the version of VTONF
		*
		* @param     none
		* @return    $versioncode version number
		*
		*/

	function getVtonfVerion() {
		include ('../include/config.php');
		$versioncode = '';
		$filepath = $SYS_CONFIG_DIR.'version';
		if (file_exists($filepath)) {
			$version = file($filepath);
			foreach ($version as $line) {
				if ($line != '') {
					$versioncode = trim($line);
				}
			}
		} else {
			$versioncode = '1.0-beta';
		}

		return $versioncode;
	}

	  /**
		* display_message is used to 
		* add the color for display message 
		*
		* @param     $message The input text message
		* @param     $message_type  1 for successfull and 0 for errormessage
		* @return    $langs contains language list
		*
		*/

	function display_message($message, $message_type) {
		$outputmsg = '';
		if (strcasecmp($message, '') != 0) {
			if ($message_type == 0) {
				$outputmsg .= '<font class="error_msg">'.$message.'</font>';
			} else {
				$outputmsg .= '<font class="sucess_msg">'.$message.'</font>';
			}
		}
		return $outputmsg;
	}

	  /**
		* checkLogin is used to 
		* validate the login page
		*
		* @param     $message The input text message
		* @param     $message_type  1 for successfull and 0 for errormessage
		* @return    $langs contains language list
		*
		*/
		
	function checkLogin() {
		$user2 = new login();

		if (isset ($_SESSION['username']) 
			) {

			if ($user2->checkUser($_SESSION['username'], $_SESSION['password']) != 0) {
				unset ($_SESSION['username']);
				unset ($_SESSION['password']);
				unset ($_SESSION['language']);
				return false;
			}
			return true;
		} else {
			return false;
		}
	}

	  /**
		* updateKeyValuePair is used to 
		* update the setup file for the key
		* 
		* @param     $keyWord  key word
		* @param     $keyValue  key value
		* @return    none 
		*
		*/

	function updateKeyValuePair($keyWord, $keyValue) {

		$file_content = '';
		$nochange = 0;
		$file = file('/etc/vtonf/setupvtonf');
		foreach ($file as $line) {
			$line = trim($line);
			if ($line != '') {
				list ($key, $value) = split(':', $line);
				if (strcasecmp($key, $keyWord) == 0) {
					if (strcasecmp($keyValue, $value) != 0) {
						$line = $key.':'.$keyValue;
					} else {
						$nochange = 1;
						break;
					}
				}
				$file_content .= $line;
				$file_content .= "\n";
			}
		}
		if ($nochange == 0) {
			$lang_file1 = fopen('/etc/vtonf/setupvtonf', 'w');
			fwrite($lang_file1, $file_content);
			fclose($lang_file1);
		}
	}

	  /**
		* getKeyValuePair is used to 
		* get the value for the corresponding key
		*
		* @param     $filename  key word
		* @param     $keyword  key value
		* @return    $keyValue 
		*
		*/

	function getKeyValuePair($filename, $keyword) {
		$keyValue = '';
		if (file_exists($filename)) {
			$file_list = file($filename);
			foreach ($file_list as $line) {
				$line = trim($line);
				list ($key, $value) = split(":", $line);
				if (strcasecmp($key, '') != 0) {
					if (strcasecmp($key, $keyword) == 0) {
						$keyValue = trim($value);
						break;
					}
				}
			}
		} else {
			$keyValue = '';
		}
		if (strcasecmp($keyValue, '') == 0) {
			$keyValue = '';
		}
		return $keyValue;
	}

	  /**
		* convert_kb_mb is used to 
		* convert kb to mb
		* 
		* @param     $kbValue
		* @return    $mbValue 
		*
		*/

	function convert_kb_mb($kbValue) {
		$temp = spliti("KB", strtoupper($kbValue));
		$mbValue = $temp[0] / 1024;
		$mbValue = round($mbValue, 3);
		$mbValue .= " MB";
		return $mbValue;
	}
	
	  /**
		* is_InRange is used to 
		* validate the ranges in the plan
		* 
		* @param     $valueSoft  Soft Limit Value
		* @param     $valueHard  Hard Limit Value
		* @return    0  or 1
		*
		*/
		
	function is_InRange($valueSoft, $valueHard) {

		if (is_numeric($valueSoft) && is_numeric($valueHard)) {

			if (strlen($valueSoft) > 0 && strlen($valueSoft) < 20 && 
			strlen($valueHard) > 0 && strlen($valueHard) < 20) {

				require_once ('../lib/server.php');
				include ('../include/config.php');
				$minValue = 0;
				$server = new server();
				$os_name = $server->getArc();

				if ($os_name == 'x86_64') {
					$maxValue = $OOMGUARPAGES_64_HARD;
				} else {
					$maxValue = $OOMGUARPAGES_HARD;
				}

				if ($valueSoft >= $minValue && $valueSoft <= $maxValue && $valueSoft <= $valueHard) {
					if (!($valueHard >= $minValue && $valueHard <= $maxValue)) {
						return 1;
					}
				} else {
					return 1;
				}
			} else {
				return 1;
			}
		} else {
			return 1;
		}
		return 0;
	}

	  /**
		* is_ValidNumeric is used to 
		* validate the ranges in the plan
		* according to the memory type
		* 
		* @param     $memValue  Memory Value
		* @param     $diskType  Memory Type(MB or GB)
		* @return    0  or 1
		*
		*/
		
	function is_ValidNumeric($memValue, $diskType) {

		if (is_numeric($memValue)) {
			$memValue = intval($memValue);

			if ($diskType == 'GB') {
				if ($memValue <= 0 || $memValue >= 200) {
					return 1;
				}
			} else {
				if ($memValue <= 0 || $memValue >= 204800) {
					return 1;
				}
			}
		} else {
			return 1;
		}
		return 0;
	}
}

$common_obj = new common_functions();
?>









