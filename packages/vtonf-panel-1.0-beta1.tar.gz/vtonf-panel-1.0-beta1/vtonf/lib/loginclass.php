<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * This class is used to handle
 * the login validation.
 *
 */

class login {

	private $username;
	private $password;

	  /**
		* checkUser is used to validate the 
		* username and password submitted
		*
		* @param     $username_submitted  Username
		* @param     $password_submitted  Password
		* @return    0 or 1 or 2 or 3 
		*
		*/
	function checkUser($username_submitted, $password_submitted) {
		$lines = file('/etc/vtonf/.vtonf.shadow');
		$data = explode(':', trim($lines[0]));
		$username = $data[0];
		$password = $data[1];
		$setval = 0;
		if (!strcmp($username_submitted, $username)) {
			$setval = 2;
		} else {
			$setval = 1;
		}

		if (!strcmp($password_submitted, $password) && $setval == 2) {
			$setval = 0;
		} else {
			if (!($setval == 1)) {
				$setval = 3;
			}
		}
		return $setval;

	}

}
$user = new login();
?>


