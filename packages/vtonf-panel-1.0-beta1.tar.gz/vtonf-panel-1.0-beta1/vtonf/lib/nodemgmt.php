<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * This class is used to handle 
 * the node management section of 
 * Vtonf Control Panel.
 *
 */

include ('../include/config.php');
include ('../services/checksession.php');

class nodeManagement {	
	  /**
		* nodeStart is used to start the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function nodeStart($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl start $veid \" ", $result);
		return $result;
	}
	
	  /**
		* nodeStop is used to stop the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function nodeStop($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl stop $veid \" ", $result);
		return $result;
	}
	
	  /**
		* nodeRestart is used to restart the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/

	function nodeRestart($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl restart $veid \" ", $result);
		return $result;
	}
	
	  /**
		* suspendNode is used to suspend the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/

	function suspendNode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl set $veid --disabled=yes --save\" ", $result['status']);
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl stop $veid \" ", $result['do']);
		return $result;
	}
	
	  /**
		* unsuspendNode is used to unsuspend the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function unsuspendNode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl set $veid --disabled=no --save\" ", $result['status']);
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl start $veid \" ", $result['do']);
		return $result;
	}
	
	  /**
		* mountNode is used to mount the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function mountNode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/mountnode $veid \" ", $result);
		return $result;
	}
	
	  /**
		* unmountNode is used to un-mount the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/	
	function unmountNode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/umountnode $veid \" ", $result);
		return $result;
	}
	
	  /**
		* setHostname is used to set 
		* the hostname for the node
		*
		* @param     $veid  Node Id
		* @param     $hostname Hostname
		* @return    $result  
		*
		*/	
	function setHostname($veid, $hostname) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/sethostname $veid $hostname\" ", $result);
		return $result;
	}
	
	  /**
		* addMoreIp is used to add ips to node
		*
		* @param     $veid  Node Id
		* @param     $ip  Ip value
		* @return    $result  
		*
		*/	
	function addMoreIp($veid, $ip) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/addmoreip $veid $ip\" ", $result);
		return $result;
	}	
	
	  /**
		* getsuspendednode is used to get 
		* the list of suspended nodes
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function getsuspendednode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/suspendinfo $veid\" ", $result);
		return $result;
	}
	
	  /**
		* getNodeIpList is used is used to get 
		* the list of nodes
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function getNodeIpList($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/iplist $veid \" ", $result['ips']);
		return $result;
	}
	
	  /**
		* removeIp is used to remove 
		* the ips from the node
		*
		* @param     $veid  Node Id
		* @param     $ip Ip value
		* @return    $result  
		*
		*/
	function removeIp($veid, $ip) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/removeip $veid $ip\" ", $result);
		return $result;
	}
	
	  /**
		* addNameservers is add the 
		* name servers to the node
		*
		* @param     $veid  Node Id
		* @param     $ns1  Name Server 1
		* @param     $ns2  Name Server 2
		* @param     $ns3  Name Server 3
		* @param     $ns4  Name Server 4
		* @return    $result  
		*
		*/
	function addNameservers($veid, $ns1, $ns2, $ns3, $ns4) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/addns $veid $ns1 $ns2 $ns3 $ns4 \" ", $result);
		return $result;
	}
	
	  /**
		* addMemory is used to add the 
		* memory value to the node
		*
		* @param     $veid  Node Id
		* @param     $mem   Memory Value
		* @return    $result  
		*
		*/
	function addMemory($veid, $mem) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/setmemory $veid $mem\" ", $result);
		return $result;
	}
	
	  /**
		* addMoreSpace is used to 
		* add more space to the node
		*
		* @param     $veid  Node Id
		* @param     $space  Disk Space 
		* @return    $result  
		*
		*/
	function addMoreSpace($veid, $space) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/setdiskspace $veid $space\" ", $result);
		return $result;
	}
	
	  /**
		* statusOfnode is used to get 
		* the status of the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function statusOfnode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/minstatusofnode $veid\" ", $result);
		return $result;
	}
	
	  /**
		* uptimeOfnode is used to get the 
		* load of the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/

	function uptimeOfnode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/anodeuptime $veid\" ", $result);
		return $result;
	}
	
	  /**
		* changePlan is used to change the 
		* plan for a node
		*
		* @param     $veid  Node Id
		* @param     $plan  Plan name
		* @return    $result  
		*
		*/
	function changePlan($veid, $plan) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/changeplan $veid $plan\" ", $result);
		return $result;
	}
	
	  /**
		* memInfo is used to get the 
		* memory information of the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function memInfo($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/nodememinfo $veid \" ", $result);
		return $result;
	}
	
	  /**
		* viewRam is used to get the 
		* RAM details of the node
		*
		* @param     $veid  Node Id
		* @return    $result  
		*
		*/
	function viewRam($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/anodefree $veid \" ", $result);
		return $result;
	}
}
$nodemgmt= new nodeManagement();
?>

