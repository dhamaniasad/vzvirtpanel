<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * This class is used to handle 
 * the server section of the 
 * Vtonf Control Panel.
 *
 */
include ('../services/checksession.php');
class server {
	  /**
		* getlastvid is used get the 
		* last node number value
		*
		* @param  none
		* @return $result  
		*
		*/
	function getlastvid() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/getlastvid\" ", $result);
		return $result;
	}
	
	  /**
		* getAllHostnames is used get all  
		* hostnames in the server
		*
		* @param  none
		* @return $result  
		*
		*/

	function getAllHostnames() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/allhostname\" ", $result);
		return $result;
	}
	
	  /**
		* getAllIpAddress is used get all  
		* ip address in the server
		*
		* @param  none
		* @return $result  
		*
		*/
	function getAllIpAddress() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/allip\" ", $result);
		return $result;
	}
	
	  /**
		* getAllIpAddress is used get all  
		* node ids in the server
		*
		* @param  none
		* @return $result  
		*
		*/
	function getAllVeid() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/allveid\"", $output);
		return $output;
	}
	
	  /**
		* NodeListing is used get the formatted 
		* node details server
		*
		* @param  none
		* @return $nodelistresult2  
		*
		*/
	function NodeListing() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/allveid\" ", $nodelistresult);
		$j= 0;
		$nodelistresult2= array ();
		foreach ($nodelistresult as $i) {
			exec("/usr/local/vtonf/bin/vpipe \"../scripts/nodelist  $i \"", $nodelistresult2[$j]);
			$j= $j +1;
		}
		return ($nodelistresult2);
	}

	  /**
		* CreateNode is used to create a node 
		*
		* @param     $veid       Node Id
		* @param     $ostemplate Operating System name
		* @param     $config     Configuration name
		* @param     $hostname   Hostname
		* @param     $ip         Ip Address
		* @return    $createresult  
		*
		*/
	function CreateNode($veid, $ostemplate, $config, $hostname, $ip) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/createnode $veid --ostemplate=$ostemplate --config=$config --hostname=$hostname  --ipadd=$ip\" ", $createresult);
		return $createresult;

	}

	  /**
		* DestroyNode is used to Destroy the node 
		*
		* @param     $veid    Node Id
		* @return    $output  
		*
		*/
	function DestroyNode($veid) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/destroynode $veid\" ", $output);
		return $output;
	}

	  /**
		* CreateConf is used to create a
		* configuration file. 
		*
		* @param     $confname Configuration file name
		* @return    $output  
		*
		*/
	function CreateConf($confname) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/createconf $confname\" ", $createconfresult);
		return $createconfresult;
	}

	  /**
		* deleteConf is used to delete a
		* configuration file. 
		*
		* @param     $confname Configuration file name
		* @return    $output  
		*
		*/
	function deleteConf($confname) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/deleteplan $confname\" ", $result);
		return $result;
	}

	  /**
		* renameConf is used to rename a
		* configuration file. 
		*
		* @param     $oldname Old Configuration file name
		* @param     $newname New Configuration file name
		* @return    $result  
		*
		*/
	function renameConf($oldname, $newname) {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/renameplan $oldname $newname\" ", $result);
		return $result;
	}

	  /**
		* getArc is used to check the type of 
		* Operating system 64 bit or 32 bit 
		*
		* @param  none
		* @return $uname  
		*
		*/
	function getArc() {
		exec("/usr/local/vtonf/bin/vpipe \"/bin/uname -i\" ", $uname);
		return $uname;
	}

	  /**
		* openvz_processor is used to get 
		* the details of the processor
		*
		* @param  none
		* @return $result  
		*
		*/
	function openvz_processor() {

		exec("/usr/local/vtonf/bin/vpipe \"../scripts/processor\" ", $result);
		return $result;

	}

	  /**
		* openvz_memory is used to get 
		* the details of the memory
		*
		* @param  none
		* @return $result  
		*
		*/
	function openvz_memory() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/meminfo\" ", $result);
		return $result;

	}

	  /**
		* openvz_kernel is used to get 
		* the details of the kernel
		*
		* @param  none
		* @return $result  
		*
		*/
	function openvz_kernel() {
		$openvzop= array ();
		exec("/usr/local/vtonf/bin/vpipe \"/bin/uname -r\" ", $openvzop['uname_r']);
		exec("/usr/local/vtonf/bin/vpipe \"/bin/uname -i\" ", $openvzop['uname_i']);
		exec("/usr/local/vtonf/bin/vpipe \"/bin/hostname\" ", $openvzop['hostname']);
		return $openvzop;

	}
	
	  /**
		* openvz_kernel is used to get 
		* the details of the kernel
		* 
		* @param  none
		* @return $result  
		*
		*/
	function openvz_harddisk() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/df\" ", $result);
		return $result;

	}

	  /**
		* getOSname is used to the name of 
		* the Operating System for a node
		*
		* @param     $veid_value Node Id
		* @return    $splitted_value or  "unknown"
		*
		*/
	function getOSname($veid_value) {
		include ('../include/config.php');

		$file= file($SYS_CONFIG_DIR.'veidvsostemplate');
		$num_lines= count($file);
		$i= 0;
		while ($i < $num_lines) {
			$value= $file[$i];
			$splitted_value= split(":", $value);
			if ($veid_value == $splitted_value[0]) {

				return $splitted_value[1];
			}
			$i ++;
		}
		return "unknown";
	}
}

$server= new server();
?>

