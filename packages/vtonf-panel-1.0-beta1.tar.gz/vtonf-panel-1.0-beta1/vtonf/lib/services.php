<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * This class is used to handle 
 * the Service section of the
 * Vtonf Control Panel.
 *
 */

include ('../include/config.php');
include ('../services/checksession.php');

class services {
	  /**
		* change_passwd_mainserver is used to 
		* change the password of the server
		*
		* @param     $verootpwd  password value
		* @return    $flag  
		*
		*/
	function change_passwd_mainserver($verootpwd) {
		$veroot= 'root';
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/pwd $veroot $verootpwd \"", $output);
		$flag= 1;
		foreach ($output as $key) {
			if (strpos($key, "error") === false) {
				$flag= 1;
			} else {
				$flag= 0;
				break;
			}

		}
		return $flag;
	}

	  /**
		* getVpsId is used to get the list
		* of the node details
		*
		* @param  none
		* @return $nodelistresult2  
		*
		*/
	function getVpsId() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/getveid\"", $nodelistresult);
		$nodelistresult2= array ();
		$j= 0;
		foreach ($nodelistresult as $i) {
			exec("/usr/local/vtonf/bin/vpipe \"../scripts/nodelist  $i \"", $nodelistresult2[$j]);
			$j= $j +1;
		}
		return $nodelistresult2;
	}
	
	  /**
		* change_passwd_node is used to 
		* change the password of the node
		*
		* @param     $vid  node number
		* @param     $vpsuser  vps user
		* @param     $vpspasswd  password
		* @return    $flag  
		*
		*/
	function change_passwd_node($vid, $vpsuser, $vpspasswd) {
		if (!($vid && $vpsuser && $vpspasswd)) {
			return 2;
		}
		exec("/usr/local/vtonf/bin/vpipe \"/usr/sbin/vzctl set $vid --userpasswd $vpsuser:$vpspasswd \"", $output);
		$flag= 1;
		foreach ($output as $key) {
			if (strpos($key, "failed") === false) {
				$flag= 1;
			} else {
				$flag= 0;
				break;
			}

		}
		return $flag;
	}
	
	  /**
		* restart_ve is used to 
		* restart the Virtual Environment 
		*
		* @param  none
	    * @return none 
		*/
	function restart_ve() {
		$_RETMP= popen('/usr/local/vtonf/bin/vpipe "/etc/rc.d/init.d/vz restart"', 'r') or die("Restart failed");

		while (!feof($_RETMP)) {
			$_VALUE1= fgets($_RETMP, 1048576);
			$_VALUE2= nl2br($_VALUE1);
		}
		pclose($_RETMP);
	}
	
	  /**
		* reboot_server is used to 
		* restart the server
		*
		* @param  none
	    * @return none 
		*/
	function reboot_server() {
		system('/usr/local/vtonf/bin/vpipe "reboot"');

	}
	
	  /**
		* showload_mainserver is used to 
		* get the load of the server
		*
		* @param  none
		* @return $output  
		*
		*/
	function showload_mainserver() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/uptime \"", $output);
		return $output;
	}
}
$load= new services();
$restartve= new services();
$vpservice= new services();
?>


