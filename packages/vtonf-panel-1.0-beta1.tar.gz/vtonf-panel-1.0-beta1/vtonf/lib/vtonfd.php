<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/**
 * This class is used to handle 
 * the Service section of the
 * Vtonf Control Panel.
 *
 */


include ('../services/checksession.php');

class vtonfd {
	  /**
		* change_login_passwd is used to change 
		* the login password of the Vtonf Control Panel
		*
		* @param     $verootpwd  login password value
		* @return    $flag  
		*
		*/
	function change_login_passwd($verootpwd) {
		include ('../include/config.php');
		$flag= 1;
		$lines= file($SYS_CONFIG_DIR.'.vtonf.shadow');
		$data= explode(':', trim($lines[0]));
		$username= $data[0];
		$file_content= $username.':'.$verootpwd;
		$lang_file1= fopen($SYS_CONFIG_DIR.'.vtonf.shadow', 'w');
		$flag= fwrite($lang_file1, $file_content);
		fclose($lang_file1);

		return $flag;
	}
	
	  /**
		* restartvtonfd is used to restart 
		* the Vtonf Control Panel
		*
		* @param     none
		* @return    $result  
		*
		*/
	function restartvtonfd() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/restartvtonf \" ", $result);
		return $result;
	}
	
	  /**
		* updateSettings is used to update 
		* the settings of the Vtonf Control Panel
		*
		* @param     none
		* @return    $result  
		*
		*/
	function updateSettings() {
		exec("/usr/local/vtonf/bin/vpipe \"../scripts/updatesettings \" ", $result);
		return $result;
	}
}
$vtonfd= new vtonfd();
?>

