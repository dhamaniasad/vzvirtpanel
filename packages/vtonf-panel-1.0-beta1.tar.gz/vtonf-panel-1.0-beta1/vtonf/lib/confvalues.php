<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

	
/**
 * This file is used to handle the plan values
 *
 */
 
include_once("../services/checksession.php");

	$_SESSION['KMEMSIZE_SOFT'] = 28745400; 
	$_SESSION['KMEMSIZE_HARD'] = 29580328; 
	$_SESSION['LOCKEDPAGES_SOFT'] = 512;
	$_SESSION['LOCKEDPAGES_HARD'] = 512; 
	$_SESSION['PRIVVMPAGES_SOFT'] = 65536;
	$_SESSION['PRIVVMPAGES_HARD'] = 65536;
	$_SESSION['SHMPAGES_SOFT'] = 43008; 
	$_SESSION['SHMPAGES_HARD'] = 43008; 
	$_SESSION['NUMPROC_SOFT'] = 480;
	$_SESSION['NUMPROC_HARD'] = 480; 
	
	$_SESSION['PHYSPAGES_SOFT'] = 0;
	$_SESSION['PHYSPAGES_HARD'] = 2147483647;	
	
	define('PHYSPAGES_64_SOFT',0) ;
	define('PHYSPAGES_64_HARD',9223372036854775807) ;
	
	$_SESSION['VMGUARPAGES_SOFT'] = 67584; 
	$_SESSION['VMGUARPAGES_HARD'] = 2147483647;	
	
	define('VMGUARPAGES_64_SOFT',67584) ;
	define('VMGUARPAGES_64_HARD',9223372036854775807);
	 
	$_SESSION['OOMGUARPAGES_SOFT'] = 52224;
	$_SESSION['OOMGUARPAGES_HARD'] = 2147483647;
	
	define('OOMGUARPAGES_64_SOFT',52224);
	define('OOMGUARPAGES_64_HARD',9223372036854775807);
	
	$_SESSION['NUMTCPSOCK_SOFT'] = 720;
	$_SESSION['NUMTCPSOCK_HARD'] = 720;
	$_SESSION['NUMFLOCK_SOFT'] = 376; 
	$_SESSION['NUMFLOCK_HARD'] = 412; 
	$_SESSION['NUMPTY_SOFT'] = 32;
	$_SESSION['NUMPTY_HARD'] = 32; 
	$_SESSION['NUMSIGINFO_SOFT'] = 512;
	$_SESSION['NUMSIGINFO_HARD'] = 512;
	$_SESSION['TCPSNDBUF_SOFT'] = 3440640;
	$_SESSION['TCPSNDBUF_HARD'] = 5406720;
	$_SESSION['TCPRCVBUF_SOFT'] = 3440640;
	$_SESSION['TCPRCVBUF_HARD'] = 5406720;
	$_SESSION['OTHERSOCKBUF_SOFT'] = 2252160;
	$_SESSION['OTHERSOCKBUF_HARD'] = 4194304;
	$_SESSION['DGRAMRCVBUF_SOFT'] = 524288;
	$_SESSION['DGRAMRCVBUF_HARD'] = 524288;
	$_SESSION['NUMOTHERSOCK_SOFT'] = 720;
	$_SESSION['NUMOTHERSOCK_HARD'] = 720;
	$_SESSION['NUMFILE_SOFT'] = 18624;
	$_SESSION['NUMFILE_HARD'] = 18624;
	$_SESSION['DCACHESIZE_SOFT'] = 7249920;
	$_SESSION['DCACHESIZE_HARD'] = 7249920;
	$_SESSION['NUMIPTENT_SOFT'] = 256;
	$_SESSION['NUMIPTENT_HARD'] = 256;
	$_SESSION['AVNUMPROC_SOFT'] = 360;
	$_SESSION['AVNUMPROC_HARD'] = 360;
	$_SESSION['MEMINFO_SOFT'] = "privvmpages";
	$_SESSION['MEMINFO_HARD'] = 1;
	$_SESSION['DISKSPACE_SOFT'] = 1572864;
	$_SESSION['DISKSPACE_HARD'] = 1572864;
	$_SESSION['DISKINODES_SOFT'] = 200000;
	$_SESSION['DISKINODES_HARD'] = 220000;
	$_SESSION['CPUUNITS'] = 1000;
	$_SESSION['QUOTATIME'] = 0;
	$_SESSION['DISABLED'] = "no";
	$_SESSION['ONBOOT'] = "yes";
	$_SESSION['QUOTAUGIDLIMIT'] = 0;
	
	$_SESSION['CPULIMIT'] = 0; 
	$_SESSION['NAMESERVER'] = "";
	$_SESSION['VE_ROOT'] = "/vz/root/\$VEID";
	$_SESSION['VE_PRIVATE'] = "/vz/private/\$VEID"; 
	$_SESSION['IPTABLES'] = "iptable_filter iptable_mangle ipt_limit ipt_multiport ipt_tos ipt_TOS ipt_REJECT ipt_TCPMSS ipt_tcpmss ipt_ttl ipt_LOG ipt_length ip_conntrack ipt_state iptable_nat ip_nat_ftp ";	
	
?>