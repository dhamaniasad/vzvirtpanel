<?php

#  The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This is the index page for  
	* Vtonf Control Panel 
	*
	*/
	
if (!isset ($_SESSION)) {
    session_start();
}
include_once ('./lib/loginclass.php');
include_once ('./include/config.php');
include_once ('./common/lang_conversion.php');

$login_url = './login/login.php';

if (file_exists($SYS_CONFIG_DIR.'setupvtonf')) {
    $setup_file = file($SYS_CONFIG_DIR.'setupvtonf');
    $lang_code = '';
    $theme = '';
    foreach ($setup_file as $line) {
        if (strcasecmp($line, '') != 0) {
            list ($key, $value) = split(":", $line);
            if ($key == 'language') {
                $lang_code = $value;
            }
            if ($key == 'theme') {
                $theme = $value;
            }
        }
    }
} else {
    $lang_code = 'en';
    $theme = 'default';
}

if (strcasecmp($lang_code, '') == 0) {
    $lang_code = 'en';
}
if (strcasecmp($theme, '') == 0) {
    $theme = 'default';
}
$_SESSION['theme'] = $theme;
$_SESSION['language'] = $lang_code;

include ($login_url);
displayLogin();
?>

