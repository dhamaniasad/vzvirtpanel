<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Node uptime page for a node
	*
	*/

include ('../services/checksession.php');
include ('../lib/server.php');
include ('../common/lang_conversion.php');
$veid= '';
if (isset ($_POST['node_veid'])) {

	$colorValueHr= '';
	$colorValueMin= '';
	$colorValueSec= '';

	include ("../lib/nodemgmt.php");

	$veid= $_POST['node_veid'];

	$serverload_array= $nodemgmt->uptimeOfnode($veid);

	$server_tmp= split("-", $serverload_array[0]);
	$time_label= $lang_conv->fetch_word(trim($server_tmp[0]));

	$time= trim($server_tmp[1]);

	$server_tmp= split("-", $serverload_array[1]);
	$avg_label= $lang_conv->fetch_word(trim($server_tmp[0]));

	$avg_load= split("\,", trim($server_tmp[1]));
	$server_tmp= split("-", $serverload_array[2]);
	$user_label= $lang_conv->fetch_word(trim($server_tmp[0]));

	$user_num= trim($server_tmp[1]);
	$server_tmp= split("-", $serverload_array[3]);
	$uptime_label= $lang_conv->fetch_word(trim($server_tmp[0]));

	$uptime_num= trim($server_tmp[1]);
	$time= split(":", $time);
	$hour= intval($time[0]);
	$min= intval($time[1]);
	$sec= intval($time[2]);

	if ($hour % 2) {
		$colorClassHr= "fontred";
	} else
		if ($hour % 3) {
			$colorClassHr= "fontblue";
		} else {
			$colorClassHr= "fontgreen";
		}
	if ($min % 2) {
		$colorClassMin= 'fontgreen';
	} else
		if ($min % 3) {
			$colorClassMin= 'fontred';
		} else {
			$colorClassMin= 'fontblue';
		}
	if ($sec % 2) {
		$colorClassSec= 'fontblue';
	} else
		if ($sec % 3) {
			$colorClassSec= 'fontgreen';
		} else {
			$colorClassSec= 'fontred';
		}
?>
<font class="uptime_table_font">
<div class="nodeuptimediv">

  <table  class="uptime_table">
  
  <tr>
  	<th colspan="5">  	
  	<?php echo $lang_conv->fetch_word("LOAD_NODE_MSG").' '.$veid?>  	
	</th>
  </tr>
  
  
  <tr>  	
      <td>
      	<?php echo $time_label?>
      </td>      
      
      <td>     
   			Hr<br>
   		<font class="<?php echo $colorClassHr?>"><?php echo $hour?></font>
   		</td>
   		<td>       Min<br>
   		<font class="<?php echo $colorClassMin?>"><?php echo $min?> </font>  
   		</td>
   		<td>      Sec     	<br>
   		<font class="<?php echo $colorClassSec?>"><?php echo $sec?></font>   		         
      </td>     
  </tr>
    
    
    <tr>
      <td >
      	<?php echo $avg_label?>
      </td>
      
      <td>      
      	 1Min <?php echo $lang_conv->fetch_word("BEFORE")?> <br>
      		<?php echo $avg_load[0]?>
      	</td>
      	<td>5Min <?php echo $lang_conv->fetch_word("BEFORE")?> <br>
      		<?php echo $avg_load[1]?>
      	</td>
      	<td>15Min <?php echo $lang_conv->fetch_word("BEFORE")?><br>
		  <?php echo $avg_load[2]?>
	  </td>
    </tr>      	
    
    <tr> 
      <td >
  	    <?php echo $user_label?>
      </td>
      <td colspan=3>
    	 <?php echo $user_num?>
      </td>
    </tr>
    
    <tr>
      <td >
      	<?php echo $uptime_label?>
      </td>
      	<td colspan=3>
      		<?php echo $uptime_num?>
      	</td>
    </tr>    
    
  </table>
</div>
</font>
	
<?php


} else {

	$listval= $server->NodeListing();
	$range= count($listval);

	if ($range > 0) {
		$runNodes= 0;
		for ($i= 0; $i < $range; $i ++) {
			list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
			if (trim($status) == 'running') {
				$runNodes ++;
				break;
			}
		}

		if ($runNodes > 0) {
?>

<div   class="nodestart_header_left"></div>
<div   class="nodestart_header">	
<?php echo $lang_conv->fetch_word("NODEUPTIME")?></div>
<div   class="nodestart_header_right"></div>

<div class="nodestart_div"> </div>
<div  class="nodestart_id_box">
<?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

<div id="Layer5">
  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false">
      
    <select id="node_veid" name="node_veid"  class="nodestart_drop_down"  onchange="clearErrorMessage()">
<?php


			for ($i= 0; $i < $range; $i ++) {
				list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
				if (trim($status) == 'running') {
					if ($hostname == '') {
						$hostname= ''.$lang_conv->fetch_word("UNKNOWN");
					}
					if ($veid == $vied) {
						echo ("<option selected value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
					} else {
						echo ("<option value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
					}

				}
			}
?>
    </select>
  </form>
  </div>
  <div class="nodeuptime_btn">
  <a href="javascript:void(0);" class="buttonstyle" 
  onclick="javascript:get_nodeuptime_data('nodeuptime.php');return false;">
  <?php echo $lang_conv->fetch_word("GETINFO")?>
  </a>
</div>
<div id="message" class="nodeuptime_message_style">
<?php

		} else {
			$outputmsg= '<font class="no_runningnodes">&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NORUNNINGNODES").'</b></center></font>';
		}
	} else {
		$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
	}
	print $outputmsg;
?>
</div>

<?php
}
?>