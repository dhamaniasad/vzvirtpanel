<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Remove Ip page for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ("../common/common_function.php");
include ($_ABS_PATH.'common/lang_conversion.php');

$outputmsg= '';
$tempveid= '';

if (isset ($_POST['node_veid'])) {

	$veid= $_POST['node_veid'];
	$ipcount= intval(trim($_POST['ipcount']));

	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2>'.$lang_conv->fetch_word("NODENUM").$veid.'</th></tr>';

	for ($i= 0; $i < $ipcount; $i ++) {
		if (isset ($_POST['n'.$i])) {
			$ip= trim($_POST['n'.$i]);
			$getresult= $nodemgmt->removeIp($veid, $ip);

			foreach ($getresult as $line) {
				$outputmsg .= '<tr><td colspan=2>';
				$outputmsg .= ''.$common_obj->display_message($line, 1);
				$outputmsg .= '</td></tr>';
			}
		}
	}
	$outputmsg .= '</table>';
}

$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {
?>

<div   class="nodestart_header_left"></div>
<div   class="nodestart_header"><?php echo $lang_conv->fetch_word("REMOVEIP")?></div>
<div   class="nodestart_header_right"></div>

<div class="nodeaddip_div"></div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false"> 
<div id="Layer5"> 
    <select  id="node_veid" name="node_veid"   class="nodestart_drop_down" onchange="fillIps()">
<?php

	for ($i= 0; $i < $range; $i ++) {

		list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
		if ($i == 0) {
			$tempveid= $vied;
		}

		if ($hostname == '') {
			$hostname= 'Unknown';
		}
		echo ("<option value=".$vied.">".$vied." - ".$hostname."</option>");
	}
?>
    </select>
    </div>
    
<div class="noderemoveip_text_box">
<?php echo $lang_conv->fetch_word("SELECT_IPS"); ?></div>
  
  <div id="maindiv" class="maindiv" >
  
  <div id="ipselectbox">
  <?php


	$iplist1= $nodemgmt->getNodeIpList($tempveid);

	$iplist= spliti(':', $iplist1['ips'][0]);

	$range= count($iplist);

	if ($range > 0) {
?>  
  <select name="iplist" id="iplist" size="3" multiple="multiple" class="removeip_dropdown">
  <?php


		foreach ($iplist as $ip) {
?>
		<option value="<?php echo $ip ?>"><?php echo $ip ?></option>
		<?php

		}
?>
	</select>

	<font size="1" class="fontred">*<?php echo $lang_conv->fetch_word("CTRLPRESS") ?></font>
  
  <?php

	} else {
?>
		<font class="error_msg">
		<input type="hidden" name="iplist" id="iplist" value=""/>
		<?php


		print ''.$lang_conv->fetch_word("NOIPS").'  '.$tempveid;
?>
		</font>
		<?php

	}
?>
  </div>
  <br>
  
 <a href="javascript:void(0);" class="buttonstyle" 
 onclick="doRemoveIPAction('removeip.php','<?php echo $lang_conv->fetch_word("SELECT_LIST"); ?>');return false;">
 <?php echo $lang_conv->fetch_word("Remove")?>
 </a>
      <br><br>
<div id="message">
<?php

	print $outputmsg;
?>
</div>     
      
  </div>  
  
	<input type="hidden" id="pagename" name="pagename" value="ip"/>
	<input type="hidden" id="addtype" name="addtype" value="<?php echo $lang_conv->fetch_word("ADDMORE")?>"/>
	<input type="hidden" id="removetype" name="removetype" value="<?php echo $lang_conv->fetch_word("REMOVEMORE")?>"/>
	<input type="hidden" id="selectips" name="selectips" value="<?php echo $lang_conv->fetch_word("SELECTIPS")?>"/>
	<input type="hidden" id="noips" name="noips" value="<?php echo $lang_conv->fetch_word("NOIPS_NODE")?>"/>
 <?php

} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
	print $outputmsg;
}
?>
  </form>