<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* nodesuspendmsg method is used to suspend 
	* a node and display the output
	*
	* @param     $veid node number
	* @return    $outputmsg 
	*
	*/

function nodesuspendmsg($veid) {

	include ('../lib/nodemgmt.php');
	include_once ('../common/lang_conversion.php');
	include ('../common/common_function.php');

	$lang_conv= new language_map();

	$outputmsg= '';

	$getresult= $nodemgmt->suspendNode($veid);

	$count= 0;
	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("NODENUM").$veid.'</th></tr>';

	foreach ($getresult['status'] as $line) {
		$outputmsg .= '<tr><td colspan=2 >';
		$outputmsg .= ''.$common_obj->display_message($line, 1);
		$outputmsg .= '</td></tr>';
	}

	foreach ($getresult['do'] as $line) {
		$outputmsg .= '<tr><td colspan=2 >';
		$outputmsg .= ''.$common_obj->display_message($line, 1);
		$outputmsg .= '</td></tr>';
		$count ++;
	}
	if ($count == 0) {
		$outputmsg .= '<tr><td colspan=2 >';
		$outputmsg .= ''.$common_obj->display_message($lang_conv->fetch_word('ALREADYSUSPEND'), 0);
		$outputmsg .= '</td></tr>';
	}
	$outputmsg .= '</table>';

	return $outputmsg;
}
?>