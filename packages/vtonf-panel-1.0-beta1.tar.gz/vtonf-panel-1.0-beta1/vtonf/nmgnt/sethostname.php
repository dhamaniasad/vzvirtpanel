<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Set HostName page for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ($_ABS_PATH.'common/lang_conversion.php');
include ("../common/common_function.php");

$outputmsg= '';
$hostname= '';
$veid= '';
if (isset ($_POST['node_veid'])) {

	$host_flag1= 1;
	$host_flag= 1;
	$host_ip_flag1= 1;
	$veid= $_POST['node_veid'];
	$hostname= $_POST['hostname'];
	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("NODENUM").$veid.'</th></tr>';

	if ($common_obj->valid_hostname($hostname)) {
		$host_flag1= 0;
	}
	if (strlen($hostname) < 16) {
		if (!$host_flag1) {
			if ($common_obj->isValid_NameServer($hostname)) {
				$host_ip_flag1= 0;
			}
		}
	} else {
		if (!$host_flag1) {
			$host_ip_flag1= 0;
			$hostname= "";
		}
	}

	$allhostnames= $server->getAllHostnames();
	foreach ($allhostnames as $line) {
		if ($line == $hostname) {
			$host_flag= 0;
			break;
		}
	}

	if (!$host_ip_flag1 && !$host_flag1) {
		$outputmsg .= '<tr><td >';
		$outputmsg .= $common_obj->display_message($lang_conv->fetch_word("HOSTNAME_EMPTY"), 0);
		$outputmsg .= '</tr></td>';
	} else
		if ($host_flag == 0) {
			$outputmsg .= '<tr><td >';
			$outputmsg .= $common_obj->display_message($lang_conv->fetch_word("HOSTNAME_UNIQUE"), 0);
			$outputmsg .= '</tr></td>';
		} else {
			$getresult= $nodemgmt->setHostname($veid, $hostname);

			foreach ($getresult as $line) {
				$outputmsg .= '<tr><td colspan=2 >';
				$outputmsg .= ''.$common_obj->display_message($line, 1);
				$outputmsg .= '</td></tr>';
			}
		}

	$outputmsg .= '</table>';
}
$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {
?>

<div class="nodestart_header_left"></div>
<div   class="nodestart_header"><?php echo $lang_conv->fetch_word("SETHOSTNAME")?></div>
<div class="nodestart_header_right"></div>

<div class="nodestart_div"> </div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

 <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false">  

    <select id="node_veid" name="node_veid"  class="nodestart_drop_down"  
    onchange="document.getElementById('hostname').value='';clearErrorMessage()">
<?php

	for ($i= 0; $i < $range; $i ++) {
		list ($vied, $nproc, $status, $ip, $hostname1)= split(':', $listval[$i][0]);
		if ($hostname1 == '') {
			$hostname1= $lang_conv->fetch_word("UNKNOWN");
		}
		if ($vied == $veid) {
			echo ("<option selected value=".$vied.">".$vied." - ".$hostname1." - ".strtoupper($status)."</option>");
		} else {
			echo ("<option value=".$vied.">".$vied." - ".$hostname1." - ".strtoupper($status)."</option>");
		}
	}
?>
    </select>
    
<div class="node_text_box">
<?php echo $lang_conv->fetch_word("ENTER_HOST")?> </div>
  
  <input class="node_text" type="text" id="hostname" name="hostname" value="<?php echo $hostname?>"/>
  
  <div class="sethostname_btn" >
  <a href="javascript:void(0);" class="buttonstyle" 
  onclick="doSetHostName('sethostname.php','detail');return false;">
  <?php echo $lang_conv->fetch_word("SET")?>
  </a>
</div>

  </form>
  
<div id="message" class="sethostname_message_style">

<?php

} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $outputmsg;
?>
</div>