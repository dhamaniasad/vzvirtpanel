<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Node Status page for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ('../lib/services.php');
include ($_ABS_PATH.'common/lang_conversion.php');

$outputmsg= '';
$veid= '';
if (isset ($_POST['node_veid'])) {
	$veid= $_POST['node_veid'];
	$getresult= $nodemgmt->statusOfnode($veid);

	$count= 0;
	$outputmsg .= '<table class="node_status">';
	$outputmsg .= '<tr><th colspan=7>'.$lang_conv->fetch_word("NODENUM").' '.$veid.'</th></tr>';

	foreach ($getresult as $line) {
		if ($count == 0) {
			$outputmsg .= '<tr>';
			$outputmsg .= '<td colspan=7 align="center">';
			$outputmsg .= $line;
			$outputmsg .= '</td>';
			$outputmsg .= '</tr>';
		} else {
			$outputmsg .= '<tr>';
			$line= spliti(" ", $line);
			$total= count($line);
			for ($i= 0; $i < $total; $i ++) {
				if (trim($line[$i]) != '') {
					if ($count == 1) {
						if ($i != 0) {
							$outputmsg .= '<th>';
							$outputmsg .= strtoupper($line[$i]);
							$outputmsg .= '</th>';
						}
					} else {
						if ($i == 5) {
							$outputmsg .= '<td align="center">';
							if ($line[$i] == 0) {
								$outputmsg .= $line[$i];
							} else {
								$outputmsg .= '<font class="error_msg" >'.$line[$i].'</font>';
							}
							$outputmsg .= '</td>';
						} else
							if ($i == 0) {
								$outputmsg .= '<td align="left">';
								$outputmsg .= strtoupper($line[$i]);
								$outputmsg .= '</td>';
							} else {
								$outputmsg .= '<td>';
								$outputmsg .= $line[$i];
								$outputmsg .= '</td>';
							}

					}
				}
			}
			$outputmsg .= '</tr>';

		}
		$count ++;
	}
	$outputmsg .= '</table>';
}

$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {

	$runNodes= 0;
	for ($i= 0; $i < $range; $i ++) {
		list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
		if (trim($status) == 'running') {
			$runNodes ++;
			break;
		}
	}

	if ($runNodes > 0) {
?>  

<div class="nodestart_header_left"></div>
<div   class="nodestart_header"><?php echo $lang_conv->fetch_word("NODESTATUS")?></div>
<div class="nodestart_header_right"></div>

<div class="nodestart_div"> </div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

<div id="Layer5">
  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false">
  
    <select id="node_veid" name="node_veid"  class="nodestart_drop_down"  onchange="clearErrorMessage()">
<?php


		for ($i= 0; $i < $range; $i ++) {
			list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
			if (trim($status) == 'running') {
				if ($hostname == '') {
					$hostname= ''.$lang_conv->fetch_word("UNKNOWN");
				}
				if ($veid == $vied) {
					echo ("<option selected value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
				} else {
					echo ("<option value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
				}
			}
		}
?>
    </select>
    
  </form>
  </div>
  <div class="nodestart_btn">
  <a href="javascript:void(0);" class="buttonstyle" 
  onclick="javascript:doNodeAction('nodestatus.php','detail');return false;">
  <?php echo $lang_conv->fetch_word("GETSTATUS")?>
  </a>
</div>
<div id="message" class="nodestatus_message_style">
<?php


	} else {
		$outputmsg= '<font class="no_runningnodes">&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NORUNNINGNODES").'</b></center></font>';
	}
} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $outputmsg;
?>
</div>