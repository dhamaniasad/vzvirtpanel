<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Set HardDisk Space page for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ($_ABS_PATH.'common/lang_conversion.php');
include ('../common/common_function.php');

$outputmsg= '';
$hdd= '';
$veid= '';
$memorytype= '';
if (isset ($_POST['node_veid'])) {
	$veid= $_POST['node_veid'];
	$hdd= $_POST['memory_value'];
	$memorytype= $_POST['setmemory_type'];

	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2 >'.'Node Number '.$veid.'</th></tr>';

	if (strlen($hdd) > 10) {
		$hdd= "";
	}
	if (is_numeric($hdd) && !$common_obj->is_ValidNumeric($hdd, $memorytype)) {
		if ($memorytype == 'MB') {
			$space= $hdd * 1024;
		} else {
			$space= $hdd * 1024 * 1024;
		}
		if ($memorytype == 'MB' && $hdd < 1024) {
			$outputmsg .= '<tr><td colspan=2>';
			$outputmsg .= ''.$common_obj->display_message($lang_conv->fetch_word("ENTERVALIDHSPACE"), 0);
			$outputmsg .= '</td></tr>';

			if (strlen($hdd) > 10) {
				$hdd= "";
			}
		} else {
			$getresult= $nodemgmt->addMoreSpace($veid, $space);

			foreach ($getresult as $line) {
				$outputmsg .= '<tr><td colspan=2>';
				$outputmsg .= ''.$common_obj->display_message($line, 1);
				$outputmsg .= '</td></tr>';
			}
			$hdd= "";
		}
	} else {
		$outputmsg .= '<tr><td colspan=2>';
		$outputmsg .= ''.$common_obj->display_message($lang_conv->fetch_word("ENTERVALIDHSPACE"), 0);
		$outputmsg .= '</td></tr>';

		if (strlen($hdd) > 10) {
			$hdd= "";
		}
	}

	$outputmsg .= '</table>';
}
$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {
?>


<div class="nodestart_header_left"></div>
<div   class="nodestart_header">	<?php echo $lang_conv->fetch_word("SET_SPACE")?></div>
<div class="nodestart_header_right"></div>

<div class="nodestart_div"> </div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false"> 
<div id="Layer5"> 
    <select id="node_veid" name="node_veid" class="nodestart_drop_down"
    onchange="document.getElementById('memory_value').value='';clearErrorMessage()">
<?php

	for ($i= 0; $i < $range; $i ++) {
		list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
		if ($hostname == '') {
			$hostname= $lang_conv->fetch_word("UNKNOWN");
		}

		if ($veid == $vied) {
			echo ("<option selected value=".$vied.">".$vied." - ".$hostname."</option>");
		} else {
			echo ("<option value=".$vied.">".$vied." - ".$hostname."</option>");
		}
	}
?>
    </select>
    </div>
  
<div class="nodens_text_box"><?php echo $lang_conv->fetch_word("ENTER_SPACE")?></div>
  <div>
  <input class="nodememory_text" type="text" 
  id="memory_value" name="memory_value" value="<?php echo $hdd ?>"/> 
  </div>
<div id="1">
<select id="setmemory_type" name="setmemory_type" class="setmemory_type" >
<?php

	if ($memorytype == 'GB') {
		print '<option selected value="GB">GB</option><option value="MB">MB</option>';
	} else {
		print '<option value="GB">GB</option><option selected value="MB">MB</option>';
	}
?>

</select>
</div>
  
  <div class="setharddisk_btn">
  <a href="javascript:void(0);" class="buttonstyle" onclick="doSetMemoryAction('setharddiskspace.php');return false;">
  <?php echo $lang_conv->fetch_word("SET")?> 
  </a>
</div>
    
  </form>
<div id="message" class="setharddisk_message_style">

<?php


} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $outputmsg;
?>
</div>