<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Set NameServers page for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ($_ABS_PATH.'common/lang_conversion.php');
include ("../common/common_function.php");

$outputmsg= '';
$veid= '';
if (isset ($_POST['node_veid'])) {

	$veid= $_POST['node_veid'];

	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2 >'.$lang_conv->fetch_word("NODENUM").'  '.$veid.'</th></tr>';

	$ns1= "";
	$ns2= "";
	$ns3= "";
	$ns4= "";
	$flag= 0;

	if (isset ($_POST['n1'])) {
		$ns1= $_POST['n1'];

		if (strlen($ns1) > 16) {
			$ns1= "";
		}

		if ($common_obj->isValid_NameServer($ns1)) {
			$outputmsg .= '<tr><td colspan=2 >';
			$outputmsg .= $common_obj->display_message($ns1.' '.$lang_conv->fetch_word("VALID_NS").'  !!', 0);
			$outputmsg .= '</td></tr>';
			$flag ++;
		}
	}
	if (isset ($_POST['n2'])) {
		$ns2= $_POST['n2'];

		if (strlen($ns2) > 16) {
			$ns2= "";
		}
		if ($common_obj->isValid_NameServer($ns2)) {
			$outputmsg .= '<tr><td colspan=2 >';
			$outputmsg .= $common_obj->display_message($ns2.' '.$lang_conv->fetch_word("VALID_NS").'  !!', 0);
			$outputmsg .= '</td></tr>';
			$flag ++;
		}
	}
	if (isset ($_POST['n3'])) {
		$ns3= $_POST['n3'];

		if (strlen($ns3) > 16) {
			$ns3= "";
		}
		if ($common_obj->isValid_NameServer($ns3)) {
			$outputmsg .= '<tr><td colspan=2 >';
			$outputmsg .= $common_obj->display_message($ns3.' '.$lang_conv->fetch_word("VALID_NS").'  !!', 0);
			$outputmsg .= '</td></tr>';
			$flag ++;
		}
	}
	if (isset ($_POST['n4'])) {
		$ns4= $_POST['n4'];

		if (strlen($ns4) > 16) {
			$ns4= "";
		}
		if ($common_obj->isValid_NameServer($ns4)) {
			$outputmsg .= '<tr><td colspan=2>';
			$outputmsg .= $common_obj->display_message($ns4.' '.$lang_conv->fetch_word("VALID_NS").'  !!', 0);
			$outputmsg .= '</td></tr>';
			$flag ++;
		}
	}

/*	$ns1= "";
	$ns2= "";
	$ns3= "";
	$ns4= "";
*/
	$getresult= $nodemgmt->addNameservers($veid, $ns1, $ns2, $ns3, $ns4);
	$ns1= "";
	$ns2= "";
	$ns3= "";
	$ns4= "";

	foreach ($getresult as $line) {
		$outputmsg .= '<tr><td colspan=2>';
		$outputmsg .= ''.$common_obj->display_message($line, 1);
		$outputmsg .= '</td></tr>';
	}
	$outputmsg .= '</table>';
	print $outputmsg;

} else {
	$listval= $server->NodeListing();
	$range= count($listval);

	if ($range > 0) {
?>

<div class="nodestart_header_left"></div>
<div   class="nodestart_header">	<?php echo $lang_conv->fetch_word("SET_NAMESERVERS")?></div>
<div class="nodestart_header_right"></div>

<div class="nodeaddip_div"></div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false"> 
<div id="Layer5"> 
    <select id="node_veid" name="node_veid"  class="nodestart_drop_down" onchange="clearNS()">
<?php


		for ($i= 0; $i < $range; $i ++) {
			list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
			if ($hostname == '') {
				$hostname= 'Unknown';
			}
			echo ("<option value=".$vied.">".$vied." - ".$hostname."</option>");
		}
?>
    </select>
    </div>
    
<div class="nodeaddip_text_box"><?php echo $lang_conv->fetch_word("ENTER_NAMESERVER")?></div>
  
  <div id="maindiv" class="maindiv" >
  
  
  <div id="myDiv">
  
	<table id="myDiv1">
		<tr>
			<td>
				<input type="text" id="n1" name="n1"/>
			</td>
			<td>
				<a href="javascript:void(0);" onclick="addElement();"><?php echo $lang_conv->fetch_word("ADDMORE")?></a>
			</td>
		</tr>
	</table>
	
      
</div><br>
	<a href="javascript:void(0);" class="buttonstyle" onclick="doSetNSAction('setnameservers.php');return false;"/>
  <?php echo $lang_conv->fetch_word("SET")?>
  </a>
      <br><br>      
<div id="message"></div>     
      
  </div>  
  
	<input type="hidden" id="pagename" name="pagename" value="nameserver"/>
	<input type="hidden" id="addtype" name="addtype" value="<?php echo $lang_conv->fetch_word("ADDMORE")?>"/>
	<input type="hidden" id="removetype" name="removetype" value="<?php echo $lang_conv->fetch_word("REMOVEMORE")?>"/>
 <?php


	} else {
		$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
		print $outputmsg;
	}
?>
  </form>
<?php


}
?>
