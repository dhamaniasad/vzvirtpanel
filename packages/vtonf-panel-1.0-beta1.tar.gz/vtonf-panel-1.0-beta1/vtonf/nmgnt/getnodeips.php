<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to fill  
	* the list with Ips for a node
	*
	*/

include ("../lib/nodemgmt.php");
include ($_ABS_PATH.'common/lang_conversion.php');

$_POST['iplist']= '';

$veid= $_POST['node_veid'];
$iplist1= $nodemgmt->getNodeIpList($veid);
$iplist= split(':', trim($iplist1['ips'][0]));
$range= count($iplist);
if (trim($iplist1['ips'][0]) == '') {
	$range= 0;
}
$outputmsg= '';
if ($range >= 1) {
	$outputmsg .= '<select name="iplist" id="iplist" class="iplist" '.'size="3" multiple="multiple">';
	foreach ($iplist as $ip) {
		if ($ip != '') {
			$outputmsg .= '<option value="'.$ip.'">'.$ip.'</option>';
		}
	}
	$outputmsg .= '</select>';

	$outputmsg .= '<font class="ctrlpress">*'.$lang_conv->fetch_word("CTRLPRESS").'</font>';
} else {
	$outputmsg .= '<font class="noips">';
	$outputmsg .= '<br>'.$lang_conv->fetch_word("NOIPS").' '.$veid;
	$outputmsg .= '</font>';
}
print $outputmsg;
?>