<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Add IPs page for a node
	*
	*/

include ('../services/checksession.php');
include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ("../common/common_function.php");
include ($_ABS_PATH.'common/lang_conversion.php');

$outputmsg= '';

if (isset ($_POST['node_veid'])) {

	$veid= $_POST['node_veid'];
	$outputmsg .= '<table class="table_msg">';
	$outputmsg .= '<tr><th colspan=2>'.$lang_conv->fetch_word("NODENUM").' '.$veid.'</th></tr>';
	for ($i= 1; $i <= 5; $i ++) {
		if (isset ($_POST['n'.$i])) {
			$ip= trim($_POST['n'.$i]);
			$split_arry= spliti('\.', $ip);
			$ip_flag= 1;
			if (strlen($ip) > 20) {
				$ip= "";
			}
			if (!($common_obj->isValid_NameServer($ip))) {

				$allips= $server->getAllIpAddress();
				foreach ($allips as $line) {
					if ($line == $ip) {
						$ip_flag= 0;
						break;
					}
				}

				if (!$ip_flag) {
					$outputmsg .= '<tr><td colspan=2>';
					$outputmsg .= $common_obj->display_message($lang_conv->fetch_word("IPADRR_UNIQUE"), 0);
					$outputmsg .= '</td></tr>';
				} else {
					$getresult= $nodemgmt->addMoreIp($veid, $ip);

					foreach ($getresult as $line) {
						$outputmsg .= '<tr><td colspan=2>';
						$outputmsg .= ''.$common_obj->display_message($line, 1);
						$outputmsg .= '</td></tr>';
					}
				}
			} else {
				$outputmsg .= '<tr><td colspan=2>';
				$outputmsg .= $common_obj->display_message($lang_conv->fetch_word("NOTVALIDIP"), 0);
				$outputmsg .= '</td></tr>';
			}
		}
	}
	$outputmsg .= '</table>';

	print $outputmsg;

} else {

	$listval= $server->NodeListing();
	$range= count($listval);
	if ($range > 0) {
?>
<div class="nodestart_header_left"></div>
<div   class="nodestart_header">	<?php echo $lang_conv->fetch_word("ADDIP")?></div>
<div class="nodestart_header_right"></div>

<div class="nodeaddip_div">

</div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false"> 
<div id="Layer5"> 
    <select id="node_veid" name="node_veid"  class="nodestart_drop_down" onchange="clearNS()">
<?php


		for ($i= 0; $i < $range; $i ++) {
			list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
			if ($hostname == '') {
				$hostname= $lang_conv->fetch_word("UNKNOWN");
			}
			echo ("<option value=".$vied.">".$vied." - ".$hostname."</option>");
		}
?>
    </select>
    </div>
    
<div class="nodeaddip_text_box"><?php echo $lang_conv->fetch_word("ENTER_IP")?></div>
  
  <div id="maindiv" class="maindiv">
  
  
  <div id="myDiv">
  
	<table id="myDiv1">
		<tr>
			<td>
				<input type="text" id="n1" name="n1"/>
			</td>
			<td>
				<a href="javascript:void(0);" onclick="addElement();"><?php echo $lang_conv->fetch_word("ADDMORE")?></a>
			</td>
		</tr>
	</table>
	
      
</div>
<br>

 <a href="javascript:void(0);" class="buttonstyle" onclick="doAddIPAction('addip.php');return false;">
 <?php echo $lang_conv->fetch_word("ADD")?>
  </a>

      <br><br>      
      
<div id="message">

</div>     
      
  </div>  
  
	<input type="hidden" id="pagename" name="pagename" value="ip"/>
	<input type="hidden" id="addtype" name="addtype" value="<?php echo $lang_conv->fetch_word("ADDMORE")?>"/>
	<input type="hidden" id="removetype" name="removetype" value="<?php echo $lang_conv->fetch_word("REMOVEMORE")?>"/>
 <?php


	} else {
		$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
		print $outputmsg;
	}
?>
  </form>
<?php
}
?>