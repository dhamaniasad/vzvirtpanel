<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Add RAM Size page for a node
	*
	*/

include ('../services/checksession.php');
include ("../lib/nodemgmt.php");
include ('../lib/server.php');
include ($_ABS_PATH.'common/lang_conversion.php');
include ($_ABS_PATH.'common/common_function.php');

$outputmsg= '';
$veid= '';
$value= '';
if (isset ($_POST['node_veid'])) {
	$veid= $_POST['node_veid'];

	$val= $nodemgmt->viewRam($veid);

	$memTotal= $val[0];
	$memFree= $val[1];
	$swapTotal= $val[11];
	$swapFree= $val[12];
	$buffers= $val[2];
	$cached= $val[3];
	$swapCached= $val[4];
	$active= $val[5];
	$inactive= $val[6];

	$line1t= spliti(":", $memTotal);
	$line2t= spliti(":", $memFree);
	$line3t= spliti(":", $swapTotal);
	$line4t= spliti(":", $swapFree);
	$line5t= spliti(":", $buffers);
	$line6t= spliti(":", $cached);
	$line7t= spliti(":", $swapCached);
	$line8t= spliti(":", $active);
	$line9t= spliti(":", $inactive);

	$line1= array ();
	$line2= array ();
	$line3= array ();
	$line4= array ();
	$line5= array ();
	$line6= array ();
	$line7= array ();
	$line8= array ();
	$line9= array ();

	$j= 0;
	for ($i= 0; $i < count($line1t); $i ++) {
		if (strcasecmp(trim($line1t[$i]), '') != 0) {
			$line1[$j]= $lang_conv->fetch_word(strtoupper(trim($line1t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line2t); $i ++) {
		if (strcasecmp(trim($line2t[$i]), '') != 0) {
			$line2[$j]= $lang_conv->fetch_word(strtoupper(trim($line2t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line3t); $i ++) {
		if (strcasecmp(trim($line3t[$i]), '') != 0) {
			$line3[$j]= $lang_conv->fetch_word(strtoupper(trim($line3t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line4t); $i ++) {
		if (strcasecmp(trim($line4t[$i]), '') != 0) {
			$line4[$j]= $lang_conv->fetch_word(strtoupper(trim($line4t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line5t); $i ++) {
		if (strcasecmp(trim($line5t[$i]), '') != 0) {
			$line5[$j]= $lang_conv->fetch_word(strtoupper(trim($line5t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line6t); $i ++) {
		if (strcasecmp(trim($line6t[$i]), '') != 0) {
			$line6[$j]= $lang_conv->fetch_word(strtoupper(trim($line6t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line7t); $i ++) {
		if (strcasecmp(trim($line7t[$i]), '') != 0) {
			$line7[$j]= $lang_conv->fetch_word(strtoupper(trim($line7t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line8t); $i ++) {
		if (strcasecmp(trim($line8t[$i]), '') != 0) {
			$line8[$j]= $lang_conv->fetch_word(strtoupper(trim($line8t[$i])));
			$j ++;
		}
	}

	$j= 0;
	for ($i= 0; $i < count($line9t); $i ++) {
		if (strcasecmp(trim($line9t[$i]), '') != 0) {
			$line9[$j]= $lang_conv->fetch_word(strtoupper(trim($line9t[$i])));
			$j ++;
		}
	}

	$usedMem= $line1[1] - $line2[1];

	$lineUsedMem[0]= $lang_conv->fetch_word("MEMUSED");
	$lineUsedMem[1]= $common_obj->convert_kb_mb($usedMem."KB");

	$usedSwap= $line3[1] - $line4[1];
	$lineUsedSwap[0]= $lang_conv->fetch_word("SWAPUSED");
	$lineUsedSwap[1]= $common_obj->convert_kb_mb($usedSwap."KB");

	$line1[1]= $common_obj->convert_kb_mb($line1[1]);
	$line2[1]= $common_obj->convert_kb_mb($line2[1]);
	$line3[1]= $common_obj->convert_kb_mb($line3[1]);
	$line4[1]= $common_obj->convert_kb_mb($line4[1]);
	$line5[1]= $common_obj->convert_kb_mb($line5[1]);
	$line6[1]= $common_obj->convert_kb_mb($line6[1]);
	$line7[1]= $common_obj->convert_kb_mb($line7[1]);
	$line8[1]= $common_obj->convert_kb_mb($line8[1]);
	$line9[1]= $common_obj->convert_kb_mb($line9[1]);

	$totram= split(" MB", trim($line1[1]));
	$freeram= split(" MB", trim($line2[1]));

	//----------------------------------------------------------

	$GET1["disk_values"]= '';
	$GET2["disk_labels"]= '';
	$value1 .= '<div class="ovzmem_pie_div_nfm">';
	$value1 .= '<table class="ovzhdd">';
	$value1 .= '<tr>';
	$value1 .= '<th colspan=2 >';
	$value1 .= ''.$lang_conv->fetch_word("TYPE");
	$value1 .= '</th>';

	$value1 .= '<th  >';
	$value1 .= ''.$lang_conv->fetch_word("PARTITION_GRAPH");
	$value1 .= '</th>';

	$value1 .= '<th colspan=3 >';
	$value1 .= ''.$lang_conv->fetch_word("PARTITION_INFO");
	$value1 .= '</th>';
	$value1 .= '</tr>';
	$row= 0;

	$value1 .= '<tr>';
	$value1 .= '<td colspan=2 >';
	$value1 .= 'RAM';
	$value1 .= '</td>';
	$value1 .= '<td >';
	$availpercentage= intval(($freeram[0] / $totram[0]) * 100);
	$usedpercentage= (100 - $availpercentage);
	$GET1["disk_values"]= $usedpercentage.'*'.$availpercentage;
	$GET2["disk_labels"]= $lang_conv->fetch_word("USED").'*'.$lang_conv->fetch_word("AVAILABLE");

	if ($usedpercentage > 90) {
		$col1= "FF130B"; //if greater than 90% showing in RED 
		$col2= "3415FF"; //if greater than 90% showing in BLUE 
	} else {
		$col1= "23C8FF";
		$col2= "003466";
	}

	$value1 .= '<img src="../server/piechart.php?'.'disk_values='.$GET1["disk_values"].'&disk_labels='.$GET2["disk_labels"].'&col1='.$col1.'&col2='.$col2.'"/>';
	$value1 .= '</td>';
	$value1 .= '<td colspan=3 >';

	$value1 .= $lang_conv->fetch_word("TOTAL_SPACE").' - '.$line1[1].'<br>';
	$value1 .= $lang_conv->fetch_word("USED_SPACE").'  - '. ($totram[0] - $freeram[0])."MB".'<br>';
	$value1 .= $lang_conv->fetch_word("FREE_SPACE").'  - '.$line2[1].'<br>';
	$value1 .= '</td>';
	$value1 .= '</tr>';
	$value1 .= '</table>';
	$value1 .= '<font class="error_msg">&#8226;</font><font class="small_font">'.$lang_conv->fetch_word("INDICATE_RAM").' 90%</font>';
	$value1 .= '</div>';

	//----------------------------------------------------------	
	$value .= '<div class="nodefree_div" >';

	$value .= '<table class="nodefree_table">';

	$value .= '<tr>';
	$value .= '<th>';
	$value .= $lang_conv->fetch_word("TYPE");
	$value .= '</th>';
	$value .= '<th>';
	$value .= $lang_conv->fetch_word("VALUE");
	$value .= '</th>';
	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line1[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= ''.$line1[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line2[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= $line2[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$lineUsedMem[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= $lineUsedMem[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line5[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= ''.$line5[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line6[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= ''.$line6[1];
	$value .= '</td>';

	$value .= '</tr>';
	
	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line8[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= ''.$line8[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '<tr>';
	$value .= '<td>';
	$value .= ''.$line9[0];
	$value .= '</td>';

	$value .= '<td>';
	$value .= ''.$line9[1];
	$value .= '</td>';

	$value .= '</tr>';

	$value .= '</table>';
	$value .= '<font class="smallfont">* '.$lang_conv->fetch_word("ALLFIELDSMB").'</font>';
	$value .= '</div>';

	$outputmsg .= $value;
}

$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {

	$runNodes= 0;
	for ($i= 0; $i < $range; $i ++) {
		list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
		if (trim($status) == 'running') {
			$runNodes ++;
			break;
		}
	}
	if ($runNodes > 0) {
?>

<div class="nodestart_header_left"></div>
<div  class="nodestart_header"> <?php echo $lang_conv->fetch_word("NODEFREEMEM")?></div>
<div class="nodestart_header_right"></div>
<div class="nodestart_div"> </div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

<div id="Layer5">
  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false">  
    <select id="node_veid" name="node_veid"  class="nodestart_drop_down" onchange="clearErrorMessage()">
<?php

		for ($i= 0; $i < $range; $i ++) {
			list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
			if (trim($status) == 'running') {
				if ($hostname == '') {
					$hostname= ''.$lang_conv->fetch_word("UNKNOWN");
				}
				if ($veid == $vied) {
					echo ("<option selected value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
				} else {
					echo ("<option value=".$vied.">".$vied." - ".$hostname." - ".strtoupper($status)."</option>");
				}

			}
		}
?>
    </select>
  </form>
  </div>
  <div class="nodestart_btn">
  <a href="javascript:void(0);" class="buttonstyle" 
  onclick="javascript:doNodeAction('allram.php','detail');return false;">
  	<?php echo $lang_conv->fetch_word("GETINFO")?> 
  </a>
</div>
<div id="message" class="nodememfree_message_style">
 
<?php
		print $outputmsg;
		print $value1;
	} else {
		$outputmsg= '<font class="no_runningnodes">&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NORUNNINGNODES").'</b></center></font>';
		print $outputmsg;
	}
} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
	print $outputmsg;
}
?>
</div>