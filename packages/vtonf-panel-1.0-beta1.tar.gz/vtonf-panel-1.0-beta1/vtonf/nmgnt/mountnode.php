<?php

#The VTONF Control Panel
#  Copyright (C) 2008 bobcares.com . All rights reserved.

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 2 of the License.
#   
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  /**
	* This file is used to view  
	* the Mounting page for a node
	*
	*/

include ('../lib/server.php');
include ('../common/lang_conversion.php');
$outputmsg= '';
$veid= '';
if (isset ($_POST['node_veid'])) {
	include ('mountnode-c.php');
	$veid= $_POST['node_veid'];
	$outputmsg= nodemountmsg($veid);
}
$listval= $server->NodeListing();
$range= count($listval);

if ($range > 0) {
?>
  
<div   class="nodestart_header_left"></div>
<div   class="nodestart_header">	<?php echo $lang_conv->fetch_word("NODEMOUNT")?></div>
<div   class="nodestart_header_right"></div>

<div class="nodestart_div"> </div>
<div  class="nodestart_id_box"><?php echo $lang_conv->fetch_word("SELECT_NODEID")?>: </div>

  <form id="nodeaction_form" name="nodeaction_form" method="post" onsubmit="return false"> 
<div id="Layer5"> 
    <select id="node_veid" name="node_veid"  class="nodemount_drop_down" onchange="clearErrorMessage()">
<?php


	for ($i= 0; $i < $range; $i ++) {
		list ($vied, $nproc, $status, $ip, $hostname)= split(':', $listval[$i][0]);
		if ($hostname == '') {
			$hostname= $lang_conv->fetch_word("UNKNOWN");
		}
		if ($veid == $vied) {
			echo ("<option selected value=".$vied.">".$vied." - ".$hostname."-".$status."</option>");
		} else {
			echo ("<option value=".$vied.">".$vied." - ".$hostname."-".$status."</option>");
		}
	}
?>
    </select>
    </div>
    
     
  <div class="nodemount_btn">
  <a href="javascript:void(0);" class="buttonstyle" 
  onclick="doNodeAction('mountnode.php','detail');return false;">
  <?php echo $lang_conv->fetch_word("MOUNT")?>
  </a>
</div>
    
  </form>
<div id="message" class="nodemount_message_style">
<?php

} else {
	$outputmsg= '<font class="norecords_ngmt" >&nbsp;<center>'.'<b>'.$lang_conv->fetch_word("NO_RECORDS").' !!  <br> '.$lang_conv->fetch_word("PLZCREATE_NODE").'</b></center></font>';
}
print $outputmsg;
?>
</div>